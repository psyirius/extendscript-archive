#target bridge
//----------------------------------------------------------------------- 
//
// ADOBE SYSTEMS INCORPORATED
// (c) Copyright 2004-2005 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE: Adobe permits you to use, modify, and distribute
// this file in accordance with the terms of the Adobe license
// agreement accompanying it. If you have received this file
// from a source other than Adobe, then your use, modification,
// or distribution of it requires the prior written permission
// of Adobe.
//
//----------------------------------------------------------------------- 
// <asm:name>Adobe ScriptManager</asm:name>
// <asm:description>Utility that helps to manage existing or developer-created scripts and place them in the correct location in the application.</asm:description>
// <asm:help></asm:help>
// <asm:author>Bob Stucky</asm:author>
// <asm:company>Adobe Systems, Inc.</asm:company>
// <asm:copyright>(c) Copyright 2005 Adobe Systems Incorporated. All rights reserved</asm:copyright>
// <asm:version>0.6.19</asm:version>
// <asm:date>07-07-2005</asm:date>
// <asm:website>http://www.adobe.com</asm:website>
//--------------------------------------------------------------------
// GLOBAL VARIABLES / SETTINGS
//--------------------------------------------------------------------
//
//
// AdobeScriptManager.jsx
// The Script Manager provides an interface to select which scripts can be loaded

// For Scripters:
// To have your script noticed by the Script Manger, you need do nothing. However, the Script Manager
// does support a set of features and tags which can be added to your script file in order to make life easier
// for your users. 
//
// If your script will be localized, you MUST include a target directive as the first line of your script.
// This is due to a bug in scope in which eval() executes. A target directive is:
// #target [app name] - without the comment!
// #target bridge - will cause your script to be executed in the bridge, and will allow it to be localized.
// There's one more step - in order to ensure your localized script is loaded, you must also include
// ScriptManager.reportLoading() as the LAST line of your script. This ensures that the Script Manager knows
// that your script loaded without error. Optionally you can include a ScriptManager.ScriptInfo object to let
// the Script Manager know some stuff about your script.
//
// Below is the example from Contact Sheet.
//
// The localize() functions with the enconded strings are zString localizations done here at Adobe. 
// You can also use the object based localization described in the scripting guide. 
// Or you can just use this call back to set the script information without localization.
// CAUTION: If you are going to use this callback, you MUST have a #target directive as
// the first line of your script. If you do not, it will be loaded via an eval() statement. Because of the scope
// bug in eval(), the ScriptManager namespace object, though defined, will not be included in the scope, causing
// the callback to fail. With the target directive it will work normally.
//
//var ContactSheet = {}
//ContactSheet.scriptInfo = new ScriptManager.ScriptInfo();
//ContactSheet.scriptInfo.set( "name", localize( "$$$/WAS/ContactSheet/infoName=Contact Sheet" ) );
//ContactSheet.scriptInfo.set( "description", localize( "$$$/WAS/ContactSheet/infodesc=Generates a contact sheet from selected InDesign files, showing each page of each file." ) );
//ContactSheet.scriptInfo.set( "help", localize( "$$$/WAS/ContactSheet/infoHelp=Select a set of images in Bridge, select menu item Tools->InDesign->Contact Sheet. The script will flip up a dialog box. Set the number of columns and rows, along with caption options, etc. You may click the 'Files' Button to fine-tune your file selection. From the files dialog you can set file type and name masks, as well as specify a hierarchical file scan. You may also set page options by clicking 'Page Setup'. The Page Setup dialog allows you to set page dimensions, margins, orientation, and units. Setting A4 or A5 will automatically change units to millimeters. Letter or Legal will set units to inches. You may also manually select the unit regardless of the selected page type. If you select PDF for the output, you must specify an output file. If you specify an output file for InDesign, it will open the file, add the images, then save it as an INDD file. The script will show a progress palette of how things are progressing in InDesign." ) );
//ContactSheet.scriptInfo.set( "author", "Bob Stucky" );
//ContactSheet.scriptInfo.set( "company", localize( "$$$/WAS/ContactSheet/infoCompany=Adobe Systems, Inc." ) );
//ContactSheet.scriptInfo.set( "copyright", localize( "$$$/WAS/ContactSheet/infoCopyright=(c)Copyright 2004-2005 Adobe Systems Incorporated 2004, all rights reserved" ) );
//ContactSheet.scriptInfo.set( "version", "0.8.9" );
//ContactSheet.scriptInfo.set( "date", "02-24-2005" );
//ContactSheet.scriptInfo.set( "website", "http://www.adobe.com" );
//ContactSheet.scriptInfo.set( "contact", "rstucky@adobe.com" );
//ScriptManager.reportLoading( ContactSheet.scriptInfo );
//
// If you're not worried about localization, and just want to have the Script Manage display information about your
// script you can optionally use the following tag set. These will work with or without the target directive and call back.
//
// The tags are:
// <asm:name> - a common name to the script - this will be displayed in ScriptManager
// <asm:description> - a few line description of the script - this will be displayed as well
// <asm:help> - a block of help text
// <asm:company> - the name of your company
// <asm:author> - you
// <asm:copyright> - your copyright statement, if any
// <asm:date> - the release date of the script
// <asm:version> - a version number or code
// <asm:website> - your web site
// <asm:contact> - your preferred contact information, email, phone, both?
// 
// each of these tags MUST be on a comment line.
// for multi-line content, use multiple tags, which are concatenated (pay attention to spaces at 
// punctuation). For example:
// <asm:description>This is the best darned script in the world. </asm:description>
// <asm:description>Not only does it do everything including the laundry, </asm:description>
// <asm:description>it also slices bread.</asm:description>
//
if ( BridgeTalk.appName == "bridge" ) {
	$.level = 0;
	$.debugDialog = false;
	
	ScriptManager = {};
	ScriptManager.store = ScriptStore.open( "adobeScriptManager" );
	ScriptManager.storedScripts = undefined;
	ScriptManager.autoLoad = true;
	ScriptManager.scriptFolder = undefined;
	ScriptManager.scripts = new Hashtable( true );
	ScriptManager.groups = new Hashtable( true );
	ScriptManager.errorPalette = undefined;
	ScriptManager.hasBeeped = false;
	ScriptManager.showRestartNotice = true;
	ScriptManager.defaultScriptFolder = new Folder( Folder.commonFiles + "/Adobe/StartupScripts/Workflow Automation Scripts" );
	ScriptManager.startupFolder = new Folder( Folder.commonFiles + "/Adobe/StartupScripts" );
	ScriptManager.isLoaded = false;
	ScriptManager.currentInfo = undefined;

	ScriptManager.dummyString = localize( "$$$/WAS/SM/tryError1=The script file " );
	ScriptManager.dummyString2 = localize( "$$$/WAS/SM/tryError2=, is written in a manner that is potentially dangerous to your script installation, and should be removed." );
	ScriptManager.strings = {};
	ScriptManager.strings.nameString = localize( "$$$/WAS/SM/name=Name: " );
	ScriptManager.strings.fileNameString = localize( "$$$/WAS/SM/fileName=File Name: " );
	ScriptManager.strings.versionString = localize( "$$$/WAS/SM/version=Version: " );
	ScriptManager.strings.dateString = localize( "$$$/WAS/SM/date=Date: " );
	ScriptManager.strings.companyString = localize( "$$$/WAS/SM/company=Company: " );
	ScriptManager.strings.authorString = localize( "$$$/WAS/SM/author=Author: " );
	ScriptManager.strings.webSiteString = localize( "$$$/WAS/SM/website=Web Site: " );
	ScriptManager.strings.contactString = localize( "$$$/WAS/SM/contact=Contact: " );
	ScriptManager.strings.usageCaption = localize( "$$$/WAS/SM/usage=Usage:" );
	ScriptManager.strings.errorCaption = localize( "$$$/WAS/SM/errors=Errors:" );
	ScriptManager.strings.descriptionCaption = localize( "$$$/WAS/SM/desc=Description:" );
	ScriptManager.strings.loadedParens = localize( "$$$/WAS/SM/parenLoaded= (loaded)" );
	ScriptManager.strings.erroredParens = localize( "$$$/WAS/SM/parenErrored= (errored)" );

	ScriptManager.reportLoading = function( info ) {
		ScriptManager.isLoaded = true;
		ScriptManager.currentInfo = info;
	}
	ScriptManager.ScriptInfo = function() {
		this.info = new Hashtable();
	}
	ScriptManager.ScriptInfo.prototype.set = function( name, val ) {
		this.info.put( name, val );
	}
	ScriptManager.ScriptInfo.prototype.get = function( name ) {
		return this.info.get( name );
	}
	
	ScriptManager.Script = function( scriptFile ) {
		this.name = "";
		this.file = scriptFile;
		this.thumb = new Thumbnail( this.file );
		this.hasTargetDirective = false;
		this.load = false;
		this.loaded = false;
		this.errored = false;
		this.text = undefined;
		this.onPrepare = undefined;
		this.onExecute = undefined;
		this.onComplete = undefined;
		this.errors = "";
		this.description = "";
		this.help = "";
		this.date = "";
		this.author = "";
		this.copyright = "";
		this.version = "";
		this.website = "";
		this.contact = "";
		this.company = "";
	}
	ScriptManager.Script.prototype.returnValidValue = function( val1, val2 ) {
		return isValidReference( val1 ) ? val1 : val2 ;
	}
	ScriptManager.Script.prototype.setInfo = function( info ) {
		this.description = info.get( "description" );
		this.name = this.returnValidValue( info.get( "name" ), this.name );
		this.help = this.returnValidValue( info.get( "help" ), this.help );
		this.date = this.returnValidValue( info.get( "date" ), this.date );
		this.author = this.returnValidValue( info.get( "author" ), this.author );
		this.copyright = this.returnValidValue( info.get( "copyright" ), this.copyright );
		this.version = this.returnValidValue( info.get( "version" ), this.version );
		this.website = this.returnValidValue( info.get( "website" ), this.website );
		this.contact = this.returnValidValue( info.get( "contact" ), this.contact );
		this.company = this.returnValidValue( info.get( "company" ), this.company );
	}
	ScriptManager.Script.prototype.loadScript = function() {
		var inLevel = $.level;
		var inDialogs = app.displayDialogs;
		try {
			$.level = 0;
			app.displayDialogs = "none";
			var output = false;
			if ( this.file != "AdobeScriptManager.jsx" ) {
				this.errors = undefined;
				this.errored = false;
				this.loaded = false;
				ScriptManager.currentInfo = undefined;
				if ( this.hasTargetDirective ) {
					ScriptManager.currentInfo = undefined;
					ScriptManager.isLoaded = false;
					output = this.thumb.open();
					if ( !ScriptManager.isLoaded ) {
						eval( this.text );
					} 
				} else {
					eval( this.text );
				}
				if ( isValidReference( ScriptManager.currentInfo ) ) {
					this.setInfo( ScriptManager.currentInfo );
				}
			}
			this.loaded = true;
			this.errors = "";
			this.errored = false;
		} catch ( e ) {
			this.errors = e;
			this.errored = true;
			this.loaded = false;
			ScriptManager.handleError( this );
			ScriptManager.setScriptLoad( this, false );
		} finally {
			$.level = inLevel;
			app.displayDialogs = inDialogs;
		}
	}
	ScriptManager.Script.prototype.setLoad = function( boo ) {
		ScriptManager.setScriptLoad( this, boo );
	}
	ScriptManager.Script.prototype.parse = function() {
		if ( this.file.exists ) {
			this.file.open( "r" );
			this.text = this.file.read();
			this.file.close();
			this.file.open( "r" );
			
			this.errors = "";
			this.description = "";
			this.name = "";
			this.help = "";
			this.date = "";
			this.author = "";
			this.copyright = "";
			this.version = "";
			this.website = "";
			this.contact = "";
			this.company = "";
			while ( !this.file.eof ) {
				var line = trim( this.file.readln() );
				if ( line.startsWith( "#target" ) || line.contains( "@target" ) ) {				
					this.hasTargetDirective = true;
					line = this.file.read();
					break;
				}
				if ( line.contains( "<asm:" ) ) {
					var stuff = getCharsAfter( line, "<asm:" );
					var tag = getCharsBefore( stuff, ">" );
					stuff = getCharsAfter( stuff, ">" );
					stuff = getCharsBefore( stuff, "</asm:" ); // the contents of the tag
					switch( tag.toLowerCase() ) {
						case "errors" : {
							this.errors += stuff;
						}
						case "description" : {
							this.description += stuff; 
							break;
						}
						case "help" : {
							this.help += stuff;
							break;
						}
						case "date" : { 
							this.date += stuff;
							break;
						}
						case "author" : { 
							this.author += stuff;
							break;
						}
						case "copyright" : { 
							this.copyright += stuff;
							break;
						}
						case "version" : { 
							this.version += stuff;
							break;
						}
						case "website" : { 
							this.website += stuff;
							break;
						}
						case "company" : { 
							this.company += stuff;
							break;
						}
						case "contact" : { 
							this.contact += stuff;
							break;
						}
						case "name" : {
							this.name += stuff;
						}
					}
				}
			}
			if ( isEmpty( this.name ) ) {
				this.name = this.file.name;
			}
			this.file.close();
		} else {
			this.error = localize( "$$$/WAS/SM/ScriptNoExist=Script file does not exist." );
		}
	}
	ScriptManager.handleError = function( scp ) {
		if ( !isValidReference( ScriptManager.errorPalette ) ) {
			ScriptManager.errorPalette = new ScriptManager.ErrorPalette( localize( "$$$/WAS/SM/loadErr=Script Loading Errors" ) );
			ScriptManager.errorPalette.palette.onClose = function() {
				ScriptManager.errorPalette = undefined;
			}
		}
		ScriptManager.errorPalette.addError( scp.file.name, scp );
		if ( !ScriptManager.hasBeeped ) {
			ScriptManager.hasBeeped = true;
			app.beep();
		}
	}
	ScriptManager.ui = function() {
//	$.debugDialog = true;
		var d = new DialogUtilities.ExtendedDialog( localize( "$$$/WAS/SM/AdobeScriptManager=Adobe Script Manager" ), true, true );
		d.mainRegion.setOrientation( "column" );
		var topPanel = d.add( "group", "topPanel" );
		var leftPanel = topPanel.add( "panel", "leftPanel", localize( "$$$/WAS/SM/availScripts=Available Scripts:" ) );
		var scriptList = leftPanel.add( "listbox", "scripts", undefined, [280,440] );
		leftPanel.setAlignment( "fill" );
		leftPanel.setAlignChildren( "left" );
		scriptList.control.onChange = function() {
			if ( isValidReference( this.selection ) ) {
				var name = this.wrapper.window.findControl( "name" );
				name.setValue( ScriptManager.strings.nameString + this.selection.script.name );
				var fName = this.wrapper.window.findControl( "fileName" );
				fName.setValue( ScriptManager.strings.fileNameString + this.selection.script.file.name );
				var version = this.wrapper.window.findControl( "version" );
				version.setValue( ScriptManager.strings.versionString + this.selection.script.version );
				var date = this.wrapper.window.findControl( "date" );
				date.setValue( ScriptManager.strings.dateString  + this.selection.script.date );
				var company = this.wrapper.window.findControl( "company" );
				company.setValue( ScriptManager.strings.companyString + this.selection.script.company );
				var author = this.wrapper.window.findControl( "author" );
				author.setValue( ScriptManager.strings.authorString + this.selection.script.author );
				var website = this.wrapper.window.findControl( "website" );
				website.setValue( ScriptManager.strings.webSiteString + this.selection.script.website );
				var contact = this.wrapper.window.findControl( "contact" );
				contact.setValue( ScriptManager.strings.contactString + this.selection.script.contact );
				var description = this.wrapper.window.findControl( "description" );
				description.setValue( this.selection.script.description );
				var help = this.wrapper.window.findControl( "help" );
				var helpCaption = this.wrapper.window.findControl( "helpStatic" );
				if ( !this.selection.script.errored ) {
					helpCaption.setValue( ScriptManager.strings.usageCaption );
					help.setValue( this.selection.script.help );
				} else {
					helpCaption.setValue( ScriptManager.strings.errorCaption );
					help.setValue( this.selection.script.errors );
				}
//				var errors = this.wrapper.window.findControl( "errors" );
				var load = this.wrapper.window.findControl( "load" );
				load.setEnabled( true );
				load.setValue( this.selection.script.load );
			} else {
				var name = this.wrapper.window.findControl( "name" );
				name.setValue( ScriptManager.strings.nameString );
				var fName = this.wrapper.window.findControl( "fileName" );
				fName.setValue( ScriptManager.strings.fileNameString );
				var version = this.wrapper.window.findControl( "version" );
				version.setValue( ScriptManager.strings.versionString );
				var date = this.wrapper.window.findControl( "date" );
				date.setValue( ScriptManager.strings.dateString );
				var company = this.wrapper.window.findControl( "company" );
				company.setValue( ScriptManager.strings.companyString );
				var author = this.wrapper.window.findControl( "author" );
				author.setValue( ScriptManager.strings.authorString );
				var website = this.wrapper.window.findControl( "website" );
				website.setValue( ScriptManager.strings.webSiteString );
				var contact = this.wrapper.window.findControl( "contact" );
				contact.setValue( ScriptManager.strings.contactString );
				var description = this.wrapper.window.findControl( "description" );
				description.setValue( "" );
				var help = this.wrapper.window.findControl( "help" );
				var helpCaption = this.wrapper.window.findControl( "helpStatic" );
				help.setValue( "" );
				helpCaption.setValue( ScriptManager.strings.usageCaption );
//				var errors = this.wrapper.window.findControl( "errors" );
//				errors.setValue( "" );
				var load = this.wrapper.window.findControl( "load" );
				load.setValue( false );
				load.setEnabled( false );
			}
		}
		var rightPanel = topPanel.add( "panel", "rightPanel", localize( "$$$/WAS/SM/scriptDetails=Script Details" ) );
		rightPanel.setAlignChildren( "top" );
		var loadIt = rightPanel.add( "checkbox", "load", localize( "$$$/WAS/SM/loadOnStartup=Load on Startup" ) );
		loadIt.control.scriptList = scriptList.control;
		loadIt.control.onClick = function() {
//		debugger;
			if ( isValidReference( this.scriptList.selection ) ) {
				this.scriptList.selection.script.setLoad( this.value );
				if ( this.value ) {
					this.scriptList.selection.script.parse();
					this.scriptList.selection.script.loadScript();
					this.scriptList.notify();
					ScriptManager.hasBeeped = false;
				} else {
					ScriptManager.restartNotice();
				}
//				this.scriptList.notify();
				var selectedScriptFile = this.scriptList.selection.script.file.name;
				this.scriptList.removeAll();
				for ( var i = 0; i < ScriptManager.scripts.keyList.length; i++ ) {
					var scp = ScriptManager.scripts.get( ScriptManager.scripts.keyList[ i ] );
					if ( scp.loaded ) {
						var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.loadedParens ) );
						item.script = scp;
					} else if ( scp.errored ) {
						var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.erroredParens ) );
						item.script = scp;
					} else {
						var item = scriptList.control.add( "item", scp.name );
						item.script = scp;
					}
					if ( scp.file.name == selectedScriptFile ) {
						item.selected = true;
					}
				}
				this.scriptList.notify();
			}
		}
		var spaces = "                                                   ";
		var rightPanelMGroup = rightPanel.add( "group", "rightPanelMGroup" );
		var rightPanelLGroup = rightPanelMGroup.add( "group", "rightPanelLGroup" );
		rightPanelLGroup.setOrientation( "column" );
		rightPanelLGroup.setAlignChildren( "left" );
		var rightPanelRGroup = rightPanelMGroup.add( "group", "rightPanelRGroup" );
		rightPanelRGroup.setOrientation( "column" );
		rightPanelRGroup.setAlignChildren( "left" );
		var nameField = rightPanelLGroup.add( "statictext", "name", ScriptManager.strings.nameString + spaces );
		var fileNameField = rightPanelLGroup.add( "statictext", "fileName", ScriptManager.strings.fileNameString + spaces );
		var versionField = rightPanelLGroup.add( "statictext", "version", ScriptManager.strings.versionString + spaces );
		var dateField = rightPanelLGroup.add( "statictext", "date", ScriptManager.strings.dateString + spaces );
		var authorField = rightPanelRGroup.add( "statictext", "author", ScriptManager.strings.authorString + spaces );
		var companyField = rightPanelRGroup.add( "statictext", "company", ScriptManager.strings.companyString + spaces );
		var websiteField = rightPanelRGroup.add( "statictext", "website", ScriptManager.strings.webSiteString + spaces );
		var contactField = rightPanelRGroup.add( "statictext", "contact", ScriptManager.strings.contactString + spaces );
		var invisibleField = rightPanel.add( "statictext", "invis", "you can't see me" );
		invisibleField.control.visible = false;
		var props = {};
		props.readonly = true;
		props.multiline = true;
		var alignGroup = rightPanel.add( "group", "alignDetail" );
		rightPanel.setAlignChildren( "left" );
		alignGroup.setOrientation( "column" );
		alignGroup.setAlignChildren( "right" );
		var descField = alignGroup.addComplexEdit( "description", "", [400,80], props, ScriptManager.strings.descriptionCaption, undefined, undefined, "top" );
		var helpField = alignGroup.addComplexEdit( "help", "", [400,120], props, ScriptManager.strings.usageCaption, undefined, undefined, "top");
//		var errField = alignGroup.addComplexEdit( "errors", "", [400,80], props, "Errors:", undefined, undefined, "top" );
		
		props.multiline = false;
		var bottomPanel = d.add( "panel", "bottomPanel", localize( "$$$/WAS/SM/scriptsFolder=Scripts Folder" ) );
		bottomPanel.setAlignChildren( "left" );
		var folderGroup = bottomPanel.add( "group", "folderGroup" );
		folderGroup.setAlignment( "fill" );
		var folderEdit = folderGroup.add( "edittext", "scriptFolder", ScriptManager.scriptFolder.fsName, [600,20], props );
		folderEdit.setAlignment( "fill" );
		var folderButton = folderGroup.add( "button", "folderButton", localize( "$$$/WAS/SM/select=Select" ) );
		folderButton.setAlignment( "right" );
		var autoLoad = bottomPanel.add( "checkbox", "load", localize( "$$$/WAS/SM/autoload=Automatically Load New Scripts" ) );
		autoLoad.control.onClick = function() {
			ScriptManager.autoLoad = this.value;
			var storeAuto = this.value ? "true" : "false";
			ScriptManager.store.put( "configuration", "loadNew", storeAuto );
		}
		folderButton.control.editField = folderEdit;
		folderButton.control.onClick = function() {
			var newFolder = ScriptManager.scriptFolder.selectDlg( localize( "$$$/WAS/SM/selectScriptsFolder=Select a Folder:" ) );
			if ( newFolder != null ) {
				this.editField.setValue( newFolder.fsName );
				this.editField.control.notify();
			}
		}
		folderEdit.control.scriptList = scriptList.control;
		folderEdit.control.onChange = function() {
			var newFolder = new Folder( this.text );
			if ( trim( newFolder ) == trim( ScriptManager.startupFolder ) ) {
				this.text = decodeURI( ScriptManager.scriptFolder.fsName );
				alert( localize( "$$$/WAS/SM/AdobeScriptManager/ssCollision=The Scripts Folder cannot be the StartupScripts folder" ) );
				return;
			}
			ScriptManager.store.put( "configuration", "scriptsfolder", this.text );
			ScriptManager.scriptFolder = newFolder;
			ScriptManager.run();
			this.scriptList.removeAll();
			for ( var i = 0; i < ScriptManager.scripts.keyList.length; i++ ) {
				var scp = ScriptManager.scripts.get( ScriptManager.scripts.keyList[ i ] );
				if ( scp.loaded ) {
					var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.loadedParens ) );
					item.script = scp;
				} else if ( scp.errored ) {
					var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.erroredParens ) );
					item.script = scp;
				} else {
					var item = scriptList.control.add( "item", scp.name );
					item.script = scp;
				}
			}
			ScriptManager.restartFolderNotice();
		}
		// fill the dialog with script data
		for ( var i = 0; i < ScriptManager.scripts.keyList.length; i++ ) {
			var scp = ScriptManager.scripts.get( ScriptManager.scripts.keyList[ i ] );
			if ( scp.loaded ) {
				var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.loadedParens ) );
				item.script = scp;
			} else if ( scp.errored ) {
				var item = scriptList.control.add( "item", ( scp.name + ScriptManager.strings.erroredParens ) );
				item.script = scp;
			} else {
				var item = scriptList.control.add( "item", scp.name );
				item.script = scp;
			}
		}
		loadIt.setValue( false );
		loadIt.setEnabled( false );
		// set the options data
		autoLoad.setValue( ScriptManager.autoLoad );
		folderEdit.setValue( File.decode( ScriptManager.scriptFolder.fsName ) );
		return d.show();
//		$.debugDialog = false;
	}
	ScriptManager.scan = function() {
		ScriptManager.scriptFolder = ScriptManager.store.get( "configuration", "scriptsfolder" );
		if ( !isValidReference( ScriptManager.scriptFolder ) ) {
			ScriptManager.scriptFolder = Folder.userData + "/Adobe/Scripts";
			ScriptManager.store.put( "configuration", "scriptsfolder", ScriptManager.scriptFolder );
			ScriptManager.store.save();
			var adobeFolder = new Folder( Folder.userData + "/Adobe" );
			if ( !adobeFolder.exists ) {
				var boo = adobeFolder.create();
				if ( !boo ) {
					throw localize( "$$$/WAS/SM/noCreateCommonFiles=Could not create Adobe folder in Common Files folder" );
				}
			}	
			var folder = new Folder( Folder.userData + "/Adobe/Scripts" );
			if ( !folder.exists ) {
				var boo = folder.create();
				if ( !boo ) {
					throw localize( "$$$/WAS/SM/noCreateScripts=Could not create default Scripts folder" );
				}
			}
			
		}
		ScriptManager.scriptFolder = new Folder( ScriptManager.scriptFolder );
		ScriptManager.validScriptsFolder = true;
		if ( trim( ScriptManager.startupFolder ) == trim( ScriptManager.scriptFolder ) ) {
			ScriptManager.validScriptsFolder = false;
		}
//		debugger;
		var files = new Array();
		if ( ScriptManager.defaultScriptFolder.exists ) {
			var rawFiles = ScriptManager.defaultScriptFolder.getFiles();
			ScriptManager.filterScripts( rawFiles, files );
		}
		if ( ScriptManager.scriptFolder.exists && ScriptManager.validScriptsFolder ) {
			var rawFiles = ScriptManager.scriptFolder.getFiles();
			ScriptManager.filterScripts( rawFiles, files );
		}
		ScriptManager.scriptsInFolder = files;
	}
	ScriptManager.filterScripts = function( files, array ) {
		for ( var i = 0; i < files.length; i++ ) {
			if ( files[ i ] instanceof File ) {
				if ( files[ i ].isFileType( TYPES.SCRIPT ) ) {
					array.push( files[ i ] );
				}
			}
		}
	}
	ScriptManager.readScripts = function() {
		for ( var i = 0; i < ScriptManager.scriptsInFolder.length; i++ ) {
			var scp = new ScriptManager.Script( ScriptManager.scriptsInFolder[ i ] );
			scp.parse();
			ScriptManager.scripts.put( scp.file.name, scp );
		}
	}
	ScriptManager.load = function() {
		ScriptManager.readScripts();
		ScriptManager.storedScripts = ScriptManager.store.getCollection( "ScriptLoadState", "scriptList" );
		var scriptsAfterLoad = new Hashtable( true );
		ScriptManager.autoLoad = ScriptManager.store.get( "configuration", "loadNew" );
		if ( !isValidReference( ScriptManager.autoLoad ) ) {
			ScriptManager.autoLoad = true;
			var storeAutoLoad = ScriptManager.autoLoad ? "true" : "false";
			ScriptManager.store.put( "configuration", "loadNew", storeAutoLoad );
		} else {
			ScriptManager.autoLoad = eval( ScriptManager.autoLoad );
		}
		if ( !isValidReference( ScriptManager.storedScripts ) ) {
			ScriptManager.storedScripts = new Hashtable( true );
			ScriptManager.store.putCollection( "ScriptLoadState", "scriptList", ScriptManager.storedScripts );
		}
//		debugger;
		for ( var i = 0; i < ScriptManager.scripts.keyList.length; i++ ) {
			var scp = ScriptManager.scripts.get( ScriptManager.scripts.keyList[ i ] );
			var storedScp = ScriptManager.storedScripts.get( scp.file.name );
			if ( !isValidReference( storedScp ) ) { // not stored, new script found
				scp.load = ScriptManager.autoLoad;
			} else { // get the load state of the stored script
				scp.load = eval( storedScp );
			}
			if ( scp.load ) {
				scp.loadScript();
			}
			var storeLoad = scp.load ? "true" : "false";
			scriptsAfterLoad.put( scp.file.name, scp.load );
		}
		ScriptManager.storedScripts = scriptsAfterLoad;
		ScriptManager.store.putCollection( "ScriptLoadState", "scriptList", ScriptManager.storedScripts );
	}
	ScriptManager.setScriptLoad = function( scp, load ) {
		scp.load = load;
		var storeLoad = load ? "true" : "false";
		ScriptManager.storedScripts.put( scp.file.name, storeLoad );
		ScriptManager.store.putCollection( "ScriptLoadState", "scriptList", ScriptManager.storedScripts );
	}
	ScriptManager.notLoaded = true;
	ScriptManager.onLoad = function( event ) {
		if ( event.object.constructor.name == "Document" ) {
			if ( event.type == "loaded" ) {
				if ( ScriptManager.notLoaded ) {
					ScriptManager.load();
					ScriptManager.notLoaded = false;
				}
				return { handled:false }; 
			}
		}
		return { handled:false };
	}
	ScriptManager.run = function() {
		ScriptManager.hasBeeped = false;
		ScriptManager.scan();		
		app.eventHandlers.push( { handler:  ScriptManager.onLoad } );
		ScriptManager.hasBeeped = false;
	}
	ScriptManager.uiCreate = function() {
	}
	ScriptManager.linkUI = function() {
	}
	ScriptManager.restartNotice = function() {
//	debugger;
		ScriptManager.showRestartNotice = ScriptManager.store.get( "configuration", "showRestartNotice" );
		if ( !isValidReference( ScriptManager.showRestartNotice ) ) {
			ScriptManager.showRestartNotice = true;
			ScriptManager.store.put( "configuration", "showRestartNotice", "true" );
		} else {
			ScriptManager.showRestartNotice = eval( ScriptManager.showRestartNotice ); // turn text in to boolean
		}
		if ( ScriptManager.showRestartNotice ) {
			var noticeDialog = new ScriptManager.RestartNotice( localize( "$$$/WAS/SM/mustRestart=You must restart Bridge to unload a script." ) );
			var clicked = noticeDialog.dialog.show();
			var notice = !noticeDialog.notice.value
			var storeNotice = notice ? "true" : "false";
			ScriptManager.store.put( "configuration", "showRestartNotice", storeNotice );
		}
	}
	ScriptManager.restartFolderNotice = function() {
//	debugger;
		ScriptManager.showNewFolderRestartNotice = ScriptManager.store.get( "configuration", "showNewFolderRestartNotice" );
		if ( !isValidReference( ScriptManager.showNewFolderRestartNotice ) ) {
			ScriptManager.showNewFolderRestartNotice = true;
			ScriptManager.store.put( "configuration", "showNewFolderRestartNotice", "true" );
		} else {
			ScriptManager.showNewFolderRestartNotice = eval( ScriptManager.showNewFolderRestartNotice ); // turn text in to boolean
		}
		if ( ScriptManager.showNewFolderRestartNotice ) {
			var noticeDialog = new ScriptManager.RestartNotice( localize( "$$$/WAS/SM/folderChangeNote=Previously loaded scripts are still loaded. You must restart Bridge to unload them.") );
			var clicked = noticeDialog.dialog.show();
			var notice = !noticeDialog.notice.value
			var storeNotice = notice ? "true" : "false";
			ScriptManager.store.put( "configuration", "showNewFolderRestartNotice", storeNotice );
		}
	}

	ScriptManager.ErrorPalette = function( title ) {
		var paletteTitle = isValidReference( title ) ? title : localize( "$$$/WAS/SM/scriptLoadErrors=Script Loading Errors" );
		this.palette = new Window( "palette", title );
		this.palette.location = [100,100];
		this.palette.orientation = "column";
		this.palette.alignChildren = "left";
		this.errPanel = this.palette.add( "panel", undefined, localize( "$$$/WAS/SM/scriptsWithErrors=Script Files with Errors" ) );
		this.errPanel.alignChildren = "left";
		this.list = this.errPanel.add( "listbox",undefined, undefined, {multiselect:false} );
		this.list.preferredSize = [250,100];
		var props = {};
		props.readonly = false;
		props.multiline = true;
		this.panel = this.palette.add( "panel", undefined, localize( "$$$/WAS/SM/errorDetails=Details" ) );
		this.panel.alignChildren = "left";
		this.scriptName = this.panel.add( "statictext", undefined, localize( "$$$/WAS/SM/errScriptNameSpacesAreImportant=Name:                                                                       " ) );
		this.scriptFile = this.panel.add( "statictext", undefined, localize( "$$$/WAS/SM/errFileNameSpacesAreImportant=File:                                                                       " ) );
		this.errLine = this.panel.add( "statictext", undefined, localize( "$$$/WAS/SM/errInLineSpacesArImportant=Error in Line:                                                    " ) );
		this.detail = this.panel.add( "edittext", undefined, undefined, props );
		this.detail.preferredSize = [250,100];
		this.errList = new Hashtable( true );
		this.list.errList = this.errList;
		this.list.palette= this;
		this.list.onChange = function() {
			if ( isValidReference( this.selection ) ) {
				var scp = this.errList.get( this.selection.text );
				this.palette.detail.text = scp.errors;
				this.palette.scriptName.text = localize( "$$$/WAS/SM/errScriptName=Name: " ) + scp.name;
				this.palette.scriptFile.text = localize( "$$$/WAS/SM/errScriptFile=File: " ) + scp.file.name;
				this.palette.errLine.text = localize( "$$$/WAS/SM/errInLine=Error in Line: " ) + scp.errors.line;
			} else {
				this.palette.detail.text = "";
				this.palette.scriptName.text = localize( "$$$/WAS/SM/errScriptNameSolo=Name: " );
				this.palette.scriptFile.text = localize( "$$$/WAS/SM/errScriptFileSolo=File: " );
				this.palette.errLine.text = localize( "$$$/WAS/SM/errInLineSolo=Error in Line: " );
			}
		}
		this.palette.show();
	}
	ScriptManager.ErrorPalette.prototype.close = function() {
		this.palette.close();
	}
	ScriptManager.ErrorPalette.prototype.hide = function() {
		this.palette.hide();
	}
	ScriptManager.ErrorPalette.prototype.updateList = function() {
		this.list.removeAll();
		for ( var i = 0; i < this.errList.keyList.length; i++ ) {
			this.list.add( "item", this.errList.keyList[ i ] );
		}
	}
	ScriptManager.ErrorPalette.prototype.addError = function( key, scp ) {
		this.errList.put( key, scp );
		this.updateList();	
	}
	ScriptManager.RestartNotice = function( msg ) {
		this.dialog = new Window( "dialog", localize( "$$$/WAS/SM/helpNoteTitle=Script Manager Help Note" ) );
		this.dialog.orientation = "column";
		var txt = this.dialog.add( "statictext", undefined, msg, { multiline:true } );
		this.notice = this.dialog.add( "checkbox", undefined, localize( "$$$/WAS/SM/noShow=Do not show this message again" ) );
		this.ok = this.dialog.add( "button", undefined, localize( "$$$/WAS/SM/okBtn=OK" ) );
		this.ok.onClick = function() {
			this.parent.close( 1 );
		}
		this.ok.alignment = "right";
		this.dialog.center();
	}
	ScriptManager.RestartNotice.prototype.show = function() {
		this.show();
		return ( !this.notice.value );
	}
// set up menu
	try {
		createGenericMenus();		
		createMenu( "command", localize( "$$$/WAS/SM/menu=Script Manager..." ), "after CRPreferences", "edit/scriptManager", ScriptManager.ui );
	} catch ( a ) {	
		alert( a );
	}
// end execute script load
	ScriptManager.run();
}