#target bridge
//----------------------------------------------------------------------- 
//
// ADOBE SYSTEMS INCORPORATED
// (c) Copyright 2004-2005 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE: Adobe permits you to use, modify, and distribute
// this file in accordance with the terms of the Adobe license
// agreement accompanying it. If you have received this file
// from a source other than Adobe, then your use, modification,
// or distribution of it requires the prior written permission
// of Adobe.
//
//--------------------------------------------------------------------
// GLOBAL VARIABLES / SETTINGS
//--------------------------------------------------------------------

// debug level: 0-2 (0:disable, 1:break on error, 2:break at beginning)
$.level = 0;
if ( BridgeTalk.appName = "bridge" )  {

var ContactSheet = {}
try {
	ContactSheet.scriptInfo = new ScriptManager.ScriptInfo();
	ContactSheet.scriptInfo.set( "name", localize( "$$$/WAS/ContactSheet/infoName=Contact Sheet" ) );
	ContactSheet.scriptInfo.set( "description", localize( "$$$/WAS/ContactSheet/infodesc=Generates a contact sheet from selected InDesign files, showing each page of each file." ) );
	ContactSheet.scriptInfo.set( "help", localize( "$$$/WAS/ContactSheet/infoHelp=Select a set of images in Bridge, select menu item Tools->InDesign->Contact Sheet. The script will flip up a dialog box. Set the number of columns and rows, along with caption options, etc. You may click the 'Files' Button to fine-tune your file selection. From the files dialog you can set file type and name masks, as well as specify a hierarchical file scan. You may also set page options by clicking 'Page Setup'. The Page Setup dialog allows you to set page dimensions, margins, orientation, and units. Setting A4 or A5 will automatically change units to millimeters. Letter or Legal will set units to inches. You may also manually select the unit regardless of the selected page type. If you select PDF for the output, you must specify an output file. If you specify an output file for InDesign, it will open the file, add the images, then save it as an INDD file. The script will show a progress palette of how things are progressing in InDesign." ) );
	ContactSheet.scriptInfo.set( "author", "Bob Stucky" );
	ContactSheet.scriptInfo.set( "company", localize( "$$$/WAS/ContactSheet/infoCompany=Adobe Systems, Inc." ) );
	ContactSheet.scriptInfo.set( "copyright", localize( "$$$/WAS/ContactSheet/infoCopyright=9c) Copyright 2004-2005 Adobe Systems Incorporated. All rights reserved" ) );
	ContactSheet.scriptInfo.set( "version", "0.8.31" );
	ContactSheet.scriptInfo.set( "date", "07-07-2005" );
	ContactSheet.scriptInfo.set( "website", "http://www.adobe.com" );
} catch ( e ) {
}
ContactSheet.strings = {};
ContactSheet.enableFacingPagesCheckBox = true;

//--------------------------------------------------------------------
// COMMAND FUNCTIONS
//--------------------------------------------------------------------
ContactSheet.showDialog = function()  {
	try {
//	debugger;
	$.level = 0;
		var d = ContactSheet.getDialog( ContactSheet.config );
//		d.fileGroup.refresh.notify();
	  	var okClicked = d.show() == 1 ? true : false;
	} catch ( a ) {
		alert( a );
	}
	app.document.bringToFront();
	if ( okClicked )  {
		try {
//		debugger;
			ContactSheet.config.files = d.files;
			ContactSheet.config.rowCount = d.layoutGroup.rows.rows.text;
			ContactSheet.config.colCount = d.layoutGroup.columns.columns.text;
			ContactSheet.config.verticalGap = d.layoutGroup.vGap.edit.text;
			ContactSheet.config.horizontalGap = d.layoutGroup.hGap.edit.text;
			ContactSheet.config.removeFrames = true;
			if ( ContactSheet.config.caption.length > 0 ) {
				ContactSheet.config.label = true;			
			} else {
				ContactSheet.config.label = false;
			}
//			ContactSheet.config.format = d.outputGroup.format.drop.selection.text;
			ContactSheet.config.place = d.layoutGroup.place.place.selection.text;
			if ( ContactSheet.config.rotation == ContactSheet.strings.Clockwise ) {
				ContactSheet.config.rotationValue = 270;
			} else {
				ContactSheet.config.rotationValue = 90;
			}
			ContactSheet.execute( ContactSheet.config );
		} catch ( e ) {
			alert( e );
		}
	}
	$.level = 0;
}
ContactSheet.execute = function( config ) {
	var files = new Array();
//debugger;
	for ( var i = 0; i < config.files.length; i++ ) { // get rid of any Folder objects in the file array
		if ( config.files[ i ] instanceof File ) {
			files.push( config.files[ i ] );
		}
	}
	var theScript = "sendBackStatus( 1, \"" + ContactSheet.strings.accept + "\" ); \n";
	theScript += "$.level = 0; \n";
	theScript += "var ContactSheet = {}; \n";
	theScript += "ContactSheet.config = {}; \n";
	theScript += "ContactSheet.config.files = eval( " + files.toSource() + " ); \n";
	var outputFile = "null";
	config.saveNewFile = false;
	if ( config.saveAsPDF ) {
		var f = new File( config.output );
		var f = f.getFileWithExtension( "pdf" );
		if ( f.exists ) {
			if ( !confirm( f.name + ContactSheet.strings.overwrite ) ) {
				alert( ContactSheet.strings.cancelledByUser );
				return;
			}
		}
		config.output = f;
		outputFile = config.output.toSource();
		theScript += "ContactSheet.config.output = eval( " + outputFile + " ); \n";
	} else {
		config.makeNewFile = true;
		theScript += "ContactSheet.config.output = null; \n";
	}
	if ( config.useTemplate ) {
		theScript += "ContactSheet.config.templateFile = eval( " + config.templateFile.toSource() + " ); \n";
	} else {
		theScript += "ContactSheet.config.templateFile = null; \n";
	}
	theScript += "ContactSheet.config.rotate = " + config.rotate + "; \n";
	theScript += "ContactSheet.config.rotation = " + parseInt( config.rotationValue ) + "; \n";
	theScript += "ContactSheet.config.PDFPreset = '" + config.PDFPreset + "'; \n";
	theScript += "ContactSheet.config.useTemplate = " + config.useTemplate + ";\n";
	theScript += "ContactSheet.config.saveAsPDF = " + config.saveAsPDF + ";\n";
	theScript += "ContactSheet.config.rowCount = " + parseInt( config.rowCount ) + "; \n";
	theScript += "ContactSheet.config.colCount = " + parseInt( config.colCount ) + "; \n";
	theScript += "ContactSheet.config.verticalGap = " + parseFloat( config.verticalGap ) + "; \n";
	theScript += "ContactSheet.config.overImages = " + config.overImages + "; \n";
	theScript += "ContactSheet.config.overImageGap = " + parseFloat( config.overImageGap ) + "; \n";
	theScript += "ContactSheet.config.horizontalGap = " + parseFloat( config.horizontalGap ) + "; \n";
	theScript += "ContactSheet.config.removeFrames = " + config.removeFrames + "; \n";
	theScript += "ContactSheet.config.label = " + config.label + "; \n";
	theScript += "ContactSheet.config.labelStyle = " + config.labelStyle + "; \n";
	theScript += "ContactSheet.config.caption = eval( " + config.caption.toSource() + " ); \n";
	theScript += "ContactSheet.config.autospace = " + config.autospace + "; \n";
	theScript += "ContactSheet.config.place = '" + config.place + "'; \n";
	theScript += "ContactSheet.config.pageSetup = {}; \n";
	theScript += "ContactSheet.config.pageSetup.units = '" + config.pageSetup.units + "'; \n";
	theScript += "ContactSheet.config.pageSetup.pageSize = '" + config.pageSetup.pageSize + "'; \n";
	theScript += "ContactSheet.config.pageSetup.width = " + parseFloat( config.pageSetup.width ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.height = " + parseFloat( config.pageSetup.height ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.facingPages = " + config.pageSetup.facingPages + "; \n";
	theScript += "ContactSheet.config.pageSetup.margins = {}; \n";
	theScript += "ContactSheet.config.pageSetup.margins.top = " + parseFloat( config.pageSetup.margins.top ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.margins.bottom = " + parseFloat( config.pageSetup.margins.bottom ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.margins.inside = " + parseFloat( config.pageSetup.margins.inside ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.margins.outside = " + parseFloat( config.pageSetup.margins.outside ) + "; \n";
	theScript += "ContactSheet.config.pageSetup.orientation = '" + config.pageSetup.orientation + "'; \n";
	theScript += "ContactSheet.margins = function( top, bottom, inside, outside ) { \n" +
				"//	var saveVP = app.viewPreferences.rulerOrigin; \n" +
				"//	app.viewPreferences.rulerOrigin = RulerOrigin.pageOrigin; \n" +
				"	this.inside = inside; \n" +
				"	this.outside = outside; \n" +
				"	this.top = top; \n" +
				"	this.bottom = bottom; \n" +
				"} \n" +
				" \n" +
				"ContactSheet.execute = function ( config ){  \n" +
				"	var fpp = config.rowCount * config.colCount; \n" +
				"	var doc = null; \n" +
				"	if ( !ContactSheet.config.useTemplate ) { \n" +
				"		doc = app.documents.add(); \n" +
				"	} else { \n" +
				"		doc = app.open( config.templateFile ); \n" +
				"	} \n" +
				"	doc.viewPreferences.rulerOrigin = RulerOrigin.pageOrigin; \n" +
				"	doc.viewPreferences.horizontalMeasurementUnits = eval( config.pageSetup.units ); \n" +
				"	doc.viewPreferences.verticalMeasurementUnits = eval( config.pageSetup.units ); \n" +
				"	if ( !config.useTemplate ) { \n" +
				"		var prefs = doc.documentPreferences; \n" +
				"		var totalFrames = config.files.length; \n" +
				"		var pageCount = Math.round( totalFrames / fpp ); \n" +
				"		if ( ( pageCount * fpp ) < totalFrames ) { \n" +
				"			pageCount++; // handle round off error \n" +
				"		} \n" +
				"		prefs.facingPages = config.pageSetup.facingPages; \n" +
				"		if ( pageCount > doc.pages.length ) { \n" +
				"			prefs.pagesPerDocument = pageCount; \n" +
				"		} \n" +
				"		var page = doc.pages.item( 0 ); \n" +
				"		var margins = page.marginPreferences; \n" +
				"		margins.left = config.pageSetup.margins.outside; \n" +
				"		margins.top = config.pageSetup.margins.top; \n" +
				"		margins.right = config.pageSetup.margins.inside; \n" +
				"		margins.bottom = config.pageSetup.margins.bottom \n" +
				"		prefs.pageWidth = config.pageSetup.width; \n" +
				"		prefs.pageHeight = config.pageSetup.height; \n" +
				"		var workingWidth = 	prefs.pageWidth - ( margins.left + margins.right ); \n" +
				"		var workingHeight = prefs.pageHeight - ( margins.top + margins.bottom ); \n" +
				"		var colWidth = workingWidth / config.colCount; \n" +
				"		var frameWidth = ( workingWidth - ( ( config.colCount - 1 ) * config.horizontalGap ) ) / config.colCount; \n" +
				"		var rowHeight = workingHeight / config.rowCount; \n" +
				"		var frameHeight = rowHeight - config.verticalGap; \n" +
				"		var pages = doc.pages; \n" +
				"	} else { \n" +
				"		var prefs = doc.documentPreferences; \n" +
				"		var totalFrames = config.files.length; \n" +
				"		var pageCount = Math.round( totalFrames / fpp ); \n" +
				"		if ( ( pageCount * fpp ) < totalFrames ) { \n" +
				"			pageCount++; // handle round off error \n" +
				"		} \n" +
				"		if ( pageCount > doc.pages.length ) { \n" +
				"			prefs.pagesPerDocument = pageCount; \n" +
				"		} \n" +
				"		var page = doc.pages.item( 0 ); \n" +
				"		var margins = page.marginPreferences; \n" +
				"		var workingWidth = 	prefs.pageWidth - ( margins.left + margins.right ); \n" +
				"		var workingHeight = prefs.pageHeight - ( margins.top + margins.bottom ); \n" +
				"		var colWidth = workingWidth / config.colCount; \n" +
				"		var frameWidth = ( workingWidth - ( ( config.colCount - 1 ) * config.horizontalGap ) ) / config.colCount; \n" +
				"		var rowHeight = workingHeight / config.rowCount; \n" +
				"		var frameHeight = rowHeight - config.verticalGap; \n" +
				"		var pages = doc.pages; \n" +
				"	} \n" +
				"	var labelStyle = null; \n" +
				"	var labelLayer = null; \n" +
				"	if( config.label ){  \n" +
				"//Create the label paragraph style if it does not already exist.  \n" +
				"		labelStyle = doc.paragraphStyles.item('labels');  \n" +
				"		try{  \n" +
				"			labelStyle.name;  \n" +
				"		}  \n" +
				"		catch ( e ){  \n" +
				"			labelStyle = doc.paragraphStyles.add( {name:'labels'} );  \n" +
				"		}  \n" +
				"		labelStyle.pointSize = 10;  \n" +
				"//Create the label layer if it does not already exist.  \n" +
				"		var labelLayer = doc.layers.item('labels');  \n" +
				"		try{  \n" +
				"			labelLayer.name;  \n" +
				"		}  \n" +
				"		catch ( e ){  \n" +
				"			labelLayer = doc.layers.add({name:'labels'});  \n" +
				"		}  \n" +
				"	} \n" +
				"//Create the object style if it doesn't exist \n" +
				"  	var objectStyle = doc.objectStyles.item( 'images' );\n" +
				"  	try { \n" +
				"  		objectStyle.name;\n" +
				"  	} catch ( e ) { \n" +
				"  		objectStyle = doc.objectStyles.add( {name:'images'} );\n" +
				"  	}\n" +
				"  	var captionObjectStyle = doc.objectStyles.item( 'captions' );\n" +
				"  	try { \n" +
				"  		captionObjectStyle.name;\n" +
				"  	} catch ( e ) { \n" +
				"  		captionObjectStyle = doc.objectStyles.add( {name:'captions'} );\n" +
				"  	}\n" +
				"// set up for place by rows or colums \n" +
				"	var OLloop = config.rowCount; \n" +
				"	var ILloop = config.colCount; \n" +
				"	var OLp1 = 'margins.top + ( rowHeight * ( a - 1) )'; \n" +
				"	var OLp2 = 'op1 + frameHeight'; \n" +
				"	var ILp1 = 'facingPagesHack + ( colWidth * ( b - 1 ) )'; \n" +
				"//	var ILp1 = 'margins.left + ( colWidth * ( b - 1 ) )'; \n" +
				"	var ILp2 = 'ip1 + frameWidth'; \n" +
				"   var swatch = doc.swatches.item('None'); \n" +
				"//	var frameMaker = 'thisPage.rectangles.add( doc.layers.item(-1), undefined, undefined, { geometricBounds:[op1, ip1, op2, ip2], strokeWeight:0, strokeColor:swatch } )'; \n" +
				"	var frameMaker = '[op1,ip1,op2,ip2]'; \n" +
				"	if ( config.place != '" + ContactSheet.strings.acrossFirst + "' ) { \n" +
				"		OLloop = config.colCount; \n" +
				"		ILloop = config.rowCount; \n" +
				"		ILp1 = 'margins.top + ( rowHeight * ( b - 1) )'; \n" +
				"		ILp2 = 'ip1 + frameHeight'; \n" +
				"		OLp1 = 'facingPagesHack + ( colWidth * ( a - 1 ) )'; \n" +
				"//		OLp1 = 'margins.left + ( colWidth * ( a - 1 ) )'; \n" +
				"		OLp2 = 'op1 + frameWidth'; \n" +
				"//		frameMaker = 'thisPage.rectangles.add( doc.layers.item(-1), undefined, undefined, { geometricBounds:[ip1, op1, ip2, op2], strokeWeight:0, strokeColor:swatch } )'; \n" +
				"		frameMaker = '[ip1, op1, ip2, op2]'; \n" +
				"	} \n" +
				"// create frames  \n" +
				"	for ( var i = 0; i < doc.rectangles.length; i++ ) { \n" +
				"		doc.rectangles[ i ].label = 'Not Made By Contact Sheet Script'; \n" +
				"	} \n" +
				"	sendBackStatus( 10, \"" + ContactSheet.strings.frames + "\" ); \n" +
				" 	for ( var i = ( pages.length - 1 ); i >= 0; i--){   \n" +
				"		var thisPage = pages.item( i );  \n" +
				"		var margins = thisPage.marginPreferences; \n" +
				"		var facingPagesHack = 0; \n" +
				"		if ( !config.useTemplate ) { \n" +
				" 			margins.top = config.pageSetup.margins.top; \n" +
				"			margins.bottom = config.pageSetup.margins.bottom; \n" +
				"			margins.left = config.pageSetup.margins.inside; \n" +
				"			margins.right = config.pageSetup.margins.outside; \n" +
				"			if ( config.pageSetup.facingPages ) { \n" +
				"				if ( i%2 == 1 ) { \n" +
				"					facingPagesHack = config.pageSetup.margins.outside; \n" +
				"				} else { \n" +
				"					facingPagesHack = config.pageSetup.margins.inside; \n" +
				"				} \n" +
				"			} else { \n" +
				"				facingPagesHack = margins.left; \n" +
				"			} \n" +
				"		} else { \n" +
				"			if ( doc.documentPreferences.facingPages ) { \n" +
				"				if ( i%2 == 1 ) { \n" +
				"					facingPagesHack = margins.right; \n" +
				"				} else { \n" +
				"					facingPagesHack = margins.left; \n" +
				"				} \n" +
				"			} else { \n" +
				"				facingPagesHack = margins.left; \n" +
				"			} \n" +
				"		} \n" +
				"		for ( var a = OLloop; a >= 1; a-- ){   \n" +
				"			var op1 = eval( OLp1 ); \n" +
				"			var op2 = eval( OLp2 ); \n" +
				" 			for ( var b = ILloop; b >= 1; b-- ){   \n" +
				"				var ip1 = eval( ILp1 );  \n" +
				"				var ip2 = eval( ILp2 ); \n" +
				"//				thisRect = eval( frameMaker );  \n" +
				"				thisRect = thisPage.rectangles.add(); \n" +
				"				thisRect.label = 'Made by Contact Sheet Script'; \n" +
				"				thisRect.move( undefined, ['1p', '1p'] ); \n" +
				"				thisRect.geometricBounds = eval( frameMaker ); \n" +
				"				thisRect.strokeWeight = 0; \n" +
				"//				thisRect.strokeColor = 'swatch'; \n" +
				"			} \n" +
				"		} \n" +
				"	} \n" +
				"// Because we constructed the frames in reverse order, rectangle 1   \n" +
				"// is the first rectangle on page 1, so we can simply iterate through   \n" +
				"// the rectangles, placing a file in each one in turn. \n" +
				"	var prog = 10; \n" +
				"   var inc = Math.round( 80 / config.files.length ); \n" +
				" 	var frameSkipper = 0; \n" +
				"	for ( var i = 0; i < config.files.length; i++){  \n" +
				"		aFile = config.files[ i ]; \n" +
				"		prog += inc; \n" +
				" 		sendBackStatus( prog, decodeURI( aFile.name ), undefined, true, \"" + ContactSheet.strings.placing + "\" ); \n" +
				"		var rect = doc.rectangles.item( i + frameSkipper );\n" +
				"		while ( rect.label != 'Made by Contact Sheet Script' ) { \n" +
				"			rect = doc.rectangles.item( i + ++frameSkipper ); \n" +
				"		}\n" +
				"		rect.applyObjectStyle( objectStyle, true ); \n" +
				"		var graphic = rect.place( aFile ); \n" +
				"		if ( config.rotate ) { \n" +
				"			var rHeight = rect.geometricBounds[2] - rect.geometricBounds[0]; \n" +
				"			var rWidth = rect.geometricBounds[3] - rect.geometricBounds[1]; \n" +
				"			var gHeight = graphic.geometricBounds[2] - graphic.geometricBounds[0]; \n" +
				"			var gWidth = graphic.geometricBounds[3] - graphic.geometricBounds[1]; \n" +	
				"			if ( rWidth > rHeight ) { \n" +
				"				if ( gWidth < gHeight ) { \n" +
				"					graphic.rotate( config.rotation ); \n" +
				"				} \n" +
				"			} else { \n" +
				"				if ( gWidth > gHeight ) { \n" +
				"					graphic.rotate( config.rotation ); \n" +
				"				} \n" +
				"			} \n" +
				"		} \n" +
				"		rect.label = aFile.fsName; \n" +
//				"		rect.label = aFile.name; \n" +
				"		rect.fit( FitOptions.proportionally ); \n" +
				"		rect.fit( FitOptions.centerContent ); \n" +
				"		//Add the label, if necessary. \n" +
				"		if( config.label ){  \n" +
				"			var x1 = rect.geometricBounds[1];  \n" +
				"			var y1 = rect.geometricBounds[2];  \n" +
				"			var x2 = rect.geometricBounds[3];  \n" +
				"			if ( config.overImages ) { \n" +
				"				var y2 = rect.geometricBounds[2] - config.overImageGap; \n" +
				"			} else { \n" +
				" 				var y2 = rect.geometricBounds[2] + config.verticalGap;  \n" +
				"			} \n" +
				" 			var str = ''; \n" +
				"			for ( var a = 0; a < config.caption.length; a++ ) { \n" +
				"				switch( config.caption[ a ] ){ \n" +
				" 					case 'filename' : \n" +
				"						str += decodeURI( aFile.name ); \n" +
				"						break; \n" +
				"					case 'fileinfo' : \n" +
				"						str += 'Size: ' + Math.round( aFile.length/1000 ) + ' KB'; \n" +
				"						break; \n" +
				"					case 'date' : \n" +
				"						str += aFile.modified; \n" +
				"						break; \n" +
				"				} \n" +
				"				str += String.fromCharCode( 10 ); \n" +
				"			} \n" +
				"			var tFrame = rect.parent.textFrames.add( labelLayer, undefined, undefined,{geometricBounds:[y1, x1, y2, x2], contents:str});  \n" +
				"			tFrame.textFramePreferences.firstBaselineOffset = FirstBaseline.leadingOffset;  \n" +
				"			tFrame.paragraphs.item( 0 ).appliedParagraphStyle = labelStyle;  \n" +
				"			tFrame.applyObjectStyle( captionObjectStyle, true ); \n" +
				"		}  \n" +
				"	}  \n" +
				"	if ( config.removeFrames ) { \n" +
				"		for (var i = ( doc.rectangles.length - 1 ); i >= 0; i--){   \n" +
				"			if ( doc.rectangles.item( i ).contentType == ContentType.unassigned){  \n" +
				"				doc.rectangles.item( i ).remove();  \n" +
				"			}   \n" +
				"			else{  \n" +
				"			//As soon as you encounter a rectangle with content, exit the loop.  \n" +
				"				break;  \n" +
				"			} \n" +
				"		}  \n" +
				" 	} \n" +
				"//	app.viewPreference.rulerOrigin = saveVP; \n" +
				"   if ( config.saveAsPDF ) { \n" +
				"		var PDFPreset = app.pdfExportPresets.item[ ContactSheet.config.PDFPreset ]; \n" +
				" 		sendBackStatus( 90, 'Exporting to PDF...'); \n" +
				"		doc.exportFile( ExportFormat.pdfType, config.output, false, PDFPreset ); \n" +
				"	} \n" +
				"	sendBackStatus( 100, \"" + ContactSheet.strings.complete + "\" ); \n" +
				"}  \n" +
				"ContactSheet.execute( ContactSheet.config ); \n";
				
// make things happen!
//	writeToFile( theScript );
	try {
		var bt = new BridgeTalkLongProcess( true, ContactSheet.strings.generating, ContactSheet.strings.contactSheet, false, "indesign", theScript );
		bt.send();
	} catch( e ) {
		alert( e );
	}
}
ContactSheet.getDialog = function( config )  {
	// first off, it helps to use "panel" objects instead of groups 
	// while you're actually working on a dialog. The panels are framed, and you can
	// see the actual grouping and alignment you are getting.
	var dlg = new Window( "dialog", ContactSheet.strings.contactSheet );
//	$.level = 1;
//	debugger;
	dlg.files = getBridgeFiles( TYPES.DEFAULT_CONTACTSHEET );
	dlg.orientation = "row"; 	// at the window level, I want two "groups", one to hold the 
							// all the "value entering" controls, and one to hold OK,CANCEL, etc
							// buttons in a vertical column on the right.
							
	dlg.alignChildren = "top"; 	// the default is center, you want both the value and button groups
								// at the top of the window
	
	dlg.val = dlg.add( "group" );	// this is the group that will hold all of the value stuff
	dlg.val.orientation = "column";
	
	dlg.btn = dlg.add( "group" );
	dlg.btn.orientation = "column";
	dlg.btn.spacing = 30; // in the button group, I want to have groups of buttons the first two will
						// always be OK, Cancel. But if you want to add a Page Setup, for example,
						// I want it to be an extra 10 pixels down from the Cancel button to differentiate
	
	dlg.layoutGroup = dlg.val.add( "panel", undefined, ContactSheet.strings.layout );
					// dlg.layoutGroup is the first visible element, a panel to hold the items common to layout
	
	dlg.layoutGroup.leftSideSubGroup = dlg.layoutGroup.add( "group" );
	// without this group, all of the top 3 items will be right justified in the panel. Since the panel is
	// pretty wide, it looks goofy. This contstrains the contents (3 static texts, 1 drop down, 2 edits)
	// and pushes them as close to the left edge of the layout panel as possible.
	// this fundamental problem is cause be having the Auto-Spacing check box and the other two edit boxes (which have to be
	// indented a little) in the same panel.
	
	dlg.layoutGroup.place = dlg.layoutGroup.leftSideSubGroup.add( "group" ); 
	dlg.layoutGroup.leftSideSubGroup.orientation = "column";		
	dlg.layoutGroup.leftSideSubGroup.alignChildren = "right";
	
	dlg.layoutGroup.place.stat = dlg.layoutGroup.place.add( "statictext", undefined, ContactSheet.strings.place );
	dlg.layoutGroup.place.place = dlg.layoutGroup.place.add( "dropdownlist" );// note the repeating pattern here for
//	dlg.layoutGroup.place.place.add( "item", ContactSheet.strings.acrossFirst);	// aligning captions with drop downs or edit boxes
//	dlg.layoutGroup.place.place.add( "item", ContactSheet.strings.downFirst );     // the next two code sections are almost identical
	
	dlg.layoutGroup.columns = dlg.layoutGroup.leftSideSubGroup.add( "group" );
	dlg.layoutGroup.columns.stat = dlg.layoutGroup.columns.add( "statictext", undefined, ContactSheet.strings.columns );
	dlg.layoutGroup.columns.columns = dlg.layoutGroup.columns.add( "edittext" );
	dlg.layoutGroup.columns.columns.preferredSize.width = 80;
	
	dlg.layoutGroup.rows = dlg.layoutGroup.leftSideSubGroup.add( "group" );
	dlg.layoutGroup.rows.stat = dlg.layoutGroup.rows.add( "statictext", undefined, ContactSheet.strings.rows );
	dlg.layoutGroup.rows.rows = dlg.layoutGroup.rows.add( "edittext" );
	dlg.layoutGroup.rows.rows.preferredSize.width = 80;

	dlg.layoutGroup.autoSpacing = dlg.layoutGroup.add( "checkbox", undefined, ContactSheet.strings.autoSpacing ); // here's the check box
	dlg.layoutGroup.autoSpacing.alignment = "left";

	dlg.layoutGroup.forAlignment = dlg.layoutGroup.add( "group" ); // analogous to dlg.layoutGroup.leftSideSubGroup

	dlg.layoutGroup.forAlignment.alignChildren = "right";
	dlg.layoutGroup.forAlignment.orientation = "column";
		
	dlg.layoutGroup.hGap = dlg.layoutGroup.forAlignment.add( "group" ); //and another repeating pattern
	dlg.layoutGroup.hGap.stat = dlg.layoutGroup.hGap.add( "statictext", undefined, ContactSheet.strings.horizGap );
	dlg.layoutGroup.hGap.edit = dlg.layoutGroup.hGap.add( "edittext" );
	dlg.layoutGroup.hGap.edit.preferredSize.width = 75;
	
	dlg.layoutGroup.vGap = dlg.layoutGroup.forAlignment.add( "group" );
	dlg.layoutGroup.vGap.stat = dlg.layoutGroup.vGap.add( "statictext", undefined, ContactSheet.strings.vertGap );
	dlg.layoutGroup.vGap.edit = dlg.layoutGroup.vGap.add( "edittext" );
	dlg.layoutGroup.vGap.edit.preferredSize.width = 75;
	dlg.layoutGroup.alignChildren = "left";
	dlg.layoutGroup.alignment = "fill";
	
	dlg.layoutGroup.rotGroup = dlg.layoutGroup.add( "group" );
	dlg.layoutGroup.rotGroup.orientation = "row";
	dlg.layoutGroup.rotGroup.alignChildren = "left";
	dlg.layoutGroup.rotGroup.rotate = dlg.layoutGroup.rotGroup.add( "checkbox", undefined, ContactSheet.strings.rotateForBestFit );
	dlg.layoutGroup.rotGroup.rotation = dlg.layoutGroup.rotGroup.add( "dropdownlist" );

	DialogUtilities.setupDropdown( dlg.layoutGroup.rotGroup.rotation, ContactSheet.rotation, config.rotation );
	dlg.layoutGroup.rotGroup.rotation.enabled = ContactSheet.config.rotate;
	dlg.layoutGroup.rotGroup.rotate.value = ContactSheet.config.rotate;
	dlg.layoutGroup.rotGroup.rotate.onClick = function() {
		this.parent.rotation.enabled = this.value;
		ContactSheet.config.rotate = this.value;
	}	
	dlg.layoutGroup.rotGroup.rotation.onChange = function() {
		if ( isValidReference( this.selection ) ) {
			ContactSheet.config.rotation = this.selection.text;
		}
	}
	
	
// set up initial values
	DialogUtilities.setupDropdown( dlg.layoutGroup.place.place, ContactSheet.places, ContactSheet.config.place );
	dlg.layoutGroup.columns.columns.text = config.colCount;
	dlg.layoutGroup.rows.rows.text = config.rowCount;
	dlg.layoutGroup.autoSpacing.value = config.autospace;
	dlg.layoutGroup.hGap.edit.text = config.horizontalGap;
	dlg.layoutGroup.vGap.edit.text = config.verticalGap;
// layoutGroup handlers
	dlg.layoutGroup.autoSpacing.onClick = function() {
		if ( dlg.layoutGroup.autoSpacing.value ) {
			dlg.layoutGroup.hGap.edit.enabled = false;
			dlg.layoutGroup.vGap.edit.enabled = false;
//			dlg.captionGroup.getCaptionBoxes();
		} else {
			dlg.layoutGroup.hGap.edit.enabled = true;
			dlg.layoutGroup.vGap.edit.enabled = true;
		}
		ContactSheet.config.autospace = dlg.layoutGroup.autoSpacing.value;
	}
	dlg.layoutGroup.columns.columns.onChange = function() {
		if ( isNaN( parseInt( this.text ) ) ) {
			this.text = ContactSheet.config.colCount;
			alert( ContactSheet.strings.columnAlert );
		} else if ( parseInt( this.text ) < 0 ) {
			this.text = ContactSheet.config.colCount;
			alert( ContactSheet.strings.columnAlertZero );
		} else {
			ContactSheet.config.colCount = parseInt( this.text );
			dlg.reportGroup.updateReport( );
		}
	}
	dlg.layoutGroup.rows.rows.onChange = function() {
		if ( isNaN( parseInt( this.text ) ) ) {
			this.text = ContactSheet.config.rowCount;
			alert( ContactSheet.strings.rowAlert );
		} else if ( parseInt( this.text ) < 0 ) {
			this.text = ContactSheet.config.rowCount;
			alert( ContactSheet.strings.rowAlertZero );
		} else {
			ContactSheet.config.rowCount = parseInt( this.text );
			dlg.reportGroup.updateReport();
		}
	}
	dlg.layoutGroup.vGap.edit.onChange = function() {
		var units = ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.INCHES ? " in" : " mm";
		if ( isNaN( parseFloat( this.text ) ) ) {
			this.text = parseFloat( ContactSheet.config.verticalGap ) + units;
			alert( ContactSheet.strings.vertAlert );
		} else if ( parseFloat( this.text ) < 0 ) {
			this.text = parseFloat( ContactSheet.config.verticalGap ) + units;
			alert( ContactSheet.strings.vertAlertZero );
		} else  {
			this.text = parseFloat( this.text ) + units;
		}
	}
	dlg.layoutGroup.hGap.edit.onChange = function() {
		var units = ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.INCHES ? " in" : " mm";
		if ( isNaN( parseFloat( this.text ) ) ) {
			this.text = parseFloat( ContactSheet.config.horizontalGap ) + units;
			alert( ContactSheet.strings.horizAlert );
		} else if ( parseFloat( this.text ) < 0 ) {
			this.text = parseFloat( ContactSheet.config.horizontalGap ) + units;
			alert( ContactSheet.strings.horizAlertZero );
		} else {
			this.text = parseFloat( this.text ) + units;
		}
	}


	dlg.captionGroup = dlg.val.add( "panel", undefined, localize( "$$$/WAS/ContactSheet/panelNameCaption=Caption" ) ); // all check boxes in this panel, talk about simple...
	dlg.captionGroup.overImages = dlg.captionGroup.add( "checkbox", undefined, ContactSheet.strings.placeOverImages );
	dlg.captionGroup.fileName = dlg.captionGroup.add( "checkbox", undefined, ContactSheet.strings.fileName );
	dlg.captionGroup.modificationDate = dlg.captionGroup.add( "checkbox", undefined, ContactSheet.strings.modDate );
	dlg.captionGroup.fileSize = dlg.captionGroup.add( "checkbox", undefined, ContactSheet.strings.fileSize );
	dlg.captionGroup.alignChildren = "left";
	dlg.captionGroup.alignment = "fill";

	dlg.captionGroup.setCaptionBoxes = function() {
		dlg.captionGroup.fileSize.value = false;
		dlg.captionGroup.fileName.value = false;
		dlg.captionGroup.modificationDate.value = false;
		dlg.captionGroup.overImages.value = ContactSheet.config.overImages;
		for ( var i = 0; i < ContactSheet.config.caption.length; i++ ) {
			switch( ContactSheet.config.caption[ i ] ) {
				case "filename" : {
					dlg.captionGroup.fileName.value = true;
					break;
				}
				case "date" : {
					dlg.captionGroup.modificationDate.value = true;
					break;
				}
				case "fileinfo" : {
					dlg.captionGroup.fileSize.value = true;
					break;
				}
			}
		}
	}
	dlg.captionGroup.getCaptionBoxes = function() {
		ContactSheet.config.caption = new Array();
		ContactSheet.config.overImages = dlg.captionGroup.overImages.value;
		if ( dlg.captionGroup.fileName.value ) {
			ContactSheet.config.caption.push( "filename" );
		}
		if ( dlg.captionGroup.modificationDate.value ) {
			ContactSheet.config.caption.push( "date" );
		}
		if ( dlg.captionGroup.fileSize.value ) {
			ContactSheet.config.caption.push( "fileinfo" );
		}	
		if ( dlg.layoutGroup.autoSpacing.value ) {
			if ( ContactSheet.config.caption.length == 0 ) {
				if ( ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.MILLIMETERS ) {
					dlg.layoutGroup.vGap.edit.text = ContactSheet.toMM( .125 ) + " mm";
					dlg.layoutGroup.hGap.edit.text = ContactSheet.toMM( .125 ) + " mm";
				} else {
					dlg.layoutGroup.hGap.edit.text = ".125 in";
					dlg.layoutGroup.vGap.edit.text = ".125 in";
				}
			} else {
				if ( ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.MILLIMETERS ) {
					if ( ContactSheet.config.overImages ) {
						dlg.layoutGroup.vGap.edit.text = ContactSheet.toMM( .125 ) + " mm";
						ContactSheet.config.overImageGap = ContactSheet.toMM( .25 * ContactSheet.config.caption.length );
					} else {
						dlg.layoutGroup.vGap.edit.text = ContactSheet.toMM( .25 * ContactSheet.config.caption.length ) + " mm";
					}
					dlg.layoutGroup.hGap.edit.text = ContactSheet.toMM( .125 ) + " mm";
				} else {
					dlg.layoutGroup.hGap.edit.text = ".125 in";
					if ( ContactSheet.config.overImages ) {
						dlg.layoutGroup.vGap.edit.text = ".125 in";
						ContactSheet.config.overImageGap = .25 * ContactSheet.config.caption.length;
					} else {
						dlg.layoutGroup.vGap.edit.text = .25 * ContactSheet.config.caption.length + " in";
					}
				}
			}
		}
	}
	dlg.captionGroup.overImages.onClick = function() {
		dlg.captionGroup.getCaptionBoxes();
	}
	dlg.captionGroup.fileName.onClick = function() {
		dlg.captionGroup.getCaptionBoxes();
	}
	dlg.captionGroup.modificationDate.onClick = function() {
		dlg.captionGroup.getCaptionBoxes();
	}
	dlg.captionGroup.fileSize.onClick = function() {
		dlg.captionGroup.getCaptionBoxes();
	}
	dlg.captionGroup.setCaptionBoxes();
	dlg.templateGroup = dlg.val.add( "panel", undefined, localize( "$$$/WAS/ContactSheet/templPanelText=Template" ) );
	dlg.templateGroup.alignment = "fill";
	dlg.templateGroup.btnGroup = dlg.templateGroup.add( "group" );
	dlg.templateGroup.btnGroup.alignment = "fill";
	dlg.templateGroup.btnGroupL = dlg.templateGroup.btnGroup.add( "group" );
	dlg.templateGroup.btnGroupR = dlg.templateGroup.btnGroup.add( "group" );
	dlg.templateGroup.btnGroupL.alignChildren = "left";
	dlg.templateGroup.btnGroupR.alignChildren = "right";
	dlg.templateGroup.btnGroupR.alignment = "fill";
	dlg.templateGroup.useTemplate = dlg.templateGroup.btnGroupL.add( "checkbox", undefined, localize( "$$$/WAS/ContactSheet/useIDTemplate=Use InDesign Template" ) );
	dlg.templateGroup.getTemplate = dlg.templateGroup.btnGroupR.add( "button", undefined, localize( "$$$/WAS/ContactSheet/templButton=Template..." ) );
	dlg.templateGroup.fileSpec = dlg.templateGroup.add( "edittext" );
	dlg.templateGroup.fileSpec.preferredSize = [300,20];
	dlg.templateGroup.fileSpec.alignment = "fill";
	dlg.templateGroup.useTemplate.fileSpecEdit = dlg.templateGroup.fileSpec;
	dlg.templateGroup.useTemplate.getTemplateButton = dlg.templateGroup.getTemplate;
	dlg.templateGroup.useTemplate.value = config.useTemplate;
	dlg.templateGroup.getTemplate.fileSpecEdit = dlg.templateGroup.fileSpec;
	if ( ContactSheet.config.useTemplate ) {
		if ( isValidReference( ContactSheet.config.templateFile ) ) {
			dlg.templateGroup.fileSpec.text = File.decode( ContactSheet.config.templateFile.fsName );
		} else {
			dlg.templateGroup.fileSpec.text = "";
			ContactSheet.config.useTemplate = false;
			dlg.templateGroup.useTemplate.value = false;
		}
	}
	dlg.templateGroup.useTemplate.onClick = function() {
		ContactSheet.config.useTemplate = this.value;
		this.fileSpecEdit.enabled = this.value;
		this.getTemplateButton.enabled = this.value;
		dlg.pageSetupGroup.pageSetup.enabled = !this.value;
		if ( this.value ) {
			if ( dlg.outputGroup.saveAsPDF.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.outputGroup.outputFile.text ) && !isEmpty( this.fileSpecEdit.text );
			} else {
				dlg.buttonGroup.okButton.enabled = !isEmpty( this.fileSpecEdit.text );
			}
		} else {
			if ( dlg.outputGroup.saveAsPDF.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.outputGroup.outputFile.text );
			} else {
				dlg.buttonGroup.okButton.enabled = true;
			}
		}
	}
	ContactSheet.checkMacFile = function( file ) {
		if ( file instanceof Folder ) {
			return true;
		} 
		return file.isFileType( "INDT,INDD," );
	}
	dlg.templateGroup.getTemplate.onClick = function() {
		if ( File.fs == "Windows" ) {
			var templateFile = File.openDialog( localize( "$$$/WAS/ContactSheet/selectTemplFile=Select the Template File" ), "InDesign Files:*.indt;*.indd" );
		} else {
			var templateFile = File.openDialog( localize( "$$$/WAS/ContactSheet/selectTemplFile=Select the Template File" ), ContactSheet.checkMacFile );			
		}
		if ( isValidReference( templateFile ) ) {
			this.fileSpecEdit.text = decodeURI( templateFile.fsName );
			ContactSheet.config.templateFile = templateFile;
			if ( dlg.outputGroup.saveAsPDF.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.outputGroup.outputFile.text );
			} else {
				dlg.buttonGroup.okButton.enabled = true;
			}
		} else {
			this.fileSpecEdit.text = "";
			dlg.buttonGroup.okButton.enabled = false;
			ContactSheet.config.templateFile = undefined;
		}
	}
	dlg.outputGroup = dlg.val.add( "panel", undefined, ContactSheet.strings.outputOptions );
	dlg.outputGroup.format = dlg.outputGroup.add( "group" );
	dlg.outputGroup.format.alignment = "fill";
	dlg.outputGroup.formatL = dlg.outputGroup.format.add( "group" );
	dlg.outputGroup.formatR = dlg.outputGroup.format.add( "group" );
	dlg.outputGroup.formatR.alignment = "fill";
	dlg.outputGroup.formatL.alignChildren = "left";
	dlg.outputGroup.formatR.alignChildren = "right";
	dlg.outputGroup.saveAsPDF = dlg.outputGroup.formatL.add( "checkbox", undefined, localize( "$$$/WAS/ContactSheet/saveAsPDFCkBox=Save As PDF" ) );	
	dlg.outputGroup.outputFileBtn = dlg.outputGroup.formatR.add( "button", undefined, ContactSheet.strings.OutputFile );
	dlg.outputGroup.outputFile = dlg.outputGroup.add( "edittext" );
	dlg.outputGroup.outputFile.alignment = "fill";
	dlg.outputGroup.alignment = "fill";
	dlg.outputGroup.orientation = "column";
	dlg.outputGroup.presetStat = dlg.outputGroup.add( "statictext", undefined, "                                                                    " );
	ContactSheet.presetStat = dlg.outputGroup.presetStat;

	dlg.outputGroup.saveAsPDF.outputEdit = dlg.outputGroup.outputFile;
	dlg.outputGroup.saveAsPDF.getOutputFileButton = dlg.outputGroup.outputFileBtn;
	dlg.outputGroup.saveAsPDF.onClick = function() {
		if ( this.value ) {
			ContactSheet.showPDFDialog();
		}
		ContactSheet.config.saveAsPDF = this.value;
		this.outputEdit.enabled = this.value;
		this.getOutputFileButton.enabled = this.value;
		if ( this.value ) {
			if ( dlg.templateGroup.useTemplate.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.outputGroup.outputFile.text ) && !isEmpty( dlg.templateGroup.fileSpec.text );
			} else {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.outputGroup.outputFile.text );
			}
		} else {
			if ( dlg.templateGroup.useTemplate.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.templateGroup.fileSpec.text );
			} else {
				dlg.buttonGroup.okButton.enabled = true;
			}
		}
	}
	ContactSheet.checkMacFilePDF = function( file ) {
		if ( file instanceof Folder ) {
			return true;
		}
		return file.isFileType( TYPES.PDF );
	}
	dlg.outputGroup.outputFileBtn.onClick = function() {
		if ( File.fs == "Windows" ) {
			var f = File.saveDialog( ContactSheet.strings.fileCaption,  "PDF Files:*.pdf" );
		} else {
			var f = File.saveDialog( ContactSheet.strings.fileCaption, ContactSheet.checkMacFilePDF );			
		}
//		var f = File.openDialog( ContactSheet.strings.fileCaption );
		if ( isValidReference( f ) ) {
			dlg.outputGroup.outputFile.text = decodeURI( f.fsName );
			if ( dlg.templateGroup.useTemplate.value ) {
				dlg.buttonGroup.okButton.enabled = !isEmpty( dlg.templateGroup.fileSpec.text );
			} else {
				dlg.buttonGroup.okButton.enabled = true;
			}
			ContactSheet.config.output = f;
		} else {
			dlg.outputGroup.outputFile.text = "";
			dlg.buttonGroup.okButton.enabled = false;
			ContactSheet.config.output = undefined;
		}
	}
	
	// in the reportGroup, I wanted to have everything lined up to a specific point. The captions right
	// justified, the values left. The longest caption determines the location of that point.
	// So I made two columnar groups, and put the captions and values in different columns.
	// This works because I have statictext in both columns. It Does NOT work in something like the layout panel
	// because the vertical sizes are different between edit boxes and statictext
	dlg.reportGroup = dlg.val.add( "panel", undefined, ContactSheet.strings.report );
	dlg.reportGroup.orientation = "row";
	dlg.reportGroup.spacing = 2;
	dlg.reportGroup.alignment = "fill";
	dlg.reportGroup.reportText = dlg.reportGroup.add( "group" );
	dlg.reportGroup.reportText.orientation = "column";
	dlg.reportGroup.reportValues = dlg.reportGroup.add( "group" );
	dlg.reportGroup.reportValues.orientation = "column";
	dlg.reportGroup.reportValues.spacing = 2;
	dlg.reportGroup.reportText.spacing = 2;
	dlg.reportGroup.reportText.alignChildren =  "right";
	dlg.reportGroup.reportValues.alignChildren = "fill";
	dlg.reportGroup.reportText.stat = dlg.reportGroup.reportText.add( "statictext", undefined, ContactSheet.strings.imagesSelected + ":        " );
	dlg.reportGroup.reportValues.images = dlg.reportGroup.reportValues.add( "statictext", undefined, "100" );
//	dlg.reportGroup.reportValues.images.preferredSize = [40,13];
	dlg.reportGroup.reportText.stat = dlg.reportGroup.reportText.add( "statictext", undefined, ContactSheet.strings.imagesPerPage + ":       " );
	dlg.reportGroup.reportValues.imagesPerPage = dlg.reportGroup.reportValues.add( "statictext", undefined, "100" );
//	dlg.reportGroup.reportValues.imagesPerPage.preferredSize = [40,13];
	dlg.reportGroup.reportText.stat = dlg.reportGroup.reportText.add( "statictext", undefined, ContactSheet.strings.pagesInSheet + ":        " );
	dlg.reportGroup.reportValues.pagesPerSheet = dlg.reportGroup.reportValues.add( "statictext", undefined, "100" );
//	dlg.reportGroup.reportValues.pagesPerSheet.preferredSize = [40,13];
	
	// this is the OK/Cancel button group
	dlg.buttonGroup = dlg.btn.add( "group", undefined );
	dlg.buttonGroup.preferredSize.width = 100;
	dlg.buttonGroup.orientation = "column";
	dlg.buttonGroup.okButton = dlg.buttonGroup.add( "button", undefined, ContactSheet.strings.okButton );
	dlg.buttonGroup.okButton.window = dlg;
	dlg.buttonGroup.cancelButton = dlg.buttonGroup.add( "button", undefined, ContactSheet.strings.cancelButton );
	dlg.buttonGroup.cancelButton.window = dlg;
	dlg.buttonGroup.okButton.onClick = function() {
		this.window.close( 1 );
	}
	dlg.buttonGroup.cancelButton.onClick = function() {
		this.window.close( 2 );
	}
	// this is a second button group with Page Setup and Files
	// because we set spacing to 30, this group will show up 30 pixels below the cancel button
	dlg.pageSetupGroup = dlg.btn.add( "group" );
	dlg.pageSetupGroup.pageSetup = dlg.pageSetupGroup.add( "button", undefined, ContactSheet.strings.pageSetupButton );
	dlg.pageSetupGroup.files = dlg.pageSetupGroup.add( "button", undefined, ContactSheet.strings.inputFiles );
	dlg.pageSetupGroup.preferredWidth = 100;
	dlg.pageSetupGroup.orientation = "column";

	dlg.outputGroup.outputFileBtn.okButton = dlg.pageSetupGroup.okButton;
	
	
	dlg.reportGroup.updateReport = function( extend ) {
//		debugger;
		var fileCount = 0;
		for ( var i = 0; i < dlg.files.length; i++ ) {
			if ( dlg.files[ i ] instanceof File ) {
				fileCount++
			}
		}
		var imagesPerPage = parseInt( dlg.layoutGroup.columns.columns.text ) * parseInt( dlg.layoutGroup.rows.rows.text );
		var pageCount = Math.round( fileCount / imagesPerPage );
		if ( ( pageCount * imagesPerPage ) < fileCount ) { 
			pageCount++; // handle round off error
		}
		var spacer = "";
		if ( extend ) {
			spacer = "              ";
		}
		dlg.reportGroup.reportValues.images.text = new String( fileCount ) + spacer;
		dlg.reportGroup.reportValues.imagesPerPage.text = imagesPerPage + spacer;
		dlg.reportGroup.reportValues.pagesPerSheet.text = pageCount + spacer;	
	}
	dlg.pageSetupGroup.files.onClick = function() {
		var settings = new FileSetDialog.Settings( true, ContactSheet.strings.contactSheet, "*" );
		var w = getParentWindow( this );
		settings.addFilter( ContactSheet.strings.filterPS, "TYPES.PHOTOSHOP" );
		settings.addFilter( ContactSheet.strings.contactSheet, "TYPES.DEFAULT_CONTACTSHEET" );
//$.level = 1;
//debugger;
		var files = FileSetDialog.show( settings );
		if ( isValidReference( files ) ) {
//		debugger;
			w.files = files.getFileList();
//			this.parent.parent.outputSettings.sampleFile = this.parent.parent.files[ 0 ];
//			this.parent.parent.files = files.getFileList( true );

			w.reportGroup.updateReport( );
		}
	}
	dlg.pageSetupGroup.pageSetup.onClick = function() {
		var d = ContactSheet.getPageSetupDialog( dlg.layoutGroup.vGap.edit, dlg.layoutGroup.hGap.edit );
	  	var okClicked = d.show() == 1 ? true : false;
		if ( okClicked )  {
			with ( ContactSheet.config.pageSetup ) {
				measurementUnits = d.units.selection.text;
				initialUnits = d.units.selection.text;
				ContactSheet.config.pageSetup.units = ContactSheet.measurementUnits.get( d.units.selection.text );
				pageSize = d.pageGroup.pageSize.selection.text;
				width = parseFloat( d.pageGroup.width.text );
				height = parseFloat( d.pageGroup.height.text );
				facingPages = d.pageGroup.facingPages.value;
				margins.top = parseFloat( d.marginGroup.top.text );
				margins.bottom = parseFloat( d.marginGroup.bottom.text );
				margins.inside = parseFloat( d.marginGroup.inside.text );
				margins.outside = parseFloat( d.marginGroup.outside.text );
				if ( d.pageGroup.portrait.value ) {
					orientation = ContactSheet.strings.orientPortrait;
				} else {
					orientation = ContactSheet.strings.orientLandscape;
				}
			}
		}
	}
	dlg.layoutGroup.autoSpacing.onClick();
	dlg.templateGroup.useTemplate.onClick();
	dlg.outputGroup.saveAsPDF.onClick();
	
	dlg.reportGroup.updateReport( true );

	dlg.center();

	return dlg;
}
ContactSheet.getPageSetupDialog = function( vGapControl, hGapControl )  {
	var dlg = new Window( "dialog", ContactSheet.strings.pageSetup ); 
//	debugger;
	dlg.parentVerticalGapControl = vGapControl;
	dlg.parentHorizontalGapControl = hGapControl;
	dlg.orientation = "row";
	var contentGroup = dlg.add( "group" );
	var btnGroup = dlg.add( "group" );
	dlg.orientation = "row";
	dlg.alignChildren = "left";
	
	contentGroup.orientation = "column";
	contentGroup.alignChildren = "left";
	dlg.unitsGroup = contentGroup.add( "group" );
	dlg.unitsStat = dlg.unitsGroup.add( "statictext", undefined, ContactSheet.strings.units );
	dlg.unitsStat.justify = "right";	
	dlg.units = dlg.unitsGroup.add( "dropdownlist" );
	DialogUtilities.setupDropdown( dlg.units, ContactSheet.measurementUnits, ContactSheet.config.pageSetup.measurementUnits );
	
	dlg.setVerticalGap = function() {
		if ( ContactSheet.config.autospace ) {
			if ( ContactSheet.config.caption.length == 0 ) {
				if ( ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.MILLIMETERS ) {
					dlg.parentHorizontalGapControl.text = ContactSheet.toMM( .125 ) + " mm";
					dlg.parentVerticalGapControl.text = ContactSheet.toMM( .125 ) + " mm";
				} else {
					dlg.parentHorizontalGapControl.text = ".125 in";
					dlg.parentVerticalGapControl.text = ".125 in";
				}
			} else {
				if ( ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.MILLIMETERS ) {
					dlg.parentHorizontalGapControl.text = ContactSheet.toMM( .125 ) + " mm";
					dlg.parentVerticalGapControl.text = ContactSheet.toMM( .25 * ContactSheet.config.caption.length ) + " mm";
				} else {
					dlg.parentHorizontalGapControl.text = ".125 in";
					dlg.parentVerticalGapControl.text = .25 * ContactSheet.config.caption.length + " in";
				}
			}
		} else {
			ContactSheet.convertControl( dlg.parentVerticalGapControl );
			ContactSheet.convertControl( dlg.parentHorizontalGapControl );
		}
	}
	dlg.units.onChange = function() {
//		debugger;
		if ( isValidReference( dlg.units.selection ) ) {
			ContactSheet.config.pageSetup.measurementUnits = dlg.units.selection.text;
		}
		try {
			if ( !isNaN( parseFloat( dlg.pageGroup.width.text ) ) ) {
				ContactSheet.convertControl( dlg.pageGroup.width );
			}
			if ( !isNaN( parseFloat( dlg.pageGroup.height.text ) ) ) {
				ContactSheet.convertControl( dlg.pageGroup.height );
			}
			ContactSheet.convertControl( dlg.marginGroup.top );
			ContactSheet.convertControl( dlg.marginGroup.bottom );
			ContactSheet.convertControl( dlg.marginGroup.inside );
			ContactSheet.convertControl( dlg.marginGroup.outside );
			dlg.setVerticalGap();
		} catch ( e ) {
			alert( e );
		} finally {
			if ( isValidReference( dlg.units.selection ) ) {
				ContactSheet.config.pageSetup.initialUnits = dlg.units.selection.text;
			} else {
				ContactSheet.config.pageSetup.initialUnits = ContactSheet.config.pageSetup.measurementUnits;
			}
		}		
	}
	
	dlg.pageGroup = contentGroup.add( "panel", undefined, ContactSheet.strings.pageSize );
	dlg.pageGroup.alignment = "fill";
	dlg.pageGroup.orientation = "row";
	dlg.pageGroup.alignChildren = "right";

	dlg.pageGroup.left = dlg.pageGroup.add( "group" );
	dlg.pageGroup.left.orientation = "column";
	dlg.pageGroup.left.alignChildren = "right";
	
	dlg.pageGroup.left.pSize = dlg.pageGroup.left.add( "group" );
	dlg.pageGroup.pageSizeStat = dlg.pageGroup.left.pSize.add( "statictext", undefined, ContactSheet.strings.pageSize );
	dlg.pageGroup.pageSize = dlg.pageGroup.left.pSize.add( "dropdownlist" );
	DialogUtilities.setupDropdown( dlg.pageGroup.pageSize, ContactSheet.pageSizes, ContactSheet.config.pageSetup.pageSize );
	
	dlg.pageGroup.widthGroup = dlg.pageGroup.left.add( "group" );
	dlg.pageGroup.wStat = dlg.pageGroup.widthGroup.add( "statictext", undefined, ContactSheet.strings.pageWidth );
	dlg.pageGroup.wStat.justify = "right";
	dlg.pageGroup.width = dlg.pageGroup.widthGroup.add( "edittext" );
	dlg.pageGroup.width.preferredSize = [80,20];

	dlg.pageGroup.heightGroup = dlg.pageGroup.left.add( "group" );
	dlg.pageGroup.heightGroup.alignChildren = "right";
	dlg.pageGroup.hStat = dlg.pageGroup.heightGroup.add( "statictext", undefined, ContactSheet.strings.pageHeight );
	dlg.pageGroup.hStat.justify = "right";	
	dlg.pageGroup.height = dlg.pageGroup.heightGroup.add( "edittext" );
	dlg.pageGroup.height.preferredSize = [80,20];

	dlg.pageGroup.right = dlg.pageGroup.add( "group" );
	dlg.pageGroup.right.orientation = "column";
	dlg.pageGroup.right.alignChildren = "left";
	dlg.pageGroup.portrait = dlg.pageGroup.right.add( "radiobutton", undefined, ContactSheet.strings.portrait );
	dlg.pageGroup.landscape = dlg.pageGroup.right.add( "radiobutton", undefined, ContactSheet.strings.landscape );
	
	if ( ContactSheet.config.pageSetup.orientation == ContactSheet.strings.orientPortrait ) {
		dlg.pageGroup.portrait.value = true;
	} else {
		dlg.pageGroup.landscape.value = true;
	}
	dlg.pageGroup.currentOrientation = ContactSheet.config.pageSetup.orientation;
	dlg.pageGroup.width.text = ContactSheet.config.pageSetup.width;
	dlg.pageGroup.width.savedValue = ContactSheet.config.pageSetup.width;
	dlg.pageGroup.height.text = ContactSheet.config.pageSetup.height;
	dlg.pageGroup.height.savedValue = ContactSheet.config.pageSetup.height;
	dlg.pageGroup.height.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	dlg.pageGroup.width.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	
	dlg.pageGroup.portrait.onClick = function() {
		if ( dlg.pageGroup.currentOrientation == ContactSheet.strings.orientLandscape ) {
			var h = dlg.pageGroup.height.text;
			var w = dlg.pageGroup.width.text;
			dlg.pageGroup.height.text = w;
			dlg.pageGroup.width.text = h;	
		}
		dlg.pageGroup.currentOrientation = ContactSheet.strings.orientPortrait;
//		dlg.pageGroup.setPageDimensions();
	}
	dlg.pageGroup.landscape.onClick = function() {
		if ( dlg.pageGroup.currentOrientation == ContactSheet.strings.orientPortrait ) {
			var h = dlg.pageGroup.height.text;
			var w = dlg.pageGroup.width.text;
			dlg.pageGroup.height.text = w;
			dlg.pageGroup.width.text = h;	
		}
		dlg.pageGroup.currentOrientation = ContactSheet.strings.orientLandscape;
//		dlg.pageGroup.setPageDimensions();
	}
	dlg.pageGroup.pageSize.onChange = function() {
		dlg.pageGroup.setPageDimensions();
	}
	dlg.pageGroup.setPageDimensions = function() {
//debugger;
		var sel = ContactSheet.strings.pageSizeLetter;
		if ( isValidReference( dlg.pageGroup.pageSize.selection ) ) {
			var sel = dlg.pageGroup.pageSize.selection.text;
		}
		var	dim = ContactSheet.pageSizes.get( sel );
		if ( isValidReference( dim ) ) {
			var h = dim.horizontal;
			var v = dim.vertical;
//			if ( isValidReference( dlg.pageGroup.orientation.selection ) ) {
			if ( dlg.pageGroup.landscape.value ) {
//				if ( dlg.pageGroup.orientation.selection.text == "Landscape" ) {
					var h = dim.vertical;
					var v = dim.horizontal;
//				}
			}
			if ( dim.units == ContactSheet.strings.MILLIMETERS ) {
				if ( ContactSheet.config.pageSetup.initialUnits != ContactSheet.strings.MILLIMETERS ) {
					dlg.units.selection = 1;
					ContactSheet.config.pageSetup.measurementUnits = ContactSheet.strings.MILLIMETERS;
					dlg.units.onChange();
				}
			} else {
				if ( ContactSheet.config.pageSetup.initialUnits != ContactSheet.strings.INCHES ) {
					dlg.units.selection = 0;
					ContactSheet.config.pageSetup.measurementUnits = ContactSheet.strings.INCHES;
					dlg.units.onChange();
				}
			}
			dlg.pageGroup.height.text = v;
			dlg.pageGroup.width.text = h;
			dlg.pageGroup.width.savedValue = h;
			dlg.pageGroup.height.savedValue = v;
			dlg.pageGroup.height.savedUnits = ContactSheet.config.pageSetup.measurementUnits;
			dlg.pageGroup.width.savedUnits = ContactSheet.config.pageSetup.measurementUnits;
			
		}	
	}
	dlg.pageGroup.facingPages = dlg.pageGroup.left.add( "checkbox", undefined, ContactSheet.strings.facingPages );
	dlg.pageGroup.facingPages.value = ContactSheet.config.pageSetup.facingPages;
//	dlg.pageGroup.facingPages.value = false;
//	dlg.pageGroup.facingPages.visible = false;
// Note, ContactSheet.enableFacingPagesCheckBox is set in line 25 to make turning
// this on and off easier while the ID bug exists
	dlg.pageGroup.facingPages.enabled = ContactSheet.enableFacingPagesCheckBox;
	dlg.pageGroup.facingPages.onClick = function() {
		if ( dlg.pageGroup.facingPages.value ) {
			dlg.marginGroup.iStat.text = ContactSheet.strings.insideMargin + ":";
			dlg.marginGroup.oStat.text = ContactSheet.strings.outsideMargin + ":";
		} else {
			dlg.marginGroup.iStat.text = "      " + ContactSheet.strings.leftMargin + ":";
			dlg.marginGroup.oStat.text = "      " + ContactSheet.strings.rightMargin + ":";
		}
	}
	
	dlg.marginGroup = contentGroup.add( "panel",undefined, ContactSheet.strings.margins );
	dlg.marginGroup.alignment = "fill";
	dlg.marginGroup.orientation = "row";
	dlg.marginGroup.leftGroup = dlg.marginGroup.add( "group" );
	dlg.marginGroup.leftGroup.orientation = "column";
	dlg.marginGroup.leftGroup.alignChildren = "right";
	
	dlg.marginGroup.topGroup = dlg.marginGroup.leftGroup.add( "group" );
	dlg.marginGroup.tStat = dlg.marginGroup.topGroup.add( "statictext", undefined, ContactSheet.strings.topMargin + ":" );
	dlg.marginGroup.tStat.justify = "right";
	dlg.marginGroup.top = dlg.marginGroup.topGroup.add( "edittext" );
	dlg.marginGroup.top.preferredSize = [80,20];
	dlg.marginGroup.top.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	dlg.marginGroup.top.savedValue = ContactSheet.config.pageSetup.margins.top;


	dlg.marginGroup.botGroup = dlg.marginGroup.leftGroup.add( "group" );
	dlg.marginGroup.bStat = dlg.marginGroup.botGroup.add( "statictext", undefined, ContactSheet.strings.bottomMargin + ":" );
	dlg.marginGroup.bStat.justify = "right";
	dlg.marginGroup.bottom = dlg.marginGroup.botGroup.add( "edittext" );
	dlg.marginGroup.bottom.preferredSize = [80,20];
	dlg.marginGroup.bottom.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	dlg.marginGroup.bottom.savedValue = ContactSheet.config.pageSetup.margins.bottom;
	
	dlg.marginGroup.rightGroup = dlg.marginGroup.add( "group" );
	dlg.marginGroup.rightGroup.orientation = "column";
	dlg.marginGroup.rightGroup.alignChildren = "right";
	dlg.marginGroup.inGroup = dlg.marginGroup.rightGroup.add( "group" );
	dlg.marginGroup.iStat = dlg.marginGroup.inGroup.add( "statictext", undefined, ContactSheet.strings.insideMargin + ":" );
	dlg.marginGroup.iStat.justify = "right";
	dlg.marginGroup.inside = dlg.marginGroup.inGroup.add( "edittext" );
	dlg.marginGroup.inside.preferredSize = [80,20];
	dlg.marginGroup.inside.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	dlg.marginGroup.inside.savedValue = ContactSheet.config.pageSetup.margins.inside;

	
	dlg.marginGroup.outGroup = dlg.marginGroup.rightGroup.add( "group" );
	dlg.marginGroup.oStat = dlg.marginGroup.outGroup.add( "statictext", undefined, ContactSheet.strings.outsideMargin + ":" );
	dlg.marginGroup.oStat.justify = "right";
	dlg.marginGroup.outside = dlg.marginGroup.outGroup.add( "edittext" );
	dlg.marginGroup.outside.preferredSize = [80,20];
	dlg.marginGroup.outside.savedUnits =  ContactSheet.config.pageSetup.measurementUnits;
	dlg.marginGroup.outside.savedValue = ContactSheet.config.pageSetup.margins.outside;
	
	
	dlg.pageGroup.facingPages.onClick();
	dlg.marginGroup.top.text = ContactSheet.config.pageSetup.margins.top;
	dlg.marginGroup.bottom.text = ContactSheet.config.pageSetup.margins.bottom;
	dlg.marginGroup.inside.text = "       " + ContactSheet.config.pageSetup.margins.inside;
	dlg.marginGroup.outside.text = "        " + ContactSheet.config.pageSetup.margins.outside;

	dlg.goodToClose = true;
	dlg.closeTime = new Date();

	dlg.validateNumber = function( control, min, max ) {
		if ( isNaN( parseFloat( control.text ) ) ) {
			control.text = control.savedValue;
//			alert( str + " " + ContactSheet.strings.mustBeNumber );
	dlg.goodToClose = false;
	dlg.closeTime = new Date();
				ContactSheet.convertControl( control );
				
				return false;
		}
		if ( isValidReference( min ) ) {
			if ( parseFloat( control.text ) < min ) {
				control.text = control.savedValue;
				ContactSheet.convertControl( control );
//				alert( str + " " + ContactSheet.strings.mustBeGreaterThan + " " + min );
	dlg.goodToClose = false;
	dlg.closeTime = new Date();
				return false;
			}
		}
		if ( isValidReference( max ) ) {
			if ( parseFloat( control.text ) > max ) {
				control.text = control.savedValue;
				ContactSheet.convertControl( control );
//				alert( str + " " + ContactSheet.strings.mustBeLessThan + " " + max );
	dlg.goodToClose = false;
	dlg.closeTime = new Date();
				return false;
			}
		}
//		alert( "ret: " + ret );
		ContactSheet.convertControl( control );
	dlg.goodToClose = true;
		return true;
	}
	dlg.marginGroup.top.onChange = function() {
		dlg.validateNumber( this, 0, parseFloat( dlg.pageGroup.height.text ) );
	}
	dlg.marginGroup.bottom.onChange = function() {
		dlg.validateNumber( this, 0,  parseFloat( dlg.pageGroup.height.text ) );
	}
	dlg.marginGroup.inside.onChange = function() {
		dlg.validateNumber( this, 0,  parseFloat( dlg.pageGroup.width.text ) );
	}
	dlg.marginGroup.outside.onChange = function() {
		dlg.validateNumber( this, 0,  parseFloat( dlg.pageGroup.width.text ) );
	}
	dlg.pageGroup.width.onChange = function() {
		var min = 0.1667;
		var max = 216;
		if ( ContactSheet.config.pageSetup.measurementUnits != ContactSheet.strings.INCHES ) {
			min = ContactSheet.toMM( min );
			max = ContactSheet.toMM( max );
		}
		dlg.validateNumber( this, min , max );
	}
	dlg.pageGroup.height.onChange = function() {	
		var min = 0.1667;
		var max = 216;
		if ( ContactSheet.config.pageSetup.measurementUnits != ContactSheet.strings.INCHES ) {
			min = ContactSheet.toMM( min );
			max = ContactSheet.toMM( max );
		}
		dlg.validateNumber( this, min, max );
	}

	dlg.onClose = function() {
		var temp = dlg.goodToClose;
		if ( !temp ) {
			var t = new Date();
			temp = ( ( t - dlg.closeTime ) > 250 );
		}
		dlg.goodToClose = true;
		return temp;
	}
	dlg.pageGroup.setPageDimensions();
	
	dlg.okBtnGroup = dlg.add( "group" );
	dlg.okBtnGroup.orientation = "column";
	dlg.okBtnGroup.okBtn = dlg.okBtnGroup.add( "button", undefined, ContactSheet.strings.okButton );
	dlg.okBtnGroup.okBtn.enabled = true;
	dlg.okBtnGroup.cancelBtn = dlg.okBtnGroup.add( "button", undefined, ContactSheet.strings.cancelButton );
	dlg.okBtnGroup.cancelBtn.onClick = function() {
		dlg.close( 2 ); 
	}
	dlg.okBtnGroup.okBtn.onClick = function() {
		dlg.close( 1 );
	}

	dlg.center();
	return dlg;
}
// set up localization strings

ContactSheet.strings.accept = localize( "$$$/WAS/ContactSheet/accept=InDesign has accepted the job" );
ContactSheet.strings.frames = localize( "$$$/WAS/ContactSheet/frames=Creating Image Frames" );
ContactSheet.strings.placing = localize( "$$$/WAS/ContactSheet/placing=Placing Image" );
ContactSheet.strings.complete = localize( "$$$/WAS/ContactSheet/complete=Complete" );
ContactSheet.strings.generating = localize( "$$$/WAS/ContactSheet/generating=Generating Contact Sheet" );
ContactSheet.strings.contactSheet = localize( "$$$/WAS/ContactSheet/cd=Contact Sheet" );
ContactSheet.strings.contactSheetMenu = localize( "$$$/WAS/ContactSheet/menu=Create InDesign Contact Sheet" );
ContactSheet.strings.dialogTitle = localize( "$$$/WAS/ContactSheet/dtitle=Create Contact Sheet (InDesign)" );
ContactSheet.strings.place = localize( "$$$/WAS/ContactSheet/place=Place:" );
ContactSheet.strings.columns = localize( "$$$/WAS/ContactSheet/cols=Columns:" );
ContactSheet.strings.layout = localize( "$$$/WAS/ContactSheet/layout=Layout" );
ContactSheet.strings.rows = localize( "$$$/WAS/ContactSheet/rows=Rows:" );
ContactSheet.strings.autoSpacing = localize( "$$$/WAS/ContactSheet/auto=Auto-Spacing" );
ContactSheet.strings.horizGap = localize( "$$$/WAS/ContactSheet/horiz=Horizontal Gap:" );
ContactSheet.strings.vertGap = localize( "$$$/WAS/ContactSheet/vert=Vertical Gap:" );
ContactSheet.strings.columnAlert = localize( "$$$/WAS/ContactSheet/colint=Columns must be an integer" );
ContactSheet.strings.rowAlert = localize( "$$$/WAS/ContactSheet/rowint=Rows must be an integer" );
ContactSheet.strings.vertAlert = localize( "$$$/WAS/ContactSheet/vertreal=Vertical Gap must be a number" );
ContactSheet.strings.horizAlert = localize( "$$$/WAS/ContactSheet/horizreal=Horizontal Gap must be a number" );
ContactSheet.strings.columnAlertZero = localize( "$$$/WAS/ContactSheet/colintz=Columns must be greater than zero" );
ContactSheet.strings.rowAlertZero = localize( "$$$/WAS/ContactSheet/rowintz=Rows must be greater than zero" );
ContactSheet.strings.vertAlertZero = localize( "$$$/WAS/ContactSheet/vertrealz=Vertical Gap must be greater than zero" );
ContactSheet.strings.horizAlertZero = localize( "$$$/WAS/ContactSheet/horizrealz=Horizontal Gap must be greater than zero" );
ContactSheet.strings.caption = localize( "$$$/WAS/ContactSheet/caption=Caption" );
ContactSheet.strings.fileName = localize( "$$$/WAS/ContactSheet/fileName=File Name" );
ContactSheet.strings.modDate = localize( "$$$/WAS/ContactSheet/modDate=Modification Date" );
ContactSheet.strings.fileSize = localize( "$$$/WAS/ContactSheet/filesize=File Size" );
ContactSheet.strings.output = localize( "$$$/WAS/ContactSheet/output=Output" );
ContactSheet.strings.format = localize( "$$$/WAS/ContactSheet/format=Format:" );
ContactSheet.strings.outputFile = localize( "$$$/WAS/ContactSheet/outputFile=Output File" );
ContactSheet.strings.fileCaption = localize( "$$$/WAS/ContactSheet/selectOutput=Select the Contact Sheet Output File:");
ContactSheet.strings.report = localize( "$$$/WAS/ContactSheet/report=Report" );
ContactSheet.strings.imagesSelected = localize( "$$$/WAS/ContactSheet/numImages=Number of Images Selected" );
ContactSheet.strings.imagesPerPage = localize( "$$$/WAS/ContactSheet/imagesPerpage=Number of Images per Page" );
ContactSheet.strings.pagesInSheet = localize( "$$$/WAS/ContactSheet/numPages=Number of Pages" );
ContactSheet.strings.okButton = localize( "$$$/WAS/ContactSheet/ok=OK" );
ContactSheet.strings.cancelButton = localize( "$$$/WAS/ContactSheet/can=Cancel" );
ContactSheet.strings.pageSetupButton = localize( "$$$/WAS/ContactSheet/pageSetup=Page Setup..." );
ContactSheet.strings.pageSetup = localize( "$$$/WAS/ContactSheet/pageSetup2=Page Setup" );
ContactSheet.strings.units = localize( "$$$/WAS/ContactSheet/units=Units:" );
ContactSheet.strings.pageSize = localize( "$$$/WAS/ContactSheet/pageSize=Page Size:" );
ContactSheet.strings.pageWidth = localize( "$$$/WAS/ContactSheet/width=Width:" );
ContactSheet.strings.pageHeight = localize( "$$$/WAS/ContactSheet/ht=Height:" );
ContactSheet.strings.portrait = localize( "$$$/WAS/ContactSheet/portrait=Portrait" );
ContactSheet.strings.landscape = localize( "$$$/WAS/ContactSheet/landscape=Landscape" );
ContactSheet.strings.widthNumber = localize( "$$$/WAS/ContactSheet/widthnum=Width must be a non-zero positive number" );
ContactSheet.strings.heightNumber = localize( "$$$/WAS/ContactSheet/htnum=Height must be a non-zero positive number" );
ContactSheet.strings.facingPages = localize( "$$$/WAS/ContactSheet/facing=Facing Pages" );
ContactSheet.strings.insideMargin = localize( "$$$/WAS/ContactSheet/inside=Inside" );
ContactSheet.strings.outsideMargin = localize( "$$$/WAS/ContactSheet/outside=Outside" );
ContactSheet.strings.topMargin = localize( "$$$/WAS/ContactSheet/top=Top" );
ContactSheet.strings.bottomMargin = localize( "$$$/WAS/ContactSheet/bottom=Bottom" );
ContactSheet.strings.rightMargin = localize( "$$$/WAS/ContactSheet/right=Right" );
ContactSheet.strings.leftMargin = localize( "$$$/WAS/ContactSheet/left=Left" );
ContactSheet.strings.margins = localize( "$$$/WAS/ContactSheet/margins=Margins" );
ContactSheet.strings.mustBeNumber = localize( "$$$/WAS/ContactSheet/marginnum=Margin must be a number" );
ContactSheet.strings.contactSheet = localize( "$$$/WAS/ContactSheet/css2=Contact Sheet" );
ContactSheet.strings.acrossFirst = localize( "$$$/WAS/ContactSheet/acrossfirst=Across First" );
ContactSheet.strings.acrossFirstLower = localize( "$$$/WAS/ContactSheet/acFirst=across first" );
ContactSheet.strings.downFirst = localize( "$$$/WAS/ContactSheet/downFirst=Down First" );
ContactSheet.strings.downFirstLower = localize( "$$$/WAS/ContactSheet/dnFirst=down first" );
ContactSheet.strings.overwrite = localize( "$$$/WAS/ContactSheet/overwrite= already exists, overwrite?" );
ContactSheet.strings.cancelledByUser = localize( "$$$/WAS/ContactSheet/cancelled=Contact Sheet execution cancelled by user" );
ContactSheet.strings.rotateForBestFit = localize( "$$$/WAS/ContactSheet/rotateBestFit=Rotate Image for best fit" );
ContactSheet.strings.placeOverImages = localize( "$$$/WAS/ContactSheet/placeOver=Place over Images" );
ContactSheet.strings.outputOptions = localize( "$$$/WAS/ContactSheet/outputOptions=Output Options" );
ContactSheet.strings.OutputFile = localize( "$$$/WAS/ContactSheet/outputFile2=Output File..." );
ContactSheet.strings.inputFiles = localize( "$$$/WAS/ContactSheet/files=Files..." );
ContactSheet.strings.mustBeGreaterThan = localize( "$$$/WAS/ContactSheet/greaterThan=must be greater than" );
ContactSheet.strings.mustBeLessThan = localize( "$$$/WAS/ContactSheet/lessThan=must be less than" );
ContactSheet.strings.orientPortrait = localize( "$$$/WAS/ContactSheet/orientPortrait=Portrait" );
ContactSheet.strings.orientLandscape = localize( "$$$/WAS/ContactSheet/orientLandscape=Landscape" );
ContactSheet.strings.Clockwise = localize( "$$$/WAS/ContactSheet/CW=Clockwise" );
ContactSheet.strings.CounterClockwise = localize( "$$$/WAS/ContactSheet/CCW=Counter-Clockwise" );
ContactSheet.strings.idDocx = localize( "$$$/WAS/ContactSheet/idDocx=InDesign Document" );
ContactSheet.strings.pdfDocx = localize( "$$$/WAS/ContactSheet/pdfDocx=PDF Document" );
ContactSheet.strings.filterPS = localize( "$$$/WAS/ContactSheet/filterPS=Photoshop" );
ContactSheet.strings.filterAI = localize( "$$$/WAS/ContactSheet/filterAI=Illustrator" );
ContactSheet.strings.filterDEF = localize( "$$$/WAS/ContactSheet/filterDEF=Default" );
ContactSheet.strings.filterPSALL = localize( "$$$/WAS/ContactSheet/filterPSALL=Photoshop - All" );
ContactSheet.strings.filterAIALL = localize( "$$$/WAS/ContactSheet/filterAIALL=Illustrator - All" );
ContactSheet.strings.filterPDF = localize( "$$$/WAS/ContactSheet/filterPDF=PDF" );
ContactSheet.strings.pageSizeA4 = localize( "$$$/WAS/ContactSheet/pageSizeA4=A4" );
ContactSheet.strings.pageSizeA5 = localize( "$$$/WAS/ContactSheet/pageSizeA5=A5" );
ContactSheet.strings.pageSizeLetter = localize( "$$$/WAS/ContactSheet/pageSizeLetter=Letter" );
ContactSheet.strings.pageSizeLegal = localize( "$$$/WAS/ContactSheet/pageSizeLegal=Legal" );
ContactSheet.strings.INCHES = localize( "$$$/WAS/ContactSheet/INCHES=Inches" );
ContactSheet.strings.MILLIMETERS = localize( "$$$/WAS/ContactSheet/MILLIMETERS=Millimeters" );


ContactSheet.outputDrop = undefined;
// set up configuration objects
ContactSheet.config = {};
ContactSheet.config.rotate = false;
ContactSheet.config.rotation = ContactSheet.strings.Clockwise;
ContactSheet.config.files = new Array( 0 );
ContactSheet.config.fileTypePreset = ContactSheet.strings.filterDEF;
ContactSheet.config.output = undefined;
ContactSheet.config.PDFPreset = undefined;
ContactSheet.config.useTemplate = false;
ContactSheet.config.templateFile = undefined;
ContactSheet.config.saveAsPDF = false;
ContactSheet.config.makeNewFile = false;
ContactSheet.config.saveNewFile = false;
ContactSheet.config.rowCount = 4;
ContactSheet.config.colCount = 3;
ContactSheet.config.autospace = true; 
if ( app.locale == "en_US" ) { 
	ContactSheet.config.verticalGap = ".25 in";
	ContactSheet.config.horizontalGap = ".125 in";
} else {
	ContactSheet.config.verticalGap = "6.35 mm";
	ContactSheet.config.horizontalGap = "3.175 mm";
}ContactSheet.config.removeFrames = true;
ContactSheet.config.recursive = true;
ContactSheet.config.filter = ContactSheet.strings.filterDEF;
ContactSheet.config.label = true;
ContactSheet.config.labelStyle = 1;
ContactSheet.config.caption = new Array();
ContactSheet.config.caption.push( "filename" );
ContactSheet.config.overImages = false;
ContactSheet.config.overImageGap = 0;
ContactSheet.config.format = ContactSheet.strings.idDocx;
ContactSheet.config.place = ContactSheet.strings.acrossFirstLower;

if ( app.locale == "en_US" ) {
	ContactSheet.config.pageSetup = {};
	ContactSheet.config.pageSetup.measurementUnits = ContactSheet.strings.INCHES;
	ContactSheet.config.pageSetup.initialUnits = ContactSheet.strings.INCHES;
	ContactSheet.config.pageSetup.units = "MeasurementUnits.INCHES_DECIMAL"; // or mm
	ContactSheet.config.pageSetup.pageSize = ContactSheet.strings.pageSizeLetter; // see ContactSheet.pageSizes Hashtable
	ContactSheet.config.pageSetup.width = "8.5 in";
	ContactSheet.config.pageSetup.height = "11 in";
	ContactSheet.config.pageSetup.facingPages = false;
	ContactSheet.config.pageSetup.margins = {};
	ContactSheet.config.pageSetup.margins.top = ".5 in";
	ContactSheet.config.pageSetup.margins.bottom = ".5 in";
	ContactSheet.config.pageSetup.margins.inside = ".5 in";
	ContactSheet.config.pageSetup.margins.outside = ".5 in";
	ContactSheet.config.pageSetup.orientation = ContactSheet.strings.orientPortrait;
} else {
	ContactSheet.config.pageSetup = {};
	ContactSheet.config.pageSetup.measurementUnits = ContactSheet.strings.MILLIMETERS;
	ContactSheet.config.pageSetup.initialUnits = ContactSheet.strings.MILLIMETERS;
	ContactSheet.config.pageSetup.units = "MeasurementUnits.MILLIMETERS";
	ContactSheet.config.pageSetup.pageSize = ContactSheet.strings.pageSizeA4 // see ContactSheet.pageSizes Hashtable
	ContactSheet.config.pageSetup.width = "210 mm";
	ContactSheet.config.pageSetup.height = "297 mm";
	ContactSheet.config.pageSetup.facingPages = false;
	ContactSheet.config.pageSetup.margins = {};
	ContactSheet.config.pageSetup.margins.top = "12.7 mm";
	ContactSheet.config.pageSetup.margins.bottom = "12.7 mm";
	ContactSheet.config.pageSetup.margins.inside = "12.7 mm";
	ContactSheet.config.pageSetup.margins.outside = "12.7 mm";
	ContactSheet.config.pageSetup.orientation = ContactSheet.strings.orientPortrait;
}


// cuppla utility functions
ContactSheet.toMM = function( inches ) {
	return inches * 25.4;
}
ContactSheet.toIN = function( mm ) {
	return mm / 25.4;
}
ContactSheet.convertControl = function( control ) {
	control.text = ContactSheet.convert( control.text, control.savedUnits );
	control.savedUnits = ContactSheet.config.pageSetup.measurementUnits;
	control.savedValue = control.text;
}
ContactSheet.convert = function( val, oUnits ) {
	var origUnits = isValidReference( oUnits ) ? oUnits : ContactSheet.config.pageSetup.initialUnits;
	var ret = parseFloat( val );
	if ( isNaN( ret ) ) {
		return;
	}
	var units = ContactSheet.config.pageSetup.measurementUnits == ContactSheet.strings.INCHES ? " in" : " mm";
	if ( ContactSheet.config.pageSetup.measurementUnits != origUnits ) {
		var ret = units == " in" ? ContactSheet.toIN( ret ) : ContactSheet.toMM( ret );
		if ( new String( ret ).length > 3 ) {
			ret = ContactSheet.round( ret, 3 );
		}
	}
	return ret + units;
}
ContactSheet.round = function( aNumber, toDecimalPlaces ) {
	if ( toDecimalPlaces == 0 ) {
		return Math.round( aNumber );
	} else {
		return ( Math.round( ( aNumber * 10 * toDecimalPlaces ) ) / ( 10 * toDecimalPlaces ) );
	}
}
// more configuration stuff
ContactSheet.orientations = new Hashtable( true );
ContactSheet.orientations.put( ContactSheet.strings.orientPortrait, ContactSheet.strings.orientPortrait );
ContactSheet.orientations.put( ContactSheet.strings.orientLandscape, ContactSheet.strings.orientLandscape );

ContactSheet.rotation = new Hashtable( true );
ContactSheet.rotation.put( ContactSheet.strings.Clockwise, ContactSheet.strings.Clockwise );
ContactSheet.rotation.put( ContactSheet.strings.CounterClockwise, ContactSheet.strings.CounterClockwise );


ContactSheet.formats = new Hashtable( true );
ContactSheet.formats.put( ContactSheet.strings.idDocx, "indd" );
ContactSheet.formats.put( ContactSheet.strings.pdfDocx, "pdf" );

ContactSheet.places = new Hashtable( true );
ContactSheet.places.put( ContactSheet.strings.acrossFirst, ContactSheet.strings.acrossFirstLower );
ContactSheet.places.put( ContactSheet.strings.downFirst, ContactSheet.strings.downFirstLower );

ContactSheet.fileFilters = new Hashtable( true );
ContactSheet.fileFilters.put( ContactSheet.strings.filterPS, "TYPES.PHOTOSHOP" );
ContactSheet.fileFilters.put( ContactSheet.strings.filterAI, "TYPES.ILLUSTRATOR" );
ContactSheet.fileFilters.put( ContactSheet.strings.filterDEF, "TYPES.DEFAULT_CONTACTSHEET" );
ContactSheet.fileFilters.put( ContactSheet.strings.filterPSALL, "TYPES.PHOTOSHOP_OPENABLE" );
ContactSheet.fileFilters.put( ContactSheet.strings.filterAIALL, "TYPES.ILLUSTRATOR_OPENABLE" );
ContactSheet.fileFilters.put( ContactSheet.strings.filterPDF, "TYPES.PDF" );

ContactSheet.measurementUnits = new Hashtable( true );
ContactSheet.measurementUnits.put( ContactSheet.strings.INCHES, "MeasurementUnits.INCHES_DECIMAL" );
ContactSheet.measurementUnits.put( ContactSheet.strings.MILLIMETERS, "MeasurementUnits.MILLIMETERS" );
ContactSheet.pageSize = function( txt, hor, vert, unit ) {
	this.display = txt;
	this.horizontal = hor;
	this.vertical = vert;
	this.units = unit;
}

ContactSheet.margins = function( top, bottom, inside, outside ) {
	this.inside = inside;
	this.outside = outside;
	this.top = top;
	this.bottom = bottom;
}

ContactSheet.pageSizes = new Hashtable( true );
ContactSheet.pageSizes.put( ContactSheet.strings.pageSizeA4, new ContactSheet.pageSize( ContactSheet.strings.pageSizeA4, "210 mm", "297 mm", ContactSheet.strings.MILLIMETERS ) );
ContactSheet.pageSizes.put( ContactSheet.strings.pageSizeA5, new ContactSheet.pageSize( ContactSheet.strings.pageSizeA5, "148 mm", "210 mm", ContactSheet.strings.MILLIMETERS ) );
ContactSheet.pageSizes.put( ContactSheet.strings.pageSizeLetter, new ContactSheet.pageSize( ContactSheet.strings.pageSizeLetter, "8.5 in", "11 in", ContactSheet.strings.INCHES ) );
ContactSheet.pageSizes.put( ContactSheet.strings.pageSizeLegal, new ContactSheet.pageSize( ContactSheet.strings.pageSizeLegal, "8.5 in", "14 in", ContactSheet.strings.INCHES ) );


ContactSheet.showPDFDialog = function()  {
	var d = ContactSheet.buildPDFDialog();
	d.center();
  	var okClicked = d.show() == 1 ? true : false;
	if ( !okClicked )  {
		ContactSheet.outputDrop.selection = ContactSheet.strings.idDocx
		ContactSheet.presetStat.text = "";
	} else {
		ContactSheet.presetStat.text = localize( "$$$/WAS/ContactSheet/usingpdfpreset=Using PDF Preset: " ) + ContactSheet.config.PDFPreset;
	}
}
ContactSheet.storePDFPresets = function( btObj ) {
	ContactSheet.PDFPresets = eval( btObj.body );
	ContactSheet.setPDFPresets();
}
ContactSheet.setPDFPresets = function() {
	for ( var i = 0; i < ContactSheet.PDFPresets.length; i++ ) {
		var newItem = ContactSheet.presetList.add( "item", ContactSheet.PDFPresets[ i ] );
	}	
	ContactSheet.PDFStatus.text = localize( "$$$/WAS/ContactSheet/selectpdfPresetUse=Select the PDF Preset to use:" );
	BridgeTalk.bringToFront( "bridge" );
}
ContactSheet.getPDFPresets = function()  {
	var theScript = "var presets = app.pdfExportPresets; \n" +
								"var pString = new Array(); \n" +
								"for ( var i = 0; i < presets.length; i++ ) { \n" +
								"   pString.push( presets.item( i ).name ); \n" +
								"} \n" +
								"pString = pString.toSource();"
	sendBridgeTalkMessage( "indesign", theScript, ContactSheet.storePDFPresets );
	BridgeTalk.bringToFront( "bridge" );
}

ContactSheet.buildPDFDialog = function( control )  {

	var dlg = new Window( "dialog", ContactSheet.strings.dialogTitleID );

  	dlg.orientation = "row"; 	// at the window level, I want two "groups", one to hold the 
						// all the "value entering" controls, and one to hold OK,CANCEL, etc
						// buttons in a vertical column on the right.
	dlg.alignChildren = "top"; 	// the default is center, you want both the value and button groups
							// at the top of the window

	dlg.vGroup = dlg.add( "group" );	// this is the group that will hold all of the value stuff
	dlg.vGroup.orientation = "column";
	dlg.vGroup.alignChildren = "top";

	dlg.bGroup = dlg.add( "group" );
	dlg.bGroup.orientation = "column";
	dlg.bGroup.spacing = 30; // in the button group, I want to have groups of buttons the first two will
					// always be OK, Cancel. But if you want to add a Page Setup, for example,
					// I want it to be an extra 10 pixels down from the Cancel button to differentiate	

// this is the OK/Cancel button group
	dlg.bGroup.okGroup = dlg.bGroup.add( "group", undefined );
	dlg.bGroup.okGroup.preferredSize.width = 100;
	dlg.bGroup.okGroup.orientation = "column";
	dlg.bGroup.okGroup.okButton = dlg.bGroup.okGroup.add( "button", undefined, ContactSheet.strings.okButton );
	
	dlg.bGroup.okGroup.cancelButton = dlg.bGroup.okGroup.add( "button", undefined, ContactSheet.strings.cancelButton );
	
	dlg.bGroup.okGroup.okButton.onClick = function() {
		dlg.close( 1 );
	}
	dlg.bGroup.okGroup.cancelButton.onClick = function() {
		dlg.close( 2 );
	}

	dlg.vGroup.status = dlg.vGroup.add( "statictext", undefined, localize( "$$$/WAS/ContactSheet/getpdfpresetfromID=Getting PDF Presets from InDesign" ), { multiline:true } );
//	dlg.vGroup.status.preferredSize = [350,20];
	ContactSheet.PDFStatus = dlg.vGroup.status;
	
	dlg.vGroup.fileGroup = dlg.vGroup.add( "panel", undefined, ContactSheet.strings.availPresets );
	dlg.vGroup.fileGroup.preferredSize = [350,400];
	dlg.vGroup.fileGroup.fileList = dlg.vGroup.fileGroup.add( "listbox",undefined ,undefined, { multiselect: false} );
	ContactSheet.presetList = dlg.vGroup.fileGroup.fileList;
	dlg.vGroup.fileGroup.fileList.okButton = dlg.bGroup.okGroup.okButton;
	dlg.vGroup.fileGroup.fileList.preferredSize = [350,400];
	dlg.vGroup.fileGroup.fileList.onChange = function() {
		if ( isValidReference( this.selection ) ) {
			ContactSheet.config.PDFPreset = this.selection.text;
			this.okButton.enabled = true;
		} else {
			this.okButton.enabled = false;
		}
	}
	dlg.onShow = function() {
		sendBridgeTalkMessage( "bridge", "12", ContactSheet.getPDFPresets ); // effectively creates a new thread to get the presets
		BridgeTalk.bringToFront( "bridge" );
	}
	dlg.bGroup.okGroup.okButton.enabled = false;
	dlg.center();
	return dlg;
}

ContactSheet.strings.dialogTitleID = localize( "$$$/WAS/ContactSheet/dtitle2=Select InDesign PDF Preset" );
ContactSheet.strings.availPresets = localize( "$$$/WAS/ContactSheet/availpresets=Available Presets" );
ContactSheet.strings.okButton = localize( "$$$/WAS/ContactSheet/presetok=OK" );
ContactSheet.strings.cancelButton = localize( "$$$/WAS/ContactSheet/presetcancel=Cancel" );


// set up menu
	createGenericMenus();		
	createMenu( "command", ContactSheet.strings.contactSheetMenu, "at the end of tools/id", "tools/id/contact", ContactSheet.showDialog, undefined, TYPES.DEFAULT_CONTACTSHEET );

	try {
		ScriptManager.reportLoading( ContactSheet.scriptInfo );	
	} catch ( e ) {
	}
}
