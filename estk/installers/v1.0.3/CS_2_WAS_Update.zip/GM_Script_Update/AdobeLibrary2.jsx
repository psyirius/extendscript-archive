#target bridge
//----------------------------------------------------------------------- 
//
// ADOBE SYSTEMS INCORPORATED
// (c)Copyright 2004-2005 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE: Adobe permits you to use, modify, and distribute
// this file in accordance with the terms of the Adobe license
// agreement accompanying it. If you have received this file
// from a source other than Adobe, then your use, modification,
// or distribution of it requires the prior written permission
// of Adobe.
//
//----------------------------------------------------------------------- 
// <asm:name>Adobe Library 2</asm:name>
// <asm:description>This file contains a persitent storage mechansim for any scripter to use.</asm:description>
// <asm:help>None, for developers only</asm:help>
// <asm:author>Bob Stucky</asm:author>
// <asm:company>Adobe Systems, Inc.</asm:company>
// <asm:copyright>(c) Copyright 2004, 2005 Adobe Systems Incorporated, all rights reserved</asm:copyright>
// <asm:version>0.5.8</asm:version>
// <asm:date>07-14-2005</asm:date>
// <asm:website>http://www.adobe.com</asm:website>
//----------------------------------------------------------------------- 

if ( BridgeTalk.appName == "bridge" ) {
	$.level = 0;
	var ScriptStore =  {};	

//--------------------------------------------------------------------
// ScriptStore is a persistent store for anything your script wants to 
// store between sessions. All ScriptStore does is safely write your
// data to disk and retrieve it for you. This is not recommended or
// certified to store objects; however, if you're going to try it, make
// sure your objects are one level deep ( class definitions that contain
// other objects do not have the child objects written in toSource()  ), 
// store them with the toSource() method, and eval() the retrieved value.
// But even then, it still might not work for a variety of reasons.
//
// WARNING: There is no transaction management in ScriptStore. Use at your
// own risk. Critical data should not be written to ScriptStore or any
// data persistence object that does not support transaction integrity.
//
//--------------------------------------------------------------------
// Usage: Create a new store for your script by executing:
//
// ScriptStore.createStore( id ); 
//
// Your script id should be something
// that will not be duplicated. I suggest using a definition something
// like: adobeBatchApplyMetaData. If there is a name collision with any other script
// running on the user's machine, creation of your store will fail with an error
// message indicating a conflict with a prior script.
// 
// Once your script has a store, open it.
//
// var store = ScriptStore.open( id );
//
// Store id's must be simple character strings. No punctuation, brackets, <>, =, slashes, or spaces allowed.
// Rule of thumb, all characters MUST be in a-z, A-Z, and 0-9, with no spaces.
// 
// Note, attempting to open a store that does not exist will create one and return
// it to you. 
//
// You can remove an entire store with:
// ScriptStore.removeStore( id );
//
// ScriptStore is an XML store. There are a couple of methods that manage the
// XML structure for you for simple data types (name-value and collection).
//
// Once you have the store:
// var store = ScriptStore.open( scriptId );
// use:
// store.put( type, name, value ); to store simple name-value pairs. Note that
// "type" is only a classification rule to make this more useful. Using different
// types allows you to store data with the same name.
// 
// Look below, "type" becomes an xml tag. That means "type" cannot contain any
// spaces, or characters other than alphanumeric. No special characters including
// punctuation, <>, etc.
//
// store.put( "metadata", "Fred", "Flinstone" );
// This creates an xml structure like:
// <metadata>
//  <member name="Fred">Flintstone</member>
// </metadata>
// 
// Doing it again:
// store.put( "metadata", "Barney", "Rubble" );
//
// yields:
// <metadata>
//  <member name="Fred">Flintstone</member>
//  <member name="Barney">Rubble</member>
// </metadata>
// 
// Attempting to overwrite does exactly that.
// store.put( "metadata", "Barney", "Fife" );
//
// yields:
// <metadata>
//  <member name="Fred">Flintstone</member>
//  <member name="Barney">Fife</member>
// </metadata>
// 
// You can remove a "type" of data with:
// store.removeType( type ); <- be careful, this could eliminate a LOT of data
//
// You can remove a single data element with:
// store.removeElement( type, name );
//
// To get simple data:
// var x = store.get( "metadata", "Barney" ); returns "Fife"
//
// A collection of data is essentially a collection of name-value pairs.
// To store a collection, create a Hashtable() object (class definition is
// in library file AdobeLibrary1.jsx).
// From there, it's the same:
//
// var ht = new Hashtable();
// ht.put( "Fred", "Flintstone" );
// ht.put( "Barney", "Rubble" );
// store.putCollection( "metadata", "toons", ht );
// yields:
// <metadata>
//	<member name="toons">
//   <element name="Fred">Flintstone</element>
//   <element name="Barney">Rubble</element>
//	</member>
// </metadata>
//
// var ht = store.getCollection( "metadata", "toons" );
// var a = ht.get( "Barney" ); yields "Rubble"
//
//	Removing a type of data will remove a type that contains collections.
//  Overwriting a collection of data does a replacement of all elements.
//  Removing a single element of a collection requires removing it from the Hashtable,
//  and then saving it again.
//
// There is also primitive access to the XML Nodes themselves. With the primitives,
// You store and retrieve data by finding xml nodes, and then
// operating on them, you are responsible for the structure of your XML data.
// ScriptStore defines an root object for each store. It's the starting point
// for all operations. To get the root node:
//
// var root = store.root;
// 
// Then to add a node,
//
// var node = root.addNode( name, value );
// or to save a line of code...
// var node = store.root.addNode( name, value );
// 
// once you have a node, you can add attributes or change the value:
//
// node.addAttribute( name );
// var attr = node.getAttribute( name );
//
// node.setValue( val );
// var val = node.getValue();
//
// to add a node in an existing structure, first thing you do is FIND the parent
//
// var node = store.findNode( nodeName );
// finds the first node of a given name
//
// var node = store.findNode( nodeName, 3 );
// finds the 4th node of that name (it's zero indexed, like arrays)
//
// var nodes = store.findNodes( nodeName );
// finds all nodes of that name, returned in an array
// 
// every node has the findNode/findNodes methods, so you can vector in
// to the element you want fairly easily.
//
// Once you find the right node, use addNode( name, value );
// And you can add attributes:
// node.addAttribute( name, value );
//
// When you are done making changes,
// store.save(); 
//
// Once you open a store, so long as you save changes, you do not have to
// close the store.
//
// Sorry, ScriptStore does not allow you to execute searches based on the 
// value of whatever you are storing... Hey, this is JavaScript...
//--------------------------------------------------------------------
// COMMAND FUNCTIONS
//--------------------------------------------------------------------
	ScriptStore.store = null;
	ScriptStore.findNodeCount = 0;
	ScriptStore.open = function( id ) {
		if ( contains( id, " " ) ) {
			throw localize( "$$$/WAS/Store/err1=Invalid store name. Store Names cannot contain spaces" );
		}
		if ( ScriptStore.store == null ) {
			ScriptStore.loadScriptStore();
		}
		var scriptNode = ScriptStore.store.findNode( id );
		if ( !isValidReference( scriptNode ) ) { // script's store does not exist
			var store = ScriptStore.create( id );
			var scriptsNode = ScriptStore.store.findNode( "scripts", 0 );
			if ( !isValidReference( scriptsNode ) ) {
				ScriptStore.createConfigFile();
				scriptsNode = ScriptStore.store.findNode( "scripts", 0 );
				if ( !isValidReference( scriptsNode ) ) {
					throw localize( "$$$/WAS/Store/err2=ScriptStore is experiencing difficulty" );
				}
			}
			var scriptNode = scriptsNode.addChildNode( id, store.filePath );
			ScriptStore.store.save();
			return store;
		} else {
			var fPath = scriptNode.getValue();
			var store = "";
			f = new File( fPath );
			if ( !f.exists ) {
//				throw localize( "$$$/WAS/Store/err3=Error Reading Storage Information: File Not Found" );
// next stuff is an attempt at a gracefule recovery
				try {
					ScriptStore.removeStore( id );
					store = ScriptStore.create( id, undefined, true );	
					var scriptsNode = ScriptStore.store.findNode( id, 0 );
					if ( !isValidReference( scriptsNode ) ) {
						ScriptStore.createConfigFile();
						scriptsNode = ScriptStore.store.findNode( "scripts", 0 );
						if ( !isValidReference( scriptsNode ) ) {
							throw localize( "$$$/WAS/Store/err2=ScriptStore is experiencing difficulty" );
						}
						var scriptNode = scriptsNode.addChildNode( id, store.filePath );
					} else {
						scriptNode.setValue( store.filePath );
					}
					ScriptStore.store.save();
				} catch ( e ) {
					store = {};
					store.isHosed = true;
				}
			} else {
// else is added as a part of the fix;
				var storeRoot = ScriptStore.parse( f );
				store = new ScriptStore.Store( f.fsName, storeRoot );
				store.isHosed = false;
			}
			return store;
		}
	}
	ScriptStore.create = function( id, fileName, force ) {
		if ( contains( id, " " ) ) {
			throw localize( "$$$/WAS/Store/err4=Invalid store name. Store Names cannot contain spaces" );
		}
		if ( ScriptStore.store == null ) {
			ScriptStore.loadScriptStore();
		}
		if ( isValidReference( ScriptStore.store.root.findNode( id ) ) ) {
			if ( !force ) {
				throw localize( "$$$/WAS/Store/err5=Script name is in conflict with a prior script" );
			}
		}
		var num = Math.round( Math.random() * 150000000 );
		var fName = Folder.userData+ "/Adobe/ScriptStore/ss" + num + ".xml";
		var fp = isValidReference( fileName ) ? fileName : fName;
		var f = new File( fp );
		while ( f.exists ) {
			var num = Math.random() * 150000000;
			var fName = Folder.userData + "/Adobe/ScriptStore/ss" + num + ".xml";
			var f = new File( fName );
		}
		var root = new ScriptStore.XmlNode( "document" );
		root.addAttribute( "version", "1.0" );
		root.addAttribute( "encoding", "iso-8859-1" );
		var store = new ScriptStore.Store( f.fsName, root );
		store.save();
		return store;		
	}
//--------------------------------------------------------------------
// UTILITIES
//--------------------------------------------------------------------
	ScriptStore.removeStore = function( id ) {
		if ( ScriptStore.store == null ) {
			ScriptStore.loadScriptStore();
		}
		var scriptNode = ScriptStore.store.findNode( id );
		if ( !isValidReference( scriptNode ) ) { // script's store does not exist
			throw localize( "$$$/WAS/Store/err6=Store: " ) + id + localize( "$$$/WAS/Store/err7= does not exist" );
		} else {
			var fPath = scriptNode.getValue();
			f = new File( fPath );
			if ( !f.exists ) {
//				throw localize( "$$$/WAS/Store/err8=Error Removing Storage Information: File Not Found" );
			} else {
				var sNode = ScriptStore.store.findNode( "scripts" );
				f.remove();
				var kids = sNode.nodeChildren;
				for ( var i = 0; i < kids.length; i++ ) {
					if ( equalsIgnoreCase( kids[ i ].tag, scriptNode.tag ) ) {
						sNode.nodeChildren = arrayRemove( kids, i );
						ScriptStore.store.save();
						return;
					}
				}
			}
		}
	}
	ScriptStore.loadScriptStore = function( ) {
		var f = new File( Folder.userData + "/Adobe/ScriptStore/ScriptStoreConfigFile.xml" );
		if ( f.exists ) {
			var root = ScriptStore.parse( f );
			if ( root.tag != "document" ) {
				var root = new ScriptStore.XmlNode( "document" );
				root.addAttribute( "version", "1.0" );
				root.addAttribute( "encoding", "iso-8859-1" );
				var scriptsNode = root.addChildNode( "scripts" );
				ScriptStore.store = new ScriptStore.Store( f.fsName, root );
				ScriptStore.store.save();
			} else {
				ScriptStore.store = new ScriptStore.Store( f.fsName, root );
			}
		} else {
			ScriptStore.createConfigFile( f );
		}
	}
	ScriptStore.createConfigFile = function() {
		var adobeFolder = new Folder( Folder.userData + "/Adobe" );
		if ( !adobeFolder.exists ) {
			var boo = adobeFolder.create();
			if ( !boo ) {
				throw localize( "$$$/WAS/Store/err9=Could not create Adobe folder in Common Files folder" );
			}
		}	
		var folder = new Folder( Folder.userData + "/Adobe/ScriptStore" );
		if ( !folder.exists ) {
			var boo = folder.create();
			if ( !boo ) {
				throw localize( "$$$/WAS/Store/err10=Could not create store folder" );
			}
		}
		var f = new File( Folder.userData + "/Adobe/ScriptStore/ScriptStoreConfigFile.xml" );
		var root = new ScriptStore.XmlNode( "document" );
		root.addAttribute( "version", "1.0" );
		root.addAttribute( "encoding", "iso-8859-1" );
		var scriptsNode = root.addChildNode( "scripts" );
		ScriptStore.store = new ScriptStore.Store( f.fsName, root );
		ScriptStore.store.save();
	}
	ScriptStore.saveScriptStore = function() {
		ScriptStore.store.save();
	}
	ScriptStore.parseAttributes = function( str, ht )  {
		var htable = isValidReference( ht ) ? ht : new Hashtable();
		if ( trim( str ).length == 0 ) {
			return htable;
		}
		var aName = trim( getCharsBefore( trim( str ), "=" ) );
		var remainder = trim( getCharsAfter( trim( str ), "=" ) );
		if ( remainder.length == 0 ) return htable;
		var aValue = null;
		if ( remainder.charAt( 0 ) == '"' ) {
			var vString = trim( getCharsAfter( remainder, '"' ) );
			aValue = trim( getCharsBefore( vString, '"' ) );
			remainder = trim( getCharsAfter( vString, '"' ) );
		} else {
			aValue = trim( getCharsBefore( remainder, " " ) );
			remainder = trim( getCharsAfter( remainder, " " ) );
		}
		htable.put( aName, unescape( aValue ) );
		return ScriptStore.parseAttributes( remainder, htable );
	}
	ScriptStore.parseText = function( text ) {
		return ScriptStore.startParser( text );
	}
	ScriptStore.parse = function( f ) {
		f.open( "r" );
		var buffer = f.read();
		f.close();
		return ScriptStore.startParser( buffer );
	}
	ScriptStore.startParser = function( buffer ) {
		buffer = stripCR( buffer );
		var xTag = trim( getCharsBefore( buffer, "?>" ) );
		var buffer = trim( getCharsAfter( buffer, "?>" ) );
		var xTag = trim( getCharsAfter( xTag, "<?xml" ) );
		var root = new ScriptStore.XmlNode( "document", undefined, undefined, true );
		var ht = ScriptStore.parseAttributes( xTag, root.attr );
		root.setAttributes( ht );
		ScriptStore.parsePrimitive( buffer, root );
		return root;
	}
	ScriptStore.parsePrimitive = function( buffer, parentNode ) {
		if ( trim( buffer ).length == 0 ) {
			return;
		}
		var buffer = trim( buffer );
		var text = trim( getCharsBefore( buffer, "<" ) );
		var buffer = trim( getCharsAfter( buffer, "<" ) );
		if ( isValidReference( parentNode ) && text.length > 0 ) {
			parentNode.value = trim( unescape( text ) );
		}
		if ( buffer.length == 0 ) {
			return;
		}
		var tagText = trim( getCharsBefore( buffer, ">" ) );
		buffer = trim( getCharsAfter( buffer, ">" ) );
		var binary = !endsWith( tagText, "/" );
		if ( !binary ) { // it's a <tag attr="val" /> style tag
			tagText = trim( tagText.substr( 0, ( tagText.length - 1 ) ) ); // trim the / and whitespace
			var tag = trim( getCharsBefore( tagText, " " ) );
			tagText = trim( getCharsAfter( tagText, " " ) );
			var node = parentNode.addChildNode( tag, "" );
			node.setAttributes( ScriptStore.parseAttributes( tagText, node.attr ) );
			ScriptStore.parsePrimitive( buffer, parentNode ); // it's not binary, go look for another tag under same parent
		} else { // it's a binary tag, like: <tag attr="val >something</tag>
			tagText = trim( tagText );
			var tag = trim( getCharsBefore( tagText, " " ) ); // peels the tag off the front
			tagText = trim( getCharsAfter( tagText, " " ) );
			var containedStuff = trim( getCharsBefore( buffer, "</" + tag ) );
			var buffer = trim( getCharsAfter( buffer, "</" + tag ) );
			var buffer = trim( getCharsAfter( buffer, ">" ) );
			var node = parentNode.addChildNode( tag, "" );
			node.setAttributes( ScriptStore.parseAttributes( tagText, node.attr ) );
			ScriptStore.parsePrimitive( containedStuff, node );// parse contained nodes
			ScriptStore.parsePrimitive( buffer, parentNode ); // parse sibling nodes
		}
	}
//--------------------------------------------------------------------
// CLASS DEFINITIONS
//--------------------------------------------------------------------

//---------------------------------------------------------
// Class Name - ScriptStore.Store - primary store object
// Description 
// 	
	ScriptStore.Store = function( filepath, documentNode, root ) {
		this.filePath = filepath;
		this.root = documentNode;
//		this.doc = documentNode;
//		this.root = root;
	}
	ScriptStore.Store.prototype.removeType = function( type ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err11=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			throw localize( "$$$/WAS/Store/err12=Type: " ) + type + localize( "$$$/WAS/Store/err12a= not found in store" );
		}
		var nodes = typeNode.parentNode.nodeChildren;
		for ( var i = 0; i < nodes.length; i++ ) {
			if ( equalsIgnoreCase( type, nodes[ i ].tag ) ) {
				typeNode.parentNode.nodeChildren = arrayRemove( nodes, i );
				this.save();
			}
		}
	}
	ScriptStore.Store.prototype.removeElement = function( type, name ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err13=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			throw localize( "$$$/WAS/Store/err14=Type: " ) + type + localize( "$$$/WAS/Store/err15= not found in store" );
		}
		var memberNodes = typeNode.nodeChildren;
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { // member name exists, kill it
				typeNode.nodeChildren = arrayRemove( memberNodes, i );
				this.save();
				return;
			}
		} // if this loop terms, no member node with the same name exists
	}
	ScriptStore.Store.prototype.put = function( type, name, value ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err16=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			typeNode = this.root.addChildNode( type );
		}
		if ( !isValidReference( typeNode ) ) {
			throw localize( "$$$/WAS/Store/err17=Error saving data" );
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { // member name already exists, save over it...
				memberNodes[ i ].value = value;
				this.save();
				return;
			}
		} // if this loop terms, no member node with the same name exists
		var memberNode = typeNode.addChildNode( "member", value );
		memberNode.addAttribute( "name", name );
		this.save();
	}
	ScriptStore.Store.prototype.get = function( type, name ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err18=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			return undefined;
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { // member of name exists, return it...
				return memberNodes[ i ].value;
			}
		} // if this loop terms, no member node with the same name exists
		return undefined;
	}
	ScriptStore.Store.prototype.putArray = function( type, name, arr ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err19=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			typeNode = this.root.addChildNode( type );
		}
		if ( !isValidReference( typeNode ) ) {
			throw "Error saving data";
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { // member name already exists, save over it...
				memberNodes[ i ].removeChildren();
				for ( var a = 0; a < ht.keyList.length; a++ ) {
					var newNode = memberNodes[ i ].addChildNode( "element", arr[ a ] );
				}
				this.save();
				return;
			}
		} // if this loop terms, no member node with the same name exists
		var memberNode = typeNode.addChildNode( "member", value );
		memberNode.addAttribute( "name", name );
		for ( var a = 0; a < ht.keyList.length; a++ ) {
			var newNode = memberNode.addChildNode( "element", arr[ a ] );
		}
		this.save();
	}
	ScriptStore.Store.prototype.getArray = function( type, name ) {
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			return undefined;
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { 
				var arr = new Array();
				var elementNodes = memberNodes[ i ].findNodes( "element" );
				for ( var a = 0; a < elementNodes.length; a++ ) {
					var eValue = elementNodes[ a ].value;
					ht.push( eValue );
				}
				return arr;
			}
		} // if this loop terms, no member node with the same name exists
		return undefined;
	}

	ScriptStore.Store.prototype.putCollection = function( type, name, ht ) {
		if ( contains( type, " " ) ) {
			throw localize( "$$$/WAS/Store/err20=Invalid store name. Store Names cannot contain spaces" );
		}
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			typeNode = this.root.addChildNode( type );
		}
		if ( !isValidReference( typeNode ) ) {
			throw localize( "$$$/WAS/Store/err21=Error saving data" );
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { // member name already exists, save over it...
				memberNodes[ i ].removeChildren();
				for ( var a = 0; a < ht.keyList.length; a++ ) {
					var newNode = memberNodes[ i ].addChildNode( "element", ht.get( ht.keyList[ a ] ) );
					newNode.addAttribute( "name", ht.keyList[ a ] );
				}
				this.save();
				return;
			}
		} // if this loop terms, no member node with the same name exists
		var memberNode = typeNode.addChildNode( "member" );
		memberNode.addAttribute( "name", name );
		for ( var a = 0; a < ht.keyList.length; a++ ) {
			var newNode = memberNode.addChildNode( "element", ht.get( ht.keyList[ a ] ) );
			newNode.addAttribute( "name", ht.keyList[ a ] );
		}
		this.save();
	}
	ScriptStore.Store.prototype.getCollection = function( type, name ) {
		var typeNode = this.findNode( type );
		if ( !isValidReference( typeNode ) ) {
			return undefined;
		}
		var memberNodes = typeNode.findNodes( "member" );
		for ( var i = 0; i < memberNodes.length; i++ ) {
			var nameAttr = memberNodes[ i ].getAttribute( "name" );
			if ( equalsIgnoreCase( nameAttr, name ) ) { 
				var ht = new Hashtable();
				var elementNodes = memberNodes[ i ].findNodes( "element" );
				for ( var a = 0; a < elementNodes.length; a++ ) {
					var eName = elementNodes[ a ].getAttribute( "name" );
					var eValue = elementNodes[ a ].value;
					ht.put( eName, eValue );
				}
				return ht;
			}
		} // if this loop terms, no member node with the same name exists
		return undefined;
	}
	ScriptStore.Store.prototype.findNode = function( tag, n, node ) {
		var searchNode = isValidReference( node ) ? node : this.root;
		var count = isValidReference( n ) ? n : 0;
		return searchNode.findNode( tag, count );
	}
	ScriptStore.Store.prototype.findNodes = function( tag, node ) {
		var searchNode = isValidReference( node ) ? node : this.root;
		return searchNode.findNodes( tag ); 
	}
	ScriptStore.Store.prototype.save = function() {
		var f = null;
		var f1 = null;
		try {
			f = new File( this.filePath );
			f.open( "w" );
			this.root.write( f );
			f.close();
			this.dirty = false;
		} catch( e ) {
			if ( f1.exists ) {
				f1.remove();
			}
			throw localize( "$$$/WAS/Store/err22=Error saving the Store File" );
		}
	}


//---------------------------------------------------------
// Class Name - ScriptStore.XmlNode - Similar to an XML DOM node, but limited in implementation
// Description 
// implements a limited XmlNode. Does not do CDATA or PCDATA stack. Does not do XMLNS
// But will generate a basic XML file, and allow searching of simple XML data nodes
//
	ScriptStore.XmlNode = function( tag, value, nParent, parsing ) {
		this.isParsing = isValidReference( parsing ) ? parsing : false;
		this.tag = tag;
		if ( typeof value == "boolean" ) {
			this.value = value ? "true" : "false";
		} else {
			this.value = value;
		}
		this.parentNode = nParent;
		this.nodeChildren = new Array( 0 );
		this.attr = new Hashtable();
		if ( this.tag == "document" && !this.isParsing ) {
			this.rootElement = new ScriptStore.XmlNode( "scriptstore_root", undefined, this );
			this.nodeChildren.push( this.rootElement );
		}
	}
	ScriptStore.XmlNode.prototype.getValue = function() {
		if ( ( this.value == "true" ) || ( this.value == "false" ) ) {
			return eval( this.value );
		}
		return decodeURI( this.value );
	}
	ScriptStore.XmlNode.prototype.setValue = function( val ) {
		this.value = encodeURI( val );
	}
	ScriptStore.XmlNode.prototype.addChildNode = function( tag, value ) {
		if ( this.tag == "document" && !this.isParsing ) {
			var newNode = new ScriptStore.XmlNode( tag, value, this.rootElement );
			this.rootElement.nodeChildren.push( newNode );
		} else  { 
			var newNode = new ScriptStore.XmlNode( tag, value, this );
			this.nodeChildren.push( newNode );
		}
		return newNode;
	}
	ScriptStore.XmlNode.prototype.removeChildren = function() {
		this.nodeChildren = new Array();
	}
	ScriptStore.XmlNode.prototype.addAttribute = function( name, value )  {
		this.attr.put( name, value );
	}	
	ScriptStore.XmlNode.prototype.getAttributes = function()  {
		return this.attr;
	}
	ScriptStore.XmlNode.prototype.getAttribute = function( name ) {
		return this.attr.get( name );
	}
	ScriptStore.XmlNode.prototype.setAttributes = function( ht )  {
		this.attr = ht;
	}
	ScriptStore.XmlNode.prototype.writeAttributes = function() {
		var attrStr = '';
		for ( var i = 0; i < this.attr.keyList.length; i++ ) {
			attrStr += ' ' + this.attr.keyList[ i ] + '="' + escape( this.attr.get( this.attr.keyList[ i ] ) ) + '"' ;
		}	
		return attrStr;
	}
	ScriptStore.XmlNode.prototype.write = function( aFile ) {
		var needToClose = true;
		var binary = true;
		if ( this.tag.toLowerCase() == "document" )  {
			aFile.writeln( '<?xml ' + this.writeAttributes() + ' ?>' );
			needToClose = false;
		} else { 
			if ( isValidReference( this.value ) ) {
				binary = ( ( this.value.length != 0 ) || (this.nodeChildren.length > 0 ) );
			} else {
				this.value = "";
				binary = this.nodeChildren.length > 0;				
			}
			if ( !binary )  { // it's tag of style <tag attr="value" />
				needToClose = false;
				aFile.writeln(	'<' + this.tag + this.writeAttributes() + '/>' );
			} else {
				var str = '<' + this.tag + this.writeAttributes() + '>';
				if ( this.value.length > 0 )  {
					str += escape( this.value );
				}
				aFile.writeln( str );				
			}
		}
		for ( var i = 0; i < this.nodeChildren.length; i++ ) {
			this.nodeChildren[ i ].write( aFile );
		}
		if ( needToClose )  {
			aFile.writeln( '</' + this.tag + '>' );
		}
	}
	ScriptStore.XmlNode.prototype.findNode = function( fTag, n )  {
		ScriptStore.findNodeCount = isValidReference( n ) ? n : 0;
		for ( var i = 0; i < this.nodeChildren.length; i ++ ) {
			if ( equalsIgnoreCase( this.nodeChildren[ i ].tag, fTag ) )  {
				if ( ScriptStore.findNodeCount <= 0 ) {
					return this.nodeChildren[ i ];
				} else {
					ScriptStore.findNodeCount -= 1;
				}
			}
			var foundNode = this.nodeChildren[ i ].findNode( fTag, ScriptStore.findNodeCount );
			if ( isValidReference( foundNode ) ) {
				return foundNode;
			}
		}
		return undefined;
	}
	ScriptStore.XmlNode.prototype.findNodes = function( fTag, anArray )  {
		var theResult = null;
		if ( !isValidReference( anArray ) )  {
			theResult = new Array();
		} else {
			theResult = anArray;
		}
		for ( var i = 0; i < this.nodeChildren.length; i ++ ) {
			if ( equalsIgnoreCase( this.nodeChildren[ i ].tag, fTag ) )  {
				theResult.push( this.nodeChildren[ i ] );
			}
			this.nodeChildren[ i ].findNodes( fTag, theResult );
		}
		return theResult;
	}
// end class definition ScriptStore.XmlNode

} // only loaded into bridge...

