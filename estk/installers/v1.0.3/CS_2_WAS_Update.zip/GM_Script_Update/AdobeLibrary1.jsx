#target bridge
//----------------------------------------------------------------------- 
//
// ADOBE SYSTEMS INCORPORATED
// (c) Copyright 2004-2005 Adobe Systems Incorporated
// All Rights Reserved
//
// NOTICE: Adobe permits you to use, modify, and distribute
// this file in accordance with the terms of the Adobe license
// agreement accompanying it. If you have received this file
// from a source other than Adobe, then your use, modification,
// or distribution of it requires the prior written permission
// of Adobe.
//
//----------------------------------------------------------------------- 
// <asm:name>Adobe Library</asm:name>
// <asm:description>This file contains a number of handy utility functions and some class definitions.</asm:description>
// <asm:help>None, for developers only</asm:help>
// <asm:author>Bob Stucky, Chandler McWilliams</asm:author>
// <asm:company>Adobe Systems, Inc.</asm:company>
// <asm:copyright>(c) Copyright 2004-2005 Adobe Systems Incorporated. All rights reserved</asm:copyright>
// <asm:version>0.5.41</asm:version>
// <asm:date>06-15-2005</asm:date>
// <asm:website>http://www.adobe.com</asm:website>
//----------------------------------------------------------------------- 
//--------------------------------------------------------------------
// GLOBAL VARIABLES / SETTINGS
//--------------------------------------------------------------------
if ( BridgeTalk.appName == "bridge" ) {

var Version = "0.1";
// debug level: 0-2 (0:disable, 1:break on error, 2:break at beginning)
$.level = 0;
AdobeLibrary1 = {};
//---------------------------------------------------------
// functionName - startTargetApplication - starts a target application and waits unti
// it is ready to receive and respond to messages.
//
// Description - There is a bug in BridgeTalk that causes messages send to an application that is
// starting to become disconnected from their onResult handlers. The solution is to start the application
// with a BT message, and wait until an onResult handler is fired. At that point, the target application
// is fully started and ready to work with BridgeTalk.
// it does the rigamarole with the eval statements because it's quite possible that a user could have
// more than one target app starting at the same time. The evals manipulate a boolean based on the target
// application's name, ensuring that more than one app can be started at one time. 
// If you are relying on the onResult handler to fire in any script, ALWAYS execute this function prior to sending
// your bt message.
// arguments 	- none
// returns 	- nothing
startTargetApplication = function( target ) {
	if ( !verifyInstalledApplication( target ) ) {
		var targetApp = getCharsBefore( target, "-" );
		var str = isValidReference( targetApp ) ? targetApp : target;
		str += localize( "$$$/WAS/AdobeLibrary1/appNotInstalled= is not installed." );
//		alert( str );
		return false;
	}
	if ( !BridgeTalk.isRunning( target ) ) {
		str = "AdobeLibrary1.start" + getCharsBefore( target, "-" ) + " = false;";
		eval( str );
		startupComplete = false;
		BridgeTalk.launch( target );
		var counter = 0;
		while ( !BridgeTalk.isRunning( target ) ) {
			$.sleep( 3000 );
			if ( counter++ == 30 ) { // if not started in 2 minutes, fail out
				var targetApp = getCharsBefore( target, "-" );
				var str = isValidReference( targetApp ) ? targetApp : target;
				str += localize( "$$$/WAS/AdobeLibrary1/appDidNotStart= did not launch." );
//				alert( str );
				return false;		
			}			
		}
		var counter = 0;
		while ( !eval( 'AdobeLibrary1.start' + target ) ) {
			var bt = new BridgeTalk();
			bt.target = target;	
			bt.body = "var t = " + target;
			bt.onResult = function( btObj ) {
				str = 'AdobeLibrary1.start' + getCharsBefore( btObj.sender, "-" ) + ' = true;';
				eval( str );
			}
			bt.send();
			$.sleep( 3000 );
			BridgeTalk.pump();
			if ( counter++ == 30 ) { // if not started in 2 minutes, fail out
				var targetApp = getCharsBefore( target, "-" );
				var str = isValidReference( targetApp ) ? targetApp : target;
				str += localize( "$$$/WAS/AdobeLibrary1/appDidNotStart= did not launch." );
//				alert( str );
				return false;		
			}
		}
	}
	return true;
}
AdobeLibrary1.applications = new Array();
AdobeLibrary1.applications[ "photoshop" ] = "Photoshop";
AdobeLibrary1.applications[ "illustrator" ] = "Illustrator";
AdobeLibrary1.applications[ "golive" ] = "GoLive";
AdobeLibrary1.applications[ "indesign" ] = "InDesign";
AdobeLibrary1.applications[ "bridge" ] = "Bridge";
AdobeLibrary1.applications[ "estoolkit" ] = "ExtendScript Toolkit";
AdobeLibrary1.applications[ "helpcenter"] = "Help Center";
//---------------------------------------------------------
// functionName - verifyInstalledApplication - returns true if the target app exists
//
// Description - checks to make sure the target app is installed
// arguments - target - the application specifier for the application you want to run
// returns 	- true or false based on target's existance

verifyInstalledApplication = function( target ) {
	var theTarget = getCharsBefore( target, "-" );
	var applications = BridgeTalk.getTargets();
	for ( var i = 0; i < applications.length; i++ ) {
		if ( theTarget == applications[ i ] ) {
			return true;
		}
	}
	return false;
}
// functionName - ensureUniqueFile 
// Description - returns a file that will point to a UNIQUE file name. If the passed file exists,
// it will append a (n) number to the end of the file (before the extension).
// arguments - file - any file
// returns - a file object that is a unique file name and that the file will not exist
//
ensureUniqueFile = function( file ) {
	var sq = 1;
	while ( file.exists ) {
		file = new File( file.path + "/" + file.getNameWithoutExtension() + "(" + sq++ + ")." + file.getExtension() );
	}
	return file;
}
//---------------------------------------------------------
// functionName - getScriptFileName - returns the filename of the executing script
//
// Description - Note, although this "hack" resides in the library, it will always return the path
// to the Library script file (because it's in the library...). 
// To return the path of your script file, copy & paste this function into your script file.
// arguments 	- none
// returns 	- path of the executing script file
getScriptFileName = function() {
	try {
		var dbLevel = $.level;
		$.level = 0;
		var path = null;
	    some_undefined_variable;
	 } catch( e )  {
	    path = e.fileName;
	 } finally {
	 	$.level = dbLevel;
	 	return path;
	 }
}
//---------------------------------------------------------
// functionName - writeToFile - write given text to a file
//
// Description - flips up a file save dialog, and then saves the the text to the selected file.
// This is a handy utility for debugging scripts that execute in a target application. Save the script with
// this function, then run the saved file as a script in the target app. Makes debugging much easier...
// arguments 	- text - the text to write to a file
// returns 	- nothing
writeToFile = function( text ) {
	var f = File.openDialog( "Name a script file:");
	if ( isValidReference( f ) ) {
		f.open( "w" );
		f.writeln( text );
		f.close();
	}
}
//--------------------------------------------------------------------
// Functions for detecting the nature of file objects
//--------------------------------------------------------------------
//---------------------------------------------------------
// functionName - isValidReference - checks to make sure whatever you give it exists 
//
// Description
// arguments 	- any object reference
// returns		- boolean indicating the state
	isValidReference = function( ref )  {
	  return ( ref != undefined && ref != null );
	}

//---------------------------------------------------------
// functionName - inInDesign - detects whether a file is an ID File
//	this function is superceded by extensions to the File prototype. It is left in
//  only for legacy scripts that might depend on it. Look at the file prototype extensions
//  a few lines further down.
//
// Description
// arguments 	- any File object
// returns 	- a boolean indicating if it's a PDF or not
isInDesign = function( f ) {
	if ( !isValidReference( f ) || f instanceof Folder ) {
		return false;
	}
	var ex = "indd,indt,INDD,INDT";
	var ext = getCharsAfter( f.name, "." ).toLowerCase();
	if ( File.fs == "Macintosh" )	 {
		ext = (f.type == '????') ? ext : f.type;
	}
	return ex.indexOf( ext ) > -1;
}
//---------------------------------------------------------
// functionName - isPDF - detects whether a file is a PDF
// Adobe provided Bridge Scripts
//	this function is superceded by extensions to the File prototype. It is left in
//  only for legacy scripts that might depend on it. Look at the file prototype extensions
//  a few lines further down.
//
// Description
// arguments 	- any File object
// returns 	- a boolean indicating if it's a PDF or not
isPDF = function( f ) {
	if ( !isValidReference( f ) || f instanceof Folder ) {
		return false;
	}
	var ex = "pdf,PDF ";
	var ext = getCharsAfter( f.name, "." ).toLowerCase();
	if ( File.fs == "Macintosh" )	 {
		ext = (f.type == '????') ? ext : f.type;
	}
	return ex.indexOf( ext ) > -1;
}
//---------------------------------------------------------
// functionName - isPSD - detects whether a file is a Photoshop PSD file
//	this function is superceded by extensions to the File prototype. It is left in
//  only for legacy scripts that might depend on it. Look at the file prototype extensions
//  a few lines further down.
// 
//
// Description
// Determines if file is psd
// arguments 	- any File object
// returns 	- a boolean indicating if it's a PSD or not
isPSD = function( f )  {
	if ( !isValidReference( f ) || f instanceof Folder ) {
		return false;
	}
	var ex = "psd,PSD,8BIM,8BPS";
	var ext = getCharsAfter( f.name, "." ).toLowerCase();
	if ( File.fs == "Macintosh" )	 {
		ext = (f.type == '????') ? ext : f.type;
	}
	return ex.indexOf( ext ) > -1;
}
//---------------------------------------------------------
// functionName - isPageMaker - detects whether a file is a PM file
// Adobe provided Bridge Scripts
//	this function is superceded by extensions to the File prototype. It is left in
//  only for legacy scripts that might depend on it. Look at the file prototype extensions
//  a few lines further down.
//
// Description
// Determines if file is PM6 or PM65. Should add latest versions as well.
// arguments 	- any File object
// returns 	- a boolean indicating if it's PM or not
isPageMaker = function( f )  {
	if ( !isValidReference( f ) || f instanceof Folder ) {
		return false;
	}
	var ex = "pm6,p65,pmd,ALD6"; // need the possible file type signatures for PM on Mac
	var ext = getCharsAfter( f.name, "." ).toLowerCase();
	if ( File.fs == "Macintosh" )	 {
		ext = f.type;
	}
	return ex.indexOf( ext ) > -1;
}
//--------------------------------------------------------------------
// Object Prototype Extensions
//--------------------------------------------------------------------
// The following section contains extensions to standard object prototypes.
// Specifically File, Date, and String
//
// all types/extensions should be uppercase
// all lists shoudl end in a comma (for easy concatination)
// these strings should be stored as a preference item, methinks...


//--------------------------------------------------------------------
// File Object Prototype Extension
//--------------------------------------------------------------------
// TYPES are standard file type extensions for the various apps
// Below TYPES is an extension to the File object that allows files
// to "self-filter" based on a requested type or set of types
TYPES = {};
TYPES.ALL = "";
TYPES.PHOTOSHOP	= "PSD,PDD,8BPS,JPEG,JPG,GIF,";
TYPES.PHOTOSHOP_OPENABLE = "PSD,PDD,JPEG,JPG,JPE,8BPS,GIF,BMP,RLE,DIB,TIF,CRW,NEF,RAF,ORF," +
	"CIN,SDPX,DPX,FIDO,GIF,EPS,PS,EPSF,FLM,PSB,EXR,AI3,AI4,AI5,AI6,AI7,AI8,AI,PCX,PDF,PDP," +
	"PCD,RAW,PICT,PCT,PIC,PXR,PNG,HRR,RGBE,XYZE,TGA,VDA,ICB,VST,TIF,TIFF,WBM,WBMP,DNG,SCT,PBM,";
TYPES.PAGEMAKER	= "PM6,PM6,P65,PMD,ALD6,";
TYPES.INDESIGN	= "INDD,IDD3,IDD4,INDT,";
TYPES.PDF		= "pdf,PDF,";
TYPES.ILLUSTRATOR = "AI,AIT,";
TYPES.ILLUSTRATOR_OPENABLE = "AI,AIT,PDF,DXF,BMP,RLE,CGM,CDR,EPS,EPSF,PS,EMF,FH?," +
	"GIF,JPEG,JPG,JPE,PCD,PCT,PIC,RTF,DOC,PCX,PSD,PDD,PXR,PNG,SVG,SVGZ,TGA,VDA,ICB,VST,TXT,TIF,TIFF,WMF,";
TYPES.DEFAULT_CONTACTSHEET = "JPG,JPEG,TIF,TIFF,GIF,AI,PSD,PDF,";
TYPES.GOLIVE = "HTML,HTM,CSS,JS";
TYPES.SCRIPT = "JSX";
// add isA methods to file object
// this handles most of it, checks if the file has the extension (win) / type (mac) of
// the comma separated string passed as ex
File.prototype.isFileType = function( ex )  {
	if ( isEmpty( ex ) ) {
		return true;
	}
	var ex = ex.toUpperCase();
	ext = this.getExtension();
	if ( !isValidReference( ext ) ) {
		ext = "";
	}
	ext = trim(ext);

	// this is tricky now because OS X uses extensions
	// so if the extension can be used to determine type,
	// use it, otherwise try the type
	if (ex.indexOf( ext.toUpperCase() ) > -1) return true;
	// only try this on mac
	if ( File.fs == "Macintosh" ) {
		ext = ( this.type == '????' ) ? ext : this.type;
		return ex.indexOf( ext.toUpperCase() ) > -1;
	}
	// pc will be false at this point
	return false;
}
File.prototype.isPhotoshop = function()  {
	return this.isFileType(TYPES.PHOTOSHOP);
}
File.prototype.isPageMaker = function()  {
	return this.isFileType(TYPES.PAGEMAKER);
}
File.prototype.isInDesign = function()  {
	return this.isFileType(TYPES.INDESIGN);
}
File.prototype.isPDF = function()  {
	return this.isFileType(TYPES.PDF);
}
File.prototype.isIllustrator = function() {
	return this.isFileType( TYPES.ILLUSTRATOR );
}
File.prototype.isOpenableIllustrator = function() {
	return this.isFileType( TYPES.ILLUSTRATOR_OPENABLE );
}
File.prototype.isOpenablePhotoshop = function() {
	return this.isFileType( TYPES.PHOTOSHOP_OPENABLE );
}
File.prototype.isScript = function() {
	return this.isFileType( TYPES_SCRIPT );
}
// QUICK FIX
	File.prototype.getExtension = function( noDecode ) {
		var idx = decodeURIComponent( this.name ).lastIndexOf( "." );
		if ( noDecode ) {
			var idx = this.name.lastIndexOf( "." );
		}
		var ext = undefined;
		if ( idx > -1 ) {
			if ( noDecode ) {
				ext = this.name.substr( ( idx + 1 ) );
			} else {
				ext = decodeURIComponent( this.name ).substr( ( idx + 1 ) );
			}
		}
		return ext;
	}
	File.prototype.getNameWithoutExtension = function( noDecode ) {
		var fName = decodeURIComponent( this.name );
		if ( noDecode ) {
			var fName = this.name;
		}
		var idx = fName.lastIndexOf( "." ); // could be more than 1 . in the file name
		if ( idx > -1 ) {
			fName = fName.substr( 0, idx );
		}
		return fName;
	}	
	File.prototype.getFileWithExtension = function( ext ) {
		var fName = this.getNameWithoutExtension( true );
		var ext1 = this.getExtension();
		if ( isValidReference( ext ) ) {
			ext1 = ext;
		}
		var newPath = this.path + "/" + fName + "." + ext1;
		return new File( newPath );
	}
// this extension to Thumbnail is to allow us to look around VC nodes and filter based on file types at 
// the same time. It has to be wrapped because thumbnails don't exist except in the Bridge

	if ( !isValidReference( Thumbnail.prototype.isFileType ) ) {
		Thumbnail.prototype.isFileType = function( ex ) { // for browsing Thumbnails
			if ( ( ( equalsIgnoreCase( this.location, "local" ) ) || ( equalsIgnoreCase( this.location.toLowerCase(), "versioncue" ) ) ) && ( this.resolve().spec instanceof File ) ) { // if it's not a File, return false
				return this.spec.isFileType( ex );
			}
			return false; 
		}
	}
	if ( !isValidReference( Thumbnail.prototype.relativePath ) ) {
		Thumbnail.prototype.relativePath = function( base ) {
			if ( !isValidReference( base ) ) {
				if ( equalsIgnoreCase( this.location, "versioncue" ) ) {
					if ( contains( this.path, "soap" ) ) {
						return getCharsAfter( this.path, "/soap/" );
					} else {
						return "/soap/";
					}
				} else {
					return this.spec.absoluteURI;
				}
			} else {
				if ( equalsIgnoreCase( this.location, "versioncue" ) ) {
					return getCharsAfter( this.path, base );
				} else {
					return this.spec.getRelativeURI( base );
				}
			}
		}
	}
//}
//--------------------------------------------------------------------
// Date Object Prototype Extension
//--------------------------------------------------------------------
// Date.formatter( formatString ) is a method to format a Date object into a string
// supported formatting:
//  Y - year character
//	M - month
//	D - day
//	h - hours
// 	m - minutes
//	s - seconds
// 	examples:	formatString = MM/DD/YY   			-> 01/22/04
//				formatString = MM-DD-YYYY 			-> 01-22-2004
//				formatString = MMMM-DDDD-YYYY		-> 0001-0022-2004
// Date.formatterDateString() is a utility function for Date.formatter( );
// You should never call it....
Date.prototype.formatterDateString = function( ch, length) {
	var ds = "";
	switch( ch ) {
		case "Y" : {
			ds = new String( this.getFullYear() );
			if ( length > 4 ) {
				ds = "               ".substr( 0, ( length - 4 ) ) + ds;
			} else {
				ds = ds.substr( ( 4 - length ), length );	
			}
			return ds;
		}
		case "M" : {
			ds = new String( this.getMonth() + 1 );
			if ( ds.length  == 1 ) {
				ds = "0" + ds;
			}
			break;
		}
		case "D" : {
			ds = new String( this.getDate() );
			if ( ds.length  == 1 ) {
				ds = "0" + ds;
			}
			break;
		}
		case "h" : {
			ds =  new String( this.getHours() + 1 );
			if ( ds.length  == 1 ) {
				ds = "0" + ds;
			}
			break;
		}
		case "m" : { 
			 ds =  new String( this.getMinutes() );
			if ( ds.length  == 1 ) {
				ds = "0" + ds;
			}
			break;
		}
		case "s" : { 
			var ds = new String( this.getSeconds() );
			if ( ds.length  == 1 ) {
				ds = "0" + ds;
			}
			break;
		}
	}
	if ( length > 2 ) {
		ds = "000000000000000".substr( 0, ( length - 2 ) ) + ds;
	} else {
		ds = ds.substr( ( 2 - length ), length );	
	}
	return ds;
}
// this is the one you call. 
// usage: 
// var myDate = new Date();
// var aString = myDate.formatter( "MM-DD-YYYY" );
Date.prototype.formatter = function( fmt, token, out ) {
	if ( !isValidReference( out ) ) {
		out = "";
	}
	if ( fmt.length == 0 ) {
		if ( token.length > 0 ) {
			out += this.formatterDateString( token[ 0 ], token.length );
		}
		return out;
	}
	if ( isValidReference( token ) ) { // we're in a second or higher iteration
		var ch = fmt[ 0 ]; // next char in the format
		var fmt = fmt.substr( 1 ); // stuff after char 1 of the format string
		if ( token.length > 0 ) { // there's something in token...
			var tch = token[ 0 ];
			if ( tch == ch ) { // it's another copy of the existing token
				token += ch;
				return this.formatter( fmt, token, out );
			} 
			if ( "YMDhms".indexOf( ch ) > -1 ) { // it's a new token character (different from existing token)
				out += this.formatterDateString( tch, token.length );
				token = ch;
				return this.formatter( fmt, token, out );
			} else { // it's not a format token character
				if ( token.length > 0 ) {
					out += this.formatterDateString( tch, token.length );
				}
				out += ch;
				return this.formatter( fmt, "", out );
			}
		} else { // token is empty 
			if ( "YMDhms".indexOf( ch ) > -1 ) { //it's a token char
				return this.formatter( fmt, ch, out );
			} else { // not a token char
				out += ch;
				return this.formatter( fmt, token, out );
			}
		}
	} else {
		return this.formatter( fmt, "", out );
	}
	return out;
}
//--------------------------------------------------------------------
// String Object Prototype Extension
//--------------------------------------------------------------------
// some handy String utilities, all of the utilites are in this file below
// this just builds them in to the actual String prototype...
String.prototype.equalsIgnoreCase = function( s ) {
	return equalsIgnoreCase( this, s );
}
String.prototype.trim = function() {
	return trim( this );
}
String.prototype.ltrim = function() {
	return ltrim( this );
}
String.prototype.rtrim = function() {
	return rtrim( this );
}
String.prototype.startsWith = function( s ) {
	return startsWith( this, s );
}
String.prototype.endsWith = function( s ) {
	return endsWith( this, s );
}
String.prototype.contains = function( s ) {
	return contains( this, s );
}
String.prototype.simpleReplace = function( s, r ) {
	return replace( this, s, r );
}
//--------------------------------------------------------------------
// UTILITY FUNCTIONS
//--------------------------------------------------------------------
wait = function( ms ) {
	$.sleep( ms );
}
//---------------------------------------------------------
// functionName - createMenu - creates menus while preventing duplicates
//
// Description
// arguments 	- type: either "command" or "menu"
//				- text: the text that will be displayed as a menu
//				- where: location for the menu, see the Scripting Guide
//				- onSelect: pointer to the onSelect handler for a menu element of type command
//				- onDisplay: pointer to the onDisplay handler for the menu element
//              - script - the script to execute
//              - onResultHandler - pointer to a method to execute onResult
// returns 	- nothing
// Note: Relies on MenuElement.find() which will NOT work on the Bridge standard menus.
// it will work on any menu a scripter creates.
// MenuElement.create() now pretty much does this. This was written months before
// create existed, and is left in the library for legacy script compatibility
	AdobeLibrary1.addedToPsMenu = false;
	AdobeLibrary1.maskedMenus = new Array();
	createMenu = function( type, text, where, id, onSelect, onDisplay, fileMask )  {
		var aMenu = null;
		var aMenu = MenuElement.find( id );
		if ( aMenu == null )  {
			if ( !AdobeLibrary1.addedToPsMenu && ( trim( where ) == "at the end of tools/ps" ) ) {
				where = "-" + trim( where );
				AdobeLibrary1.addedToPsMenu = true;
			}
			aMenu = new MenuElement( type, text, where, id );
		}
		aMenu.enabled = true;
		if ( isValidReference( onDisplay ) ) {
			aMenu.onDisplay = onDisplay;
		} else {
			if ( isValidReference( fileMask ) ) {
				aMenu.requiredFileMask = fileMask;
				aMenu.onDisplay = WASDisplayMenu;
				AdobeLibrary1.maskedMenus.push( text );
			} 
		}

		if ( type == "command" ) {
			aMenu.onSelect = onSelect;	
		}

		return aMenu;
	}
	WASDisplayMenu = function() {
//		$.level = 1;
//		debugger;
//		var t = getBridgeThumbnails( this.requiredFileMask, true, true );
//		this.enabled = isValidReference( t[ 0 ] );
		this.enabled = true;
	}
//---------------------------------------------------------
// functionName - createGenericMenus - creates standard tools menus without duplicating
//
// Description - If your script is intended to reside in one of these menus, you
// 				should execute this function prior to adding your menus to ensure
//				that they actually exist before you make your script specific ones.
// arguments 	
// returns 	- nothing
	createGenericMenus = function() {
//		AdobeLibrary1.modifyThumbnailPrototype();
		try {
			var psServicesMenuExists = MenuElement.find ('Tools/PhotoshopServices') != null;
			createMenu( "menu", AdobeLibraryStrings.psMenu, psServicesMenuExists ? '-after Tools/PhotoshopServices' : '-after submenu/VersionCue', "tools/ps" );
			createMenu( "menu", AdobeLibraryStrings.aiMenu, "after tools/ps", "tools/ai" );
			createMenu( "menu", AdobeLibraryStrings.idMenu, "after tools/ai", "tools/id" ); 
//			createMenu( "menu", AdobeLibraryStrings.psMenu, "at the end of Tools", "tools/ps" );
//			createMenu( "menu", AdobeLibraryStrings.aiMenu, "at the end of Tools", "tools/ai" );
//			createMenu( "menu", AdobeLibraryStrings.idMenu, "at the end of Tools", "tools/id" );
//			createMenu( "menu", AdobeLibraryStrings.glMenu, "at the end of Tools", "tools/gl" );
		} catch ( e ) {
			alert( e );
		}
	}

//---------------------------------------------------------
// functionName - sendBridgeTalkMessage - send the most basic BT message
//
// Description - Creates and sends a BT message
// arguments 	- target - the BT target application
//              - script - the script to execute
//              - onResultHandler - pointer to a method to execute onResult
// returns 	- nothing
// Throws - throws a text message indicating the nature of the error if one occurs
// Early attempts at making BT a little easier. See the progress dialog stuff below for
// BT message objects that manage progress meters.
	sendBridgeTalkMessage = function( target, script, onResultHandler ) {
		try {
			var bt = new BridgeTalk();
			bt.target = target;
			bt.body = script;
			if (!BridgeTalk.isRunning( target ) )  {
				if ( !startTargetApplication( target ) ) {
					return;
				}
			}
		} catch (a ) {
			alert( a );
		}
		// bt message interaction handlers

		bt.onResult = onResultHandler;

		bt.onError = function( r )  {
			alert( TranslateErrorCodes.getMessage( r ) );
		}
		var p = bt.send();
	}
//---------------------------------------------------------
// functionName - getBridgeFiles - returns files selected in Bridge
//
// Description
//   returns an array of File/Folder objects that are currently selected. If no
//   files or folders are selected, it returns all of the Files/Folders in the 
//   content pane of the Bridge. If one of the selected objects is an alias or shortcut
//   it will resolve the shortcut to its target.
//	the optional mask parameter will only return files of a particular type as defined in TYPES
	AdobeLibrary1.isFile = function( thumb ) {
		try {
			return thumb.resolve().spec instanceof File;
		} catch ( e ) {
			return false;
		}
	}
	AdobeLibrary1.isFolder = function( thumb ) {
		try {
			return thumb.resolve().spec instanceof Folder;
		} catch ( e ) {
			return false;
		}
	}
	AdobeLibrary1.isHidden = function( thumb ) {
		try {
			return thumb.resolve().spec.hidden;
		} catch ( e ) {
			return false;
		}
	}
	thumbnailsToFiles = function( thumbnails ) {
		var files = new Array();
		var paths = new Array();
		var vcNodes = false;
		for ( var i = 0; i < thumbnails.length; i++ ) {
//			if ( equalsIgnoreCase( thumbnails[ i ].location, "versioncue" ) ) {
//				vcNodes = true;
			paths.push( thumbnails[ i ].path );
//			}
//			files.push( thumbnails[ i ].spec );
			files.push( new File( encodeURI( thumbnails[ i ].path ) ) );
		}
//		if ( vcNodes ) {
			app.preflightFiles( paths );
//		}
		return files;
	}
	getBridgeFiles = function( mask, getFolderChildren, filesOnly, firstOnly ) {
		return thumbnailsToFiles( getBridgeThumbnails( mask, getFolderChildren, filesOnly, firstOnly ) );
	}
	getBridgeThumbnails = function( mask, getFolderChildren, filesOnly, firstOnly )  {	
		var store = ScriptStore.open( "libraryGetBridgeFiles" );
		var warnNoSelection = store.get( "alertFlags", "noselection" );
		if ( !isValidReference( warnNoSelection ) ) {
			warnNoSelection = true;
			store.put( "alertFlags", "noselection", "true" );
		} else {
			warnNoSelection = eval( warnNoSelection );
		}
		var warnSomeBadType = store.get( "alertFlags", "badtypes" );
		if ( !isValidReference( warnSomeBadType ) ) {
			warnSomeBadType = true;
			store.put( "alertFlags", "badtypes", "true" );
		} else {
			warnSomeBadType = eval( warnSomeBadType );
		}
		var folderChildren = isValidReference( getFolderChildren ) ? getFolderChildren : true;
		var getFirstFile = isValidReference( firstOnly ) ? firstOnly : false;
		var getFilesOnly = isValidReference( filesOnly ) ? filesOnly : false;
		mask = isValidReference( mask ) ? mask : "";
		var thumbnails = new Array();
		var goodFiles = false;
		var badFiles = false;	
		if ( app.document.selections.length == 0 && warnNoSelection && !firstOnly ) {
			var warning = new DoNoShowAgainWarningAlert( localize( "$$$/WAS/Library/goodFileBadFile=When you do not select any files, All files in the active" ), true, localize( "$$$/WAS/Library/goodFileBadFile2=Bridge document are processed. Click Cancel if this is not what you want." ) );
			var showAgain = warning.show();
			var storeShowAgain = showAgain ? "true" : "false";
			store.put( "alertFlags", "noselection", storeShowAgain );
			if ( warning.actionCancelled ) {
				return thumbnails;
			}
		}
		if ( isValidReference( app.document ) && isValidReference( app.document.thumbnail ) ) {
			var kids = app.document.selections;
			if ( kids.length > 0 ) { // user selected individual thumbnails in the content pane
				for ( var i = 0; i < kids.length ; i++ ) {
					var thumb = kids[ i ].resolve();
//thumb.location == "local"
					if ( AdobeLibrary1.isFile( thumb ) ) {
						if ( thumb.isFileType( mask ) ) {
							goodFiles = true;
							thumbnails.push( thumb );
							if ( getFirstFile ) {
								return thumbnails;
							}
						} else {
							badFiles = true;
						}
					} else if ( AdobeLibrary1.isFolder( thumb ) ) {
						if ( folderChildren ) { // if they selected a folder type, go ahead and get the children
//							thumbnails = thumbnails.concat( getFilesinFolderUsingMask( thumb, mask, getFirstFile ) );
							var kids = thumb.children;
							for ( var i = 0; i < kids.length; i++) {
								var thumb2 = kids[ i ];
//thumb2.location == "local"
								if ( !AdobeLibrary1.isHidden( thumb2 ) ) { // again, skip any hidden files
									if ( thumb2.isFileType( mask ) ) {
										goodFiles = true;
										thumbnails.push( thumb2 );
										if ( getFirstFile ) {
											return thumbnails;
										}
									} else {// here we are not looking at downline folders, doing so would start a full hierarchical file scan (a bad thing)
										badFiles = true;
									}
								}
							}
						} else { // unless, of course, we don't want to (getting the children is the default)
							if ( !getFirstFile && !getFilesOnly ) {
								thumbnails.push( thumb );
							}
						}
					} else {
						alert( AdobeLibraryStrings.fsError );
						return new Array();
					}					
				}
			}
			else if ( app.document.thumbnail.children.length > 0 ) { // user did not select any specific thumbnail, look at all thumbnails in the content pane
				var kids = app.document.thumbnail.children;
				for ( var i = 0; i < kids.length ; i++ ) {
					var thumb = kids[ i ];
//thumb.location == "local"
					thumb = thumb.resolve();
					if ( !AdobeLibrary1.isHidden( thumb ) ) { // because they didn't select anything, it's possible a hidden file will be in there somewhere...
						if ( AdobeLibrary1.isFile( thumb ) ) {
							if ( thumb.isFileType( mask ) ) { // only take those that fit the mask
								goodFiles = true;
								thumbnails.push( thumb );
								if ( getFirstFile ) {
									return thumbnails;
								}
							} else {
								badFiles = true;
							}
						} else if ( AdobeLibrary1.isFolder( thumb ) ) {
							if ( !getFirstFile && !getFilesOnly ) {
								thumbnails.push( thumb );
							}
						} else {
							throw AdobeLibraryStrings.fsError;
						}
					}
				}
			}
			if ( warnSomeBadType && goodFiles && badFiles ) { // there were both valid and invalid file types selected...
				// do the warning
				var warning = new DoNoShowAgainWarningAlert( localize( "$$$/WAS/Library/goodFileBadFile3=One or more selected files will be skipped because they are not" ), false, localize( "$$$/WAS/Library/goodFileBadFile3a=the right type of file for the requested operation." ) );
				var showAgain = warning.show();
				var storeShowAgain = showAgain ? "true" : "false";
				store.put( "alertFlags", "badtypes", storeShowAgain );
			}
		}
		return thumbnails;
	}
	// get list of files in a folder
	function getFilesinFolderUsingMask( aThumbnail, mask, getFirstFile ) {
		var stopOnFirstFile = isValidReference( getFirstFile ) ? getFirstFile : false;
		var output = [];
		var kids = aThumbnail.children;
		for ( var i=0; i < kids.length; i++) {
			var thumb = kids[ i ];
			if ( !thumb.hidden ) { // again, skip any hidden files
				if ( thumb.isFileType( mask ) ) {
					output.push( thumb );
					if ( stopOnFirstFile ) {
						return output;
					}
				}// here we are not looking at downline folders, doing so would start a full hierarchical file scan (a bad thing)
			}
		}
		return output;
	}
//---------------------------------------------------------
// functionName - getFirstSelectedBridgeFile - returns fist File object selected in Bridge
//
// Description
//   returns a the first selected file in Bridge
//   If no files are selected, it returns undefined
getFirstSelectedBridgeFile = function( mask ) {
	var files = getBridgeFiles( mask, true, true, true );
	return files[ 0 ];
}
//---------------------------------------------------------
// functionName - getParentWindow - returns window that contains the object
//
// Description
//   returns the window, dialog, or palette that contains the supplied ScriptUI control
//
	getParentWindow = function( control ) {
		while ( isValidReference( control.parent ) ) {
			control = control.parent;
		}
		return control;
	}
//---------------------------------------------------------
// functionName - isEmpty 
//
// Description
// arguments 	- any string
// returns 	- a boolean indicating the state of the string
	isEmpty = function( str )  {
		if ( !isValidReference( str ) ) {
			return true;
		}
		return ( str == null || str == "" )
	}
//---------------------------------------------------------
// functionName - equalsIgnoreCase - string equality check 
//
// Description
// arguments 	- two strings
// returns		- boolean indicating the equality state, ignoring case
	equalsIgnoreCase = function( str, str1 )  {
		return str.toLowerCase() == str1.toLowerCase();
	}
	String.prototype.equalsIgnoreCase = function( str1 ) {
		return equalsIgnoreCase( this, str1 );
	}
//---------------------------------------------------------
// functionName - ltrim - trims whitespace from left edge of a string 
//
// Description
// arguments	- any string
// returns		- a trimmed string
	ltrim = function( str )  {
	    return new String( str ).replace( /^\s+/ , "" );
	}
//---------------------------------------------------------
// functionName - rtrim - trims whitespace from right edge of a string 
//
// Description
// arguments	- any string
// returns		- a trimmed string
	rtrim = function( str )  {
	    return new String( str ).replace( /\s+$/ , "" );
	}
//---------------------------------------------------------
// functionName - trim	- trims white space from the both ends of a string
//
// Description
// arguments	- any string
// returns		- a trimmed string
	trim = function( st )  {
		var str = new String( st );
	    str = str.replace( /^\s+/ , "" );
	    str = str.replace( /\s+$/ , "" );
	    return str
	}
//---------------------------------------------------------
// functionName - isWhitespace	- checks if a character is white space
//
// Description
// arguments 	- any character
// returns		- boolean reflecting the state
	isWhitespace = function( c )  {
		return ( c.search(/\s+/) != -1 );
	}
//---------------------------------------------------------
// functionName - endsWith 	- checks to see if a string ends with another string
//
// Description
// arguments	- str - any string
//				- end - the "end" string
// returns		- a boolean with the correct state
	endsWith = function( str, end )  {
		var s = str.substr( ( str.length - end.length ), end.length );
		return( s == end );
	}
//---------------------------------------------------------
// functionName: stripCR	- removes carriage returns from a string
// arguments	- s - any string
// returns		- a string with no carriage returns. It does NO replacing...
	stripCR = function( s )  {
		if ( isValidReference( s ) )	 {
			var str = new String( s.toString() );
			str = str.replace( /\r/g, "" );
			return str;
		}
		return s;	
	}
//---------------------------------------------------------
// functionName - startsWith 	- checks to see if a string starts with another string
//
// Description
// arguments	- str - any string
//				- start - the "start" string
// returns		- a boolean with the correct state
	startsWith = function( str, start )  {
		var s = str.substr( 0, start.length );
		return( s == start );
	}
//---------------------------------------------------------
// functionName - unQuote		- removes a double quotes from the ends of a string
//
// Description
// arguments	- any string
// returns		- a string without quotes on the ends
	unQuote = function( str )  {
		var s = new String( str );
		if ( ( s.charAt( 0 ) == '"' ) && ( s.charAt( ( s.length - 1 ) ) == '"' ) )  {
			return s.subString( 1, ( s.length - 2 ) ).toString();			
		}
		return str;		
	}
//---------------------------------------------------------
// functionName - contains 	- returns boolean true if a string contains a substring
//
// Description
// arguments 	- str - any string
//				- ch - a token string
// returns		- a boolean
// 
	contains = function( str, ch )  {
		s = new String( str );
		var idx = s.indexOf( ch );
		return idx > -1;
	}
//---------------------------------------------------------
// functionName - getCharsBefore 	- returns the characters before a token string
//
// Description
// arguments 	- str - any string
//				- ch - a token string
// returns		- a string of the characters before the token, the entire string
//				  if the token does not exist in the string
// NOTE: function trims whitespace on the subject string!!
	getCharsBefore = function( str, ch )  {
		s = new String( trim( str ) );
		var idx = s.indexOf( ch );
		if (idx == -1 )  {
			return s.toString();
		} else {
			return s.substr( 0, idx );		
		}
	}
//---------------------------------------------------------
// functionName - getCharsAfter 	- returns the characters after a token string
//
// Description
// arguments 	- str - any string
//				- ch - a token string
// returns		- a string of the characters after the token, an empty string
//				  if the token does not exist in the string
// NOTE: function trims whitespace on the subject string!!
	getCharsAfter = function( str, ch )  {
		s = new String( trim( str ) );
		var idx = s.indexOf( ch );
		if (idx == -1 )  {
			return "";
		} else {
			return s.substr( ( idx + ch.length ) );		
		}
	}
	
//---------------------------------------------------------
// functionName - pathinfo 	- returns object of path elements from absoluteURI formatted string
//
// Description
// arguments 	- str - any URI formatted string
// returns		- a object with 3 properties:
//				  dirname: the directory info for the file
//				  basename: the basename without extension of the file
//				  extension: the extension for the file
	function pathinfo(fname) {
		var dot = fname.lastIndexOf('.');
		if (dot == -1) dot = fname.length;
		var out = {};
		out.dirname = fname.substring(0, fname.lastIndexOf('/'));
		out.basename = fname.substring(fname.lastIndexOf('/'), dot);
		out.extension = fname.substr(dot+1);
		return out;
	}

//---------------------------------------------------------
// functionName - replace	- executes a string replace
// Description
// replace	- executes a string replace
// arguments	- s1 - the source string (the one to have something replaced)
//				- s2 - the search string (what you want replaced)
//				- s3 - the replace string (what you want to replace it with)
// returns		- the source string with s2 replaced by s3
	replace = function( s1, s2, s3 )  {
		if ( isValidReference( s1 ) && isValidReference( s2 ) )	 {
			var grep = new RegExp( s2, "g" );
			if ( !isValidReference( s3) )  {
				s3 = "";
			}
			try {
				s1 = s1.replace( grep, s3 );
			} catch ( e ) {
				alert( e );
			}
		}
		return s1;
	}
//---------------------------------------------------------
// functionName - arrayRemove	- removes an indexed item from an array
// Description 
// arguments	- ar - any array
//				- idx - the index of the item to be removed
// returns		- an array of ar, with the item at idx removed
// note: using JS provided Array.splice or Array.pop does not change the length
// of an Array. This function returns a new array, with the correct length
	arrayRemove = function( ar, idx )  {
		if ( idx > ar.length || idx < 0 ) {
			throw AdobeLibraryStrings.indexBoundsError;
		}
		var nr = new Array( 0 );
		for ( var i = 0; i < ar.length ; i++ ) {
			if ( i != idx )  {
				nr.push( ar[ i ] );
			}
		}
		return nr;
	}
//---------------------------------------------------------
// functionName - arrayRemoveMultiple - removes multiple items from an Array
// Description 
// arguments	- ar - any array
//				- ir - an array of items you want removed from ar
// returns		- an array of ar, less the items in ir
// note: using JS provided Array.splice or Array.pop does not change the length
// of an Array. This function returns a new array, with the correct length
// "ir" is an array of values to be removed from the array, NOT indexes
	arrayRemoveMultiple = function( ar, ir )  {
		var nr = new Array( 0 );
		for ( var i = 0; i < ar.length ; i++ ) {
			if ( getArrayIndex( ir, i ) == -1 )  {
				nr.push( ar[ i ] );
			}
		}
		return nr;
	}
//---------------------------------------------------------
// functionName - getArrayIndex	- returns the index of a value in the array
// Description 
// arguments		- arr - an array
// 	 				- val - a value to find in the array
// returns			- the index of the value in the array, -1 if not found
	getArrayIndex = function( arr, val )  {
		for ( var i = 0; i < arr.length ; i++ ) {
			if ( arr[i] == val )	 {
				return i;
			}
		}
		return -1;
	}
//---------------------------------------------------------
// functionName - arrayMove	- moves an element from one index to another
// Description 
// arguments		- ar - an array
// 	 				- oldIndex - index of element to move
//					- newIndex - index of where that element will move
// returns			- new array with things "just right"
arrayMove = function( ar, oldIndex, newIndex ) {
	if ( newIndex > ar.length || newIndex < 0 ) {
		throw AdobeLibraryStrings.indexBoundsError;
	}
	if ( oldIndex > ar.length || oldIndex < 0 ) {
		throw AdobeLibraryStrings.indexBoundsError;
	}
	var x = ar[ oldIndex ];
	var res = new Array();
	for ( var i = 0; i < ar.length; i++ ) {
		if ( oldIndex < newIndex ) {
			if ( i != oldIndex ) {
				res.push( ar[ i ] );
			}
			if ( i == newIndex ) {
				res.push( x );
			}
		} else {
			if ( i == newIndex ) {
				res.push( x );
			}
			if ( i != oldIndex ) {
				res.push( ar[ i ] );
			}
		}
	}
	return res;
}
//--------------------------------------------------------------------
// UTILITY Object (Class) Definitions
//--------------------------------------------------------------------
//---------------------------------------------------------
// Class Name - Iterator - similar to Java's Iterator object
// Description 
// takes an array, and iterates through it
// Usage:
//  var it = new Iterator( myFavoriteArray );
//  while ( it.hasNext() ) {
//    var aValue = it.nextItem();
//    // do something here
//  }
	function Iterator( anArray ) {
		this.ar = anArray;
		this.ix = -1;
	}
// methods
	Iterator.prototype.hasNext = function() {
		return ( this.ix < ( this.ar.length - 1 ) );
	}
	Iterator.prototype.nextItem = function() {
		return this.ar[ ++this.ix ];
	}
	Iterator.prototype.currentItem = function() {
		if ( this.ix == -1 ) {
			return undefined;
		} else {
			return this.ar[ this.ix ];
		}
	}
	Iterator.prototype.first = function() {
		return this.ar[ 0 ];
	}
	Iterator.prototype.length = function() {
		return ar.length();
	}
	Iterator.prototype.last = function() {
		return this.ar[ ( this.ar.length - 1 ) ];
	}
	Iterator.prototype.item = function( i ) {
		return this.ar[ i ];
	}
//---------------------------------------------------------
// Class Name - Hashtable - similar to Java's Hashtable object
// Description 
// 	handy way to store and retrieve name-value pairs
// Usage:
//  var ht = new Hashtable();
//  ht.put( "frog", "Kermit" );
//  ht.put( "pig", "Miss Piggy" );
//  ht.put( "anothertable", new Hashtable() );
//  var ht2 = ht.get( "anothertable" );
//  ht2.put( "Fred", "Flintstone" );
//  ht2.put( "Barney", "Rubble" );
//  var a = ht.get("PIG" );   <= a now equals Miss Piggy
//  var b = ht.get( "ANoTHERtaBLE" ).get( "fred" );   <= b now equals Flintstone
//  you can turn on case sensitivity by providing "true" as an argument
	function Hashtable( caseSensitive ) {
		this.caseSensitive = caseSensitive || false;
		this.ar = new Array( 0 );
		this.keyList = new Array( 0 );
		this.keyIndex = new Array( 0 );
		this.count = 0;
	}
//methods	
	Hashtable.prototype.isUniqueKey = function( name ) {
		var lowerName = this.caseSensitive ? name : name.toLowerCase();
		for ( var i = 0; i < this.keyList.length; i++ ) {
			if ( this.keyList[ i ] == lowerName ) {
				return false;
			}
		}
		return true;
	}
	Hashtable.prototype.put = function( name, value ) {
		var lowerName = this.caseSensitive ? name : name.toLowerCase();
		this.ar[ lowerName ] = value;
		if ( this.keyIndex[ lowerName ] == undefined )  {
			this.keyIndex[ lowerName ] = this.keyList.length;
			this.keyList.push( lowerName );
			this.count++;
		}
	}			
	Hashtable.prototype.keys = function()  {
		return this.keyList;
	}
	Hashtable.prototype.get = function( name ) {
		var lowerName = this.caseSensitive ? name : name.toLowerCase();
		return this.ar[ lowerName ];
	}

	Hashtable.prototype.getCount = function()  {
		return this.count;
	}
	Hashtable.prototype.remove = function( name )  {
		if ( isValidReference( this.get( name ) ) )  {
			var lowerName = this.caseSensitive ? name : name.toLowerCase();
			var rAr = this.ar.splice( lowerName, 1 );
			var idx = this.keyIndex[ lowerName ];
			var rKeyIndex = this.keyIndex.splice( lowerName, 1 );
			var rKey = this.keyList.splice( idx, 1 );
			this.count--;
		}
	}
// end Hashtable
//---------------------------------------------------------
// Class Name - URL - encapsulates a url string with encoded values
// Description 
// 	makes it easy to construct complex urls
// Usage:
//   var u = new URL( "www.myserver.com", "index.html", "http" );
//   u.addProperty( "fred", "flintstone" );
//   var a = u.toString(); <= a is now: http://www.myserver.com./index.html?fred=flinstone
	function URL( svr, obj, prot ) {
		if ( isValidReference( prot ) ) {
			this.protocol = endsWith( prot, "://" ) ? getCharsBefore( prot, "://" ) : prot;
		} else {
			this.protocol = "http";
		}
		this.server = svr;
		this.object = obj;
		this.uri = protocol + "://" + svr + "/" + obj;
		this.props = new Hashtable();
	}			  
// methods
	URL.prototype.toString = function()  {
		var str = this.uri;
		var iter = this.props.keyIterator();
		var first = true;
		while ( iter.hasNext() ) {
			var k = iter.nextItem();
			var v = this.props.get( k );
			if ( first )  {
				str += "?";
				first = false;
			} else  {
				str += "&";
			}
			str += escape( k ) + "=" + escape( v );		
		}
		return str;
		
	}
	URL.prototype.addProperty = function( k, y ) {
		this.props.put( k, v );
	}
	URL.prototype.clearProperties = function()  {
		this.props = new Hashtable();
	}
// end object URL
//---------------------------------------------------------
// Class Name - Tokenizer - Similar to Java's string tokenizer
// Description 
// 	handy for parsing strings, comma delimited lists, etc.
// Usage:
// var tk = new Tokenizer( "The rain in Spain" );
// while ( tk.hasMoreTokens() ) {
//   var myToken = tk.nextToken();
//   // Do something with myToken
// }
// Defaults to space. Placing any string in token uses that string as the delimiter
// Above example tokenizes on spaces, in the Loop, the first value of myToken is "The",
// it will iterate 4 times through the loop, the last value of myToken is "Spain"
	function Tokenizer( str, token ) {
		this.src = str ||  "";
		this.tk = token || " ";
		this.ar = this.src.split( this.tk );
		this.ix = -1;
	}
// methods
	Tokenizer.prototype.nextToken = function()  {
		return this.ar[ ++this.ix ];		
	}
	Tokenizer.prototype.thisToken = function()  {
		return this.ar[ this.ix ];
	}
	Tokenizer.prototype.hasMoreTokens = function()  {
		return ( this.ix < ( this.ar.length - 1 ) );
	}
// end object Tokenizer

//---------------------------------------------------------
// Class Name - StringBuffer - Similar to Java's StringBuffer
// Description 
// 	Not that useful, but it's here anyway for you Java guys and gals.
// Usage:
//	var sb = new StringBuffer();
//   sb.append( "The" );
//   sb.append( "rain" );
//   sb.append( "in" );
//   sb.append( "Spain" );
//   var b = sb.toString(); <= b == "TheraininSpain"
// constructor, properties, and initial values
	function StringBuffer( aString ) {
		this.str = aString || "";
	}
	StringBuffer.prototype.append = function( st ) {
		if ( !isValidReference( this.str ) ) {
			this.str = "";
		}
		if ( !isValidReference( st ) ) {
			this.str += st;
		}
	}
	StringBuffer.prototype.toString  = function() {
		return this.str;
	}
	StringBuffer.prototype.clear = function()  {
		this.str = "";
	}
	StringBuffer.prototype.length = function()  {
		return this.str.length;
	}
// end object StringBuffer

//---------------------------------------------------------
// Class Name - Stack - Similar to Java's Stack, or the stack function of JS Array
// Description 
// 	Just a stack, but unlike JS Arrays, when you pop, the length is corrent
// Usage:
//   var st = new Stack();
//   st.push( "fred" );		  st.length == 1
//   st.push( "barney" );      st.length == 2
//   st.push( "wilma" );       st.length == 3
//   var a = st.pop();    a == "wilma", st.length == 2
	function Stack(  ) {
		this.stk = new Array( 0 );
	}
	// pushes an object onto the stack
	Stack.prototype.push = function( st ) {
		this.stk.push( st );
	}
	// pops one off
	Stack.prototype.pop = function() {
	// create a new array 
		var a = new Array( 0 );
		for (var i = 0; i < ( this.stk.length - 1 ) ;i++ ) {
			a[i] = this.stk[i];
		}
		var rVal = this.stk.pop();
		this.stk = a;
		return rVal;
	}
	// returns the index of a value in the stack, -1 if not there
	Stack.prototype.search = function( x )  {
		return getArrayIndex( this.stk, x );
	}
	Stack.prototype.toString = function() {
		return this.stk.toString();
	}
	Stack.prototype.length = function( )  {
		return this.stk.length;
	}
// end object Stack
//---------------------------------------------------------
// Class Name - XmlNode - Similar to an XML DOM node, but limited in implementation
// Description 
// implements a limited XmlNode. Does not do CDATA or PCDATA stack. Does not do XMLNS
// But will generate a basic XML file, and allow searching of simple XML data nodes
//
// Usage:
// var doc = new XmlNode( "document" );
// var c = doc.addChildNode( "cartoons" );
// var ch = c.addChildNode( "characters" );
// var f = ch.addChildNode( "fred", "flintstone" );
// var f.addAttribute( "gender", "male" );
// doc.write( new File( "c:\xml\xmlExample.xml" ) );
// 
// output file looks like:
// <?xml version="1.0" encoding="iso-8859-1?>
// <cartoons>
// <characters>
// <fred gender="male">flintstone</fred>
// </characters>
// </cartoons>
	XmlNode = function( tag, value, nParent ) {
		this.tag = tag;
		this.value = value;
		this.parentNode = nParent;
		this.nodeChildren = new Array( 0 );
		this.attr = new Hashtable();
	}
	XmlNode.prototype.getValue = function() {
		return this.value;
	}
	XmlNode.prototype.addChildNode = function( tag, value ) {
		var newNode = new XmlNode( tag, value, this );
		this.nodeChildren.push( newNode );
		return newNode;
	}
	XmlNode.prototype.removeChildren = function() {
		this.nodeChildren = new Array();
	}
	XmlNode.prototype.addAttribute = function( name, value )  {
		this.attr.put( name, value );
	}	
	XmlNode.prototype.getAttributes = function()  {
		return this.attr;
	}
	XmlNode.prototype.getAttribute = function( name ) {
		return this.attr.get( name );
	}
	XmlNode.prototype.setAttributes = function( ht )  {
		this.attr = ht;
	}
	XmlNode.prototype.writeAttributes = function() {
//		var ki = this.attr.keyIterator();
//		ki.dump( this.tag );
		var attrStr = '';
//		while ( ki.hasNext() ) {
		for ( var i = 0; i < this.attr.keyList.length; i++ ) {
//			var thisAttr = ki.nextItem();
//			attrStr += ' ' + thisAttr + '="' + encode( this.attr.get( thisAttr ) ) + '"' ;
			attrStr += ' ' + this.attr.keyList[ i ] + '="' + escape( this.attr.get( this.attr.keyList[ i ] ) ) + '"' ;
		}	
		return attrStr;
	}
	XmlNode.prototype.write = function( aFile ) {
		var needToClose = true;
		var binary = true;
		if ( this.tag.toLowerCase() == "document" )  {
			aFile.writeln( '<?xml ' + this.writeAttributes() + ' ?>' );
			needToClose = false;
		} else { 
			if ( isValidReference( this.value ) ) {
				binary = ( ( this.value.length != 0 ) || (this.nodeChildren.length > 0 ) );
			} else {
				this.value = "";
				binary = this.nodeChildren.length > 0;				
			}
			if ( !binary )  { // it's tag of style <tag attr="value" />
				needToClose = false;
				aFile.writeln(	'<' + this.tag + this.writeAttributes() + '/>' );
			} else {
				var str = '<' + this.tag + this.writeAttributes() + '>';
				if ( this.value.length > 0 )  {
					str += escape( this.value );
				}
				aFile.writeln( str );				
			}
		}
		for ( var i = 0; i < this.nodeChildren.length; i++ ) {
			this.nodeChildren[ i ].write( aFile );
		}
		if ( needToClose )  {
			aFile.writeln( '</' + this.tag + '>' );
		}
	}
	XmlNode.prototype.findNode = function( fTag, n )  {
		ScriptStore.findNodeCount = isValidReference( n ) ? n : 0;
		for ( var i = 0; i < this.nodeChildren.length; i ++ ) {
			if ( equalsIgnoreCase( this.nodeChildren[ i ].tag, fTag ) )  {
				if ( ScriptStore.findNodeCount <= 0 ) {
					return this.nodeChildren[ i ];
				} else {
					ScriptStore.findNodeCount -= 1;
				}
			}
			var foundNode = this.nodeChildren[ i ].findNode( fTag, ScriptStore.findNodeCount );
			if ( isValidReference( foundNode ) ) {
				return foundNode;
			}
		}
		return undefined;
	}
	XmlNode.prototype.findNodes = function( fTag, anArray )  {
		var theResult = null;
		if ( !isValidReference( anArray ) )  {
			theResult = new Array();
		} else {
			theResult = anArray;
		}
		for ( var i = 0; i < this.nodeChildren.length; i ++ ) {
			if ( equalsIgnoreCase( this.nodeChildren[ i ].tag, fTag ) )  {
				theResult.push( this.nodeChildren[ i ] );
			}
			this.nodeChildren[ i ].findNodes( fTag, theResult );
		}
		return theResult;
	}
// end object XmlNode
//---------------------------------------------------------
// Class Name - FileTree - creates, stores, and manipulates a map of selected files in Bridge
//              
// Description 
//   This is intended to work with a ScriptUI listbox control (could work with a drop down I guess).
//   The idea is to take whatever user selected in bridge, and display in a list box. If they click a
//   "recursive" button, set recursive to true, and it will traverse all folder objects
//
// Usage:
//    myDialog.tree = new FileTree( myDialog.listbx, app.document, true ); // app.document is from the Bridge DOM
//    myDialog.tree.refresh();
//    
//    After the user has dismissed the dialog,
//    var fileArray = myDialog.tree.getFileList();
//    returns an array of files
ThumbnailTree = function( control, doc, recursive, prune, filter ) {
	this.control = control || undefined;
	this.doc = doc || undefined;
	this.recursive = recursive || false;
	this.prune = prune || false;
	this.filter = filter || undefined;
	if ( isValidReference( app.document ) ) {
		this.base = File.decode( app.document.thumbnail.resolve().relativePath() );
	}
	this.children = undefined;
}

ThumbnailTree.prototype.refresh = function()  {
//$.level = 1;
//debugger;
	this.children = new Array();
	if ( !isValidReference( this.doc ) ) {
		var thumbs = getBridgeThumbnails( this.filter, false ); // get thumbnails selected in bridge, do not head downline
		for ( var i = 0; i < thumbs.length; i++ ) {
			if ( equalsIgnodeCase( thumbs[ i ].location, "versioncue" ) ) {
				this.children.push( new ThumbnailTreeNode( undefined, thumbs[ i ], this.base, this ) );
			} else {
				this.children.push( new FileTreeNode( undefined, thumbs[ i ].spec, this.base, this ) );
			}
		}
	} else {
		if ( this.doc instanceof Array ) {
			for ( var i = 0; i < this.doc.length; i++ ) {
				if  ( ( this.doc[ i ] instanceof Folder ) || ( this.doc instanceof File ) ) {
					this.children.push( new FileTreeNode( undefined, this.doc[ i ], this.base, this ) );
				} else {
					if ( this.doc[ i ] instanceof Thumbnail ) {
						if ( equalsIgnoreCase( this.doc[ i ].location, "versioncue" ) ) {
							this.children.push( new ThumbnailTreeNode( undefined, this.doc[ i ], this.base, this ) );
						} else {
							this.children.push( new FileTreeNode( undefined, this.doc[ i ].spec, this.base, this ) );
						}
					}
				}
			}
		} else if ( ( this.doc instanceof Folder ) || ( this.doc instanceof File ) ) {
			this.children.push( new FileTreeNode( undefined, this.doc, this.base, this ) );
		} else if ( this.doc instanceof Thumbnail ) {
			if ( equalsIgnoreCase( this.doc.location, "versioncue" ) ) {
				this.children.push( new ThumbnailTreeNode( undefined, this.doc, this.base, this ) );
			} else {
				this.children.push( new FileTreeNode( undefined, this.doc.spec, this.base, this ) ) ;
			}
		} else if ( ( this.doc instanceof Document ) ) {
			var thumbs = getBridgeThumbnails( this.filter, false ); // get thumbnails selected in bridge, do not head downline
			for ( var i = 0; i < thumbs.length; i++ ) {
				if ( equalsIgnoreCase( thumbs[ i ].location, "versioncue" ) )  {
					this.children.push( new ThumbnailTreeNode( undefined, thumbs[ i ], this.base, this ) );
				} else {
					this.children.push( new FileTreeNode( undefined, thumbs[ i ].spec, this.base, this ) );
				}
			}
		} else {
			throw "Invalid object";
		}
	}
	if ( this.recursive )  {
		for ( var i = 0; i < this.children.length ; i++ ) { // fill the tree recursively
			this.children[ i ].populate( this.filter );
		} 
	}
	this.addToControl( this.prune ); // fill the list box
}
ThumbnailTree.prototype.addToControl = function( prune ) {
	if ( isValidReference( this.control ) ) {
		this.control.selection = null;
		this.control.removeAll();
		for ( var i = 0; i < this.children.length ; i++ ) { // fill the listbox
			this.children[ i ].addToControl( this.control, "", prune );
		}
	}
}
ThumbnailTree.prototype.removeSelection = function( selection ) {
	var sel = selection;
	if ( ( sel instanceof Array ) ) {
		sel = [ sel ];
	}
	for ( var i = 0; i < sel.length; i++ ) {
		this.remove( trim( sel[ i ] ) );
	}
	this.addToControl( this.prune );
}
ThumbnailTree.prototype.remove = function( text )  { //selection is an array of list items
	for ( var i = 0; i < this.children.length ; i++ ) { // against each child
		if ( trim( this.children[ i ].text ) == text )  {
			this.children = arrayRemove( this.children, i ); // remove the bad child
			break;  // since these should be unique, return
		} else {
			if ( this.children[ i ].remove( text ) )  {
				break;	
			} // if not this child, check progeny
		}
	}
}
ThumbnailTree.prototype.removeSingleton = function( selection )  {
	this.remove( trim( selection.text ) );
	this.addToControl( this.prune );
}
ThumbnailTree.prototype.move = function( selection, up ) {
// note this assumes there is only one selected item
	if ( selection.length > 1 ) {
		throw AdobeLibraryStrings.MoveOneError;
	}
	for ( var i = 0; i < this.children.length ; i++ ) { // against each child
	// these children are top level hierarchy, can't move up,
		if ( this.children[ i ].text == selection.text )  {
			if ( up ) {
				if ( i > 0 ) {
					this.children = arrayMove( this.children, i, ( i - 1 ) ); // move up
				}
			} else {
//			debugger;
				if ( i < ( this.children.length - 1 ) ) {
					this.children = arrayMove( this.children, i, ( i + 1 ) ); // move down
				}
			}
			break;  // since these should be unique, return
		} else {
			if ( this.children[ i ].move( selection.text, up ) )  {
				break;	
			} // if not this child, check progeny
		}
	}
	this.addToControl();
}
ThumbnailTree.prototype.getFileList = function( includeFolders )  {
	var anArray = new Array();
	var pathList = new Array();
	for ( var i = 0; i < this.children.length ; i++ ) { // fill the listbox
		anArray = this.children[ i ].getFileList( anArray, pathList, includeFolders );
	}
	app.preflightFiles( pathList );
	return anArray;
}
ThumbnailTree.prototype.findSelectedNode = function( selection ) {
	return this.findNode( trim( selection.text ) );
}
ThumbnailTree.prototype.findNode = function( text ) {
	for ( var i = 0; i < this.children.length; i++ ) {
		if ( this.children[ i ].text == text ) {
			return this.children[ i ];
		} else {
			var ans = this.children[ i ].findNode( text );
			if ( isValidReference( ans ) ) {
				return ans;
			}
		}
	}
	return undefined;
}



ThumbnailTreeNode = function( parent, obj, baseDir, fileTree ) {
//$.level =1;
//debugger;
	this.parent = parent || undefined;
	this.obj = obj || undefined;
	this.base = baseDir || undefined;
	this.tree = fileTree || undefined;
//	this.suffix = this.thumbnail.isFileNode() ? "  (file)" : "  (folder)";
	if ( isValidReference( this.obj ) ) {
		this.text = File.decode( this.relativePath( this.base ) );
	}
	this.children = new Array();
	this.cacheChildren();
}
ThumbnailTreeNode.prototype.relativePath = function( base )  {
	return this.obj.relativePath( base );
}
ThumbnailTreeNode.prototype.cacheChildren = function()  {
	if ( isValidReference( this.obj ) ) {
		if ( this.obj instanceof Thumbnail )  {
			this.objChildren = this.obj.children;
		} else {
			if ( this.obj instanceof Folder )  {
				this.objChildren = this.obj.getFiles();
			}
		}
	}
}
ThumbnailTreeNode.prototype.hasAChildFileSomewhere = function() {
	if ( AdobeLibrary1.isFile( this.obj ) ) {
		return true;
	}
	for ( var i = 0; i < this.children.length; i++ ) {
		var result = this.children[ i ].hasAChildFileSomewhere();
		if ( result ) {
			return true;
		}
	}	
	return false;
}
ThumbnailTreeNode.prototype.findNode = function( text ) {
	if ( trim( this.text ) == trim( text ) ) {
		return this;
	}
	for ( var i = 0; i < this.children.length; i++ ) {
		var ans = this.children[ i ].findNode( text );
		if ( isValidReference( ans ) ) {
			return ans;
		}
	}
	return undefined;
}
ThumbnailTreeNode.prototype.getFileList = function( anArray, paths, includeFolders )  {
	if ( AdobeLibrary1.isFile( this.obj ) || includeFolders ) {
		paths.push( this.obj.path );
		anArray.push( new File( encodeURI( this.obj.spec ) ) );	// sending back an array of file or folder objects
	}
	for ( var i = 0; i < this.children.length ; i++ ) { // fill the array by traversing filetreenodes
		anArray = this.children[ i ].getFileList( anArray, paths, includeFolders );
	}
	return anArray;
}
ThumbnailTreeNode.prototype.addToControl = function( control, spacer, prune )  {
	if ( AdobeLibrary1.isFile( this.obj ) || ( this.hasAChildFileSomewhere() || !prune ) ) {
		control.add( "item", spacer + this.text );
		for ( var i = 0; i < this.children.length ; i++ ) {
			this.children[ i ].addToControl( control, spacer + "  ", prune );
		}
	}
}
ThumbnailTreeNode.prototype.populate = function( filter )  {
	for ( var i = 0; i < this.objChildren.length; i ++ ) {
		var thumb =  this.objChildren[ i ];
		if ( !isValidReference( thumb.aliasType ) ) { // skip alias's's's down here in hierarchy - avoid loops...
			if ( thumb.isFileType( filter ) ) {
				var newNode = this.add( thumb );
			} else if ( AdobeLibrary1.isFolder( thumb ) ) {
				var newNode = this.add( thumb );
				newNode.populate( filter );	
			}
		}
	}
}
ThumbnailTreeNode.prototype.add = function( thumbnail )  {
	var newNode = new ThumbnailTreeNode( this, thumbnail, this.base, this.tree );
	this.children.push( newNode );
	return newNode;
}
ThumbnailTreeNode.prototype.remove = function( text )  { // returning true stops the loop the remove in FileNode.remove()
	for ( var i = 0; i < this.children.length ; i++ ) {
		if ( trim( this.children[ i ].text ) == trim( text ) )  {
			this.children = arrayRemove( this.children, i );
			return true;
		} else {
			if ( this.children[ i ].remove( text ) )  {
				return true;
			}
		}
	}
	return false;
}
ThumbnailTreeNode.prototype.move = function( text, up )  { // returning true stops the loop the remove in FileNode.remove()
	for ( var i = 0; i < this.children.length ; i++ ) {
		if ( trim( this.children[ i ].text ) == trim( text ) )  {
			if ( up ) {
				if ( i > 0 ) {
					this.children = arrayMove( this.children, i, ( i - 1 ) );
				}
			} else {
				if ( i < ( this.children.length - 1 ) ) {
					this.children = arrayMove( this.children, i, ( i + 1 ) );
				}
			}
			return true;
		} else {
			if ( this.children[ i ].move( text, up ) )  {
				return true;
			}
		}
	}
	return false;
}


FileTree = function( control, doc, recursive, prune, filter )  {
	this.ancestor = ThumbnailTree;
	this.ancestor( control, doc, recursive, prune, filter );
}
FileTree.prototype = new ThumbnailTree;
// end class FileTree

//---------------------------------------------------------
// Class Name - FileTreeNode - Helps FileTree do it's thing
//              
// Description 
//   you should never have to use this class by itself
//

FileTreeNode = function( parent, obj, baseDir, fileTree )  {
	this.ancestor = ThumbnailTreeNode;
	this.ancestor( parent, obj, baseDir, fileTree );
}
FileTreeNode.prototype = new ThumbnailTreeNode;

FileTreeNode.prototype.relativePath = function( base )  {
	var sufx = ( this.obj instanceof Folder ) ? "/" : "";
	return File.decode( this.obj.getRelativeURI( this.base ) + sufx );
}

FileTreeNode.prototype.hasAChildFileSomewhere = function() {
	if ( this.obj instanceof File ) {
		return true;
	}
	for ( var i = 0; i < this.children.length; i++ ) {
		var result = this.children[ i ].hasAChildFileSomewhere();
		if ( result ) {
			return true;
		}
	}	
	return false;
}
FileTreeNode.prototype.getFileList = function( anArray, paths, includeFolders )  {
	if ( ( this.obj instanceof File ) || includeFolders ) {
//		paths.push( this.obj.absoluteURI );
		anArray.push( this.obj );	// sending back an array of file or folder objects
	}
	for ( var i = 0; i < this.children.length ; i++ ) { // fill the array by traversing filetreenodes
		anArray = this.children[ i ].getFileList( anArray, paths, includeFolders );
	}
	return anArray;
}
FileTreeNode.prototype.populate = function( filter )  {
	if ( this.obj instanceof Folder )  {  // files have no children...
		var files = this.obj.getFiles(); // get the files it contains
	  	for ( var i = 0; i < files.length; i++ ) { 
	  		if ( files[ i ] instanceof File ) {
				if ( files[ i ].isFileType( filter ) && !files[ i ].alias )  {
					var tn = this.add( files[ i ] );
				}
	 		} else { // itsa folder
	 			var tn = this.add( files[ i ] ); // add a child node to this node
				tn.populate( filter ); // populate the new node - note if it's a file it's a quick return!
	  		}
	  	}
	}
}
FileTreeNode.prototype.add = function( obj )  {
	var tn = new FileTreeNode( this, obj, this.base, this.tree );
	this.children.push( tn );
	return tn;
}
FileTreeNode.prototype.addToControl = function( control, spacer, prune )  {
	if ( ( this.obj instanceof File ) || ( this.hasAChildFileSomewhere() || !prune ) ) {
		control.add( "item", spacer + this.text );
		for ( var i = 0; i < this.children.length ; i++ ) {
			this.children[ i ].addToControl( control, spacer + "  ", prune );
		}
	}
}
//---------------------------------------------------------
// Class Name - BAScriptMenu - encapsulates some common menu functions
//              
// Description 
//  make menu commands easier to create and manage and dodges some namespace issues
//	also makes it easy to control menu availability depending on selected file type
//	if JS had subclasses, this would be a subclass of the MenuElement
// Usage:
//	var PSSaveForWeb =  new BAScriptMenu( "command", "Save For Web",	"at the end of Photoshop",	"PSSaveForWeb");
//	PSSaveForWeb.setEnabledForTypes(TYPES.PHOTOSHOP);
//	PSSaveForWeb.onSelect = function() { }
function BAScriptMenu( type, text, where, id )  {
	this.enabledForTypes = false;
	this.target = false;
	this.text = text;
	var self = this;		// so we can make a reference back to this object
	this.menu = createMenu(type, text, where, id, function() {self.onSelect()}, function() {self.onDisplay()});		// reference the menu
	this.menu.parent = self;
	
}

BAScriptMenu.prototype.setEnabledForTypes = function(types) {
	this.enabledForTypes = types;
}

BAScriptMenu.prototype.setTarget = function(target) {
	this.target = target;
}

BAScriptMenu.prototype.onDisplay = function() {
// until this is hammered out, just enable and return.
this.menu.enabled = true;
return;

	if (this.enabledForTypes == false) {
		this.menu.enabled = true;
	} else {
		var files = WASSelection.getSelectedOfType(this.enabledForTypes);
		this.menu.enabled = (files.length > 0);
	}
}

BAScriptMenu.prototype.onSelect = function() {
	var files, it, value;
	files = getBridgeFiles(this.enabledForTypes, true, true);

	if (files.length) {
		BridgeTalk.bringToFront( this.target );

		var bti = new BridgeTalkIterator( true, this.text, this.text, false );
		for ( var i = 0; i < files.length; i++ ) {
			if ( files[ i ] instanceof File ) {
				var theScript = this.getScript( files[ i ] );
				bti.addMessage( this.target, theScript, files[ i ].name );
			}
		}
		bti.send();
	} else {
		alert(AdobeLibraryStrings.noFileSelected.replace(/ScriptName/g, this.text));
	}	
}


BAScriptMenu.prototype.sendSimpleBTMsg = function( target, args )  {
	try {
		var bt = new BridgeTalk();
		bt.target = target;
		// the script to evaluate is assigned to the "body" property,
		bt.body = this.getScript( args );
		if (bt.body == false) return;


	} catch (a ) {
		alert( AdobeLibraryStrings.failedToSendMessage + a );
	}



	bt.onError = function( r )  {
		alert( TranslateErrorCodes.get( r.headers ["Error-Code"] ) );
	}
	try {
		if ( startTargetApplication( target ) ) {
			bt.send();
		}
	} catch ( e ) {
		alert( e );
	}
}

//---------------------------------------------------------
// Class Name - TranslateErrorCodes - a static class to translate BridgeTalk error codes in to English
//	this is a legacy class from the days when error messages were not included in BT messages. Not really
//  all that useful now, but it's here to make sure older scripts don't break.
//              
// Description 
//   BridgeTalk errors are returned as integer codes. This makes 'em English
// Usage:
//   var bt = new BridgeTalk();   
//	bt.onError = function( r )  {
//		alert( TranslateErrorCodes.get( r.headers ["Error-Code"] ) );
//	}
// OR
//   var bt = new BridgeTalk();   
//	bt.onError = function( r )  {
//		alert( TranslateErrorCodes.getMessage( r ) );
//	}
var TranslateErrorCodes = {};
TranslateErrorCodes.getMessage = function( btObj )  {
	var s = btObj.body;
	return AdobeLibraryStrings.btError + ": " + s;
}
// end class TranslateErrorCodes
//---------------------------------------------------------
// Class Name - FIFOBuffer - a simple first in, first out buffer
//              
// Description 
//   use push and pop to put things in and get them out
//  pop returns objects in the order they were put in
//  returns undefined if the buffer is empty.
// Usage:
//   var buf = new FIFOBuffer();   
//	 buf.push( "Fred" );
//   buf.push( "Barney" );
//   var n = buf.pop();  n == "Fred", next pop would be Barney
//
FIFOBuffer = function() {
	this.buffer = new Array();
	this.length = 0;
}
FIFOBuffer.prototype.push = function( obj ) {
	this.buffer.push( obj );
	this.length = this.buffer.length;
}
FIFOBuffer.prototype.pop = function() {
	if ( this.buffer.length == 0 ) {
		return undefined;
	}
	var rval = this.buffer[ 0 ];
	this.buffer = arrayRemove( this.buffer, 0 );
	this.length = this.buffer.length;
	return rval;
}
//---------------------------------------------------------
// functionName - messageDialog	- slaps up a palette with your message in it
// Description 
// arguments		- text - the text to display
// 	 				- title - the window title of the palette
//	returns - a reference to the message palette - NOTE: it SHOWS the palette for you
MessageDialog = function( text, title ) {
	var d = new Window( "palette", title );
	d.staticText = d.add( "statictext",undefined, text );
	d.staticText.preferredSize = [300,20];
	d.staticText.justify = "center";
	d.center();
	d.show();
	return d;
}
//---------------------------------------------------------
// functionName - progressDialog	- creates a progress PALETTE...
// Description 
// arguments		- text - the first line of 2 text lines for user info
// 	 				- title - the window title of the palette
//					- max - the max number of units for the progress bar
//					- autoClose - whether to automatically close on completion
//					- btnText - the text of the ONE button on the palette
//	returns - a reference to the progress palette - NOTE: it SHOWS the palette for you
progressDialog = function( text, title, max, autoClose, btnText ) {
	this.buttonText = isValidReference( btnText ) ? btnText : AdobeLibraryStrings.cancel;
	this.windowTitle = isValidReference( title) ? title : AdobeLibraryStrings.progress;
	this.maxValue = isValidReference( max ) ? max : 100;
	this.d = new Window( "palette", windowTitle, [500,300,820,440] );
	d.staticText = d.add( "statictext",[10,0,290,20], text );
	d.staticText.justify = "center";
	d.statusText = d.add( "statictext",[10,30,290,50], "" );
	d.statusText.justify = "center";
	d.statusText2 = d.add( "statictext",[10,50,290,70], "" );
	d.statusText2.justify = "center";
	d.progress = d.add( "progressbar",[ 20,80,280,90] );
	d.cancelBtn = d.add( "button",[120,100,200,120], btnText );
	d.progress.maxvalue = maxValue;
	d.progress.value = 0;
	d.cancelled = false;
	d.cancelBtn.onClick = function() {
		this.parent.cancelled = ( this.parent.progress.value < this.parent.progress.maxvalue );
		this.parent.close();
	}
	d.onClose = function() {
	}
	d.setValue = function( val ) {
		var numValue = parseInt( val );
		if ( isNaN( numValue ) ) {
			throw AdobeLibraryStrings.numericValue;
		}
		this.progress.value = numValue;
		if ( this.progress.value >= this.progress.maxvalue ) {
			if ( autoClose ) {
				this.setText( AdobeLibraryStrings.complete );
				this.cancelBtn.text = AdobeLibraryStrings.complete;
				$.sleep( 1500 );
				this.close();
			} else {
				this.setText( AdobeLibraryStrings.complete );
				this.cancelBtn.text = AdobeLibraryStrings.complete;
			}
		}
	}
	d.setComplete = function() {
		this.setValue( this.progress.maxvalue );
	}
	d.increment = function() {
		this.setValue( ++d.progress.value );
	}
	d.setText = function( txt ) {
		this.staticText.text = this.checkStringWidth( txt );
	}
	d.setStatus = function( txt, truncate, action ) {
		if ( isValidReference( truncate ) ) {
			if ( truncate ) {
				this.statusText.text = this.checkStringWidth( txt, action );
				this.statusText2.text = "";
			} else {
				this.splitString( txt );
			}
		} else {
				this.splitString( txt );
		}
	}
	d.splitString = function( str, action) {
		var w = this.stringWidth( str );
		if ( w > 280 ) {
			var idx = Math.round( str.length / 2 ) - 5;
			idx = str.indexOf( " ", idx );
			if ( idx == -1 ) {
				this.statusText.text = this.checkStringWidth( str, action )
				this.statusText2.text = "";
			} else {
				this.statusText.text = str.substring( 0, idx );
				this.statusText2.text = str.substr( idx );
			}
		} else {
			this.statusText.text = str;
		}
	}
	d.stringWidth = function( str ) {
		var temp = this.add( "statictext", undefined, str );
		var w = temp.preferredSize.width + 2; // there's a 2 pixel bug in the call
		this.remove( temp );
		return w;
	}
	d.checkStringWidth = function( txt, action ) {
		var prefix = isValidReference( action ) ? action + ":" + " " : "";
		var w = this.stringWidth( prefix + txt );
		var res = prefix + txt;
		if ( w >= 280 ) {
			var idx = Math.round( ( ( ( w - 280 ) * res.length ) / w ) + 3 );
			res = prefix + "..." + txt.substr( idx );
		}
		return res;
	}
	d.show();
	return d;
}

//---------------------------------------------------------
// 	Class Name - Progress Error Palette - 
//	allows the placing of multiple error message into a single error palette

AdobeLibrary1.palette = undefined;
ProgressErrorPalette = function( title ) {
	var paletteTitle = isValidReference( title ) ? title : localize( "$$$/WAS/Library/stdErrMessageTitle=Encountered Errors During Processing" );
	this.palette = new Window( "palette", title );
	this.palette.location = [100,100];
	this.palette.orientation = "column";
	this.stat = this.palette.add( "statictext", undefined, localize( "$$$/WAS/Library/stdErrMessage=An Error ocurred while processing the listed files:" ) );
	this.list = this.palette.add( "listbox",undefined, undefined, {multiselect:false} );
	this.list.preferredSize = [280,100];
	var props = {};
	props.readonly = false;
	props.multiline = true;
	this.showDetail = this.palette.add( "checkbox", undefined, localize( "$$$/WAS/Library/showDetail=Show Details" ) );
	this.detail = this.palette.add( "edittext",undefined, undefined, props );
	this.showDetail.value = false;
	this.detail.visible = false;
	this.detail.preferredSize = [280,100];
	this.showDetail.detail = this.detail;
	this.errList = new Hashtable( true );
	this.list.errList = this.errList;
	this.list.detail = this.detail;
	this.list.onChange = function() {
//		alert( this.selection.text );
		if ( isValidReference( this.selection ) ) {
			this.detail.text = this.errList.get( this.selection.text );
		}
	}
	this.showDetail.onClick = function() {
		this.detail.visible = this.value;
	}

}
ProgressErrorPalette.prototype.show = function() {
	this.palette.show();
}
ProgressErrorPalette.prototype.close = function() {
	this.palette.close();
}
ProgressErrorPalette.prototype.hide = function() {
	this.palette.hide();
}
ProgressErrorPalette.prototype.updateList = function() {
	this.list.removeAll();
	var lastItem = undefined;
	for ( var i = 0; i < this.errList.keyList.length; i++ ) {
		lastItem = this.list.add( "item", this.errList.keyList[ i ] );
	}
	lastItem.selected = true;
}
ProgressErrorPalette.prototype.addError = function( key, err ) {
	this.errList.put( key, err );
	this.updateList();	
}
//---------------------------------------------------------
// 	Class Name - BridgeTalkIterator - 
//	Sends multiple bridgetalk messages, one after another, with an option
//	for a progress bar to be shown during the iteration. Progress bar
//	has an "n" of "total" status line( n / total ) for each iteration.
//  handled errors in individual units of the iteration, and reports back
//	error information.
// 	BridgeTalkIterator handles the progress bar itself, You do NOTHING
// 	In the iteration, you CAN (don't know why you would) send messages to different
//	target applications.
//
//  Usage:
//	getScript = function( file ) [
//		...code to generate a script based upon a passed file name
//	}
//	var target = "photoshop";
//	var showProgress = true;
//	var notifyComplete = false;
//	var progressTextLine = "Doing Something Now";
//	var progressWindowTitle = "Doing Something";
//	var bti = new BridgeTalkIterator( showProgress, progressTextLine, progressWindowTitle, notifyComplete );
//	for ( var i = 0; i < files.length; i++ ) {
//		var scp = getString( files[ i ] );
//		bti.add( target, scp );
//	}
//	bti.send();
//
BridgeTalkIterator = function( showProgress, text, title, notifyComplete ) {
	this.text = text;
	this.title = title;
	this.showProgress = showProgress;
	this.notifyComplete = notifyComplete;
	this.progress = undefined;
	this.messageBuffer = new FIFOBuffer();
	this.firstMessageSent = false;
	this.errored = false;
	this.errorArray = new Array();
	this.count = 1;
	this.total = 0;
}
BridgeTalkIterator.prototype.addMessage = function( target, script, fileName ) {
	var bt = new BridgeTalk();
	bt.target = target;
	bt.body = script;
	bt.fileName = File.decode( fileName );
	this.messageBuffer.push( bt );
	this.total++;
}
BridgeTalkIterator.prototype.increment = function() {
	if ( this.count < this.total ) {
		this.count++;
	}
}
BridgeTalkIterator.prototype.send = function() {
	if ( this.messageBuffer.length > 0 ) {
		if ( this.showProgress ) {
			if ( !isValidReference( this.progress ) ) {
				this.progress = progressDialog( this.text, this.title, this.messageBuffer.length, true, AdobeLibraryStrings.cancel );
				var txt = this.count + " / " + this.total;
				this.progress.setStatus( txt );
			} 
		}
		var bt = this.messageBuffer.pop();
		bt.wrapper = this;
		bt.onResult = function( btObj ) {
			this.wrapper.increment();
			if ( this.wrapper.showProgress ) {
				var txt = this.wrapper.count + " / " + this.wrapper.total;
				this.wrapper.progress.setStatus( txt );
				this.wrapper.progress.increment();
			}
			this.wrapper.send();
		}
		bt.onError = function( btObj ) {
			this.wrapper.errorArray.push( this.wrapper.count );
			this.wrapper.increment();
			if ( !this.wrapper.errored ) {
				this.wrapper.errorPalette = new ProgressErrorPalette( localize( "$$$/WAS/Library/stdErrMessageTitle2es=Encountered Errors During Processing" ) );
				AdobeLibrary1.palette = this.wrapper.errorPalette;
				this.wrapper.errorPalette.show();
			}
			this.wrapper.errored = true;
			var errName = localize("$$$/WAS/Lib/iterationWord=Iteration " ) +  (this.wrapper.count - 1 )
			if ( isValidReference( this.fileName ) ) {
//				errName = localize("$$$/WAS/Lib/errMessagepalette1=Error when processing file: " ) + this.fileName;
				errName = this.fileName;
			} 
			var errMessage = localize( "$$$/WAS/Lib/errFailureOnFile=The error message was: " ) + "\r\n\r\n" + btObj.body;
			this.wrapper.errorPalette.addError( errName, errMessage );
			if ( this.wrapper.showProgress ) {
				var txt = errName;	
				this.wrapper.progress.setText( txt );
				app.beep();
				wait( 1500 );
				var txt = this.wrapper.count + " / " + this.wrapper.total;
				this.wrapper.progress.setStatus( txt );
				this.wrapper.progress.increment();
			}
			this.wrapper.send();
		}
		if ( this.showProgress ) {
			if ( !this.progress.cancelled ) {
				if ( !startTargetApplication( bt.target ) ) {
					this.progress.close();
					return;
				}
				if ( !this.firstMessageSent ) {
					BridgeTalk.bringToFront( bt.target );
				}
				bt.send();
				this.firstMessageSent = true;
			}
		} else {
			if ( !startTargetApplication( bt.target ) ) {
				return;
			}
			if ( !this.firstMessageSent ) {
				BridgeTalk.bringToFront( bt.target );
			}
			bt.send();
			this.firstMessageSent = true;
		}
	} else {
		if ( this.showProgress ) {
			this.progress.setComplete();
			this.progress.close();
		}
		if ( this.notifyComplete ) {
			alert( AdobeLibraryStrings.operationComplete );
		}
	}
}
//---------------------------------------------------------
// 	Class Name - BridgeTalkLongProcess - 
//	Designed to implement a progress bar during a long running process on the target application
//	It will flip up a progress window (palette), but it is up to YOUR script that executes on the 
//  target application to send back status messages to make the progress bar do anything.
//  
// 	To send back an status message, embed a function call in your long running target script.
//  the call is: sendBackStatus( increment, status, text );
//	increment is the value you want the progress bar to take, 0-100, 100 being complete.
//  status is the status line text. The progress palette has 2 lines of text, one on top of
// 		the other. This parameter affects the SECOND line. Useful for reporting what file name
//		is being operated on, etc. Consider it a detail information line for the progress palette
//  text is the FIRST line. Normally you wouldn't change this (but might want to in certain processes,
//    	it can be left out if you don't want to change.
//	
//	The funtion sendBackStatus() is generated using a call to the target application PRIOR to executing your
// 	script. The function is generated and then prepended to your script. In your script, DO NOT define your
//  own function named sendBackStatus(), it will render this object inoperable.
//
//	A Detailed example of the useage of this object is in ContactSheet_ID.jsx
//
//  Usage:
//	getScript = function( file ) [
//		var scp = "sendBackStatus( 0, 'Photoshop has accepted the task' ); \n" +
//			scp+= "... code to do something...; \n" +
//			scp+= "sendBackStatus( 10, 'We are 10% done' ); \n" +
//			scp+= "...more code to do something; \n" +
//			scp+= "sendBackStatus( 20, 'We are 20% done', 'Is this cool or what?' ); \n";
//			... more code....
//	}
//	var target = "photoshop";
//	var showProgress = true;
//	var notifyComplete = false;
//	var progressTextLine = "Doing Something Now";
//	var progressWindowTitle = "Doing Something";
//	var bt = new BridgeTalkLongProcess( showProgress, progressTextLine, progressWindowTitle, notifyComplete, target, getScript() );
//	bt.send();
//
BTLPSupport = {};
BTLPSupport.bars = new Hashtable();
BTLPSupport.id = 1;

BTLPSupport.sendBackStatus = function( increment, status, text, truncate, act ) {
	var trunk = truncate == undefined ? false : truncate; 
	trunk = trunk ? 'true' : 'false';
	var action = act == undefined ? '' : act;
	var msg = '<?xml version=\"1.0\" encoding=\"iso-8859-1\" ?>';
	msg += '<progress><increment>' + escape( increment ) + '</increment><status>' + escape( status ) + '</status><text>' + escape( text ) + '</text><truncate>' + escape( trunk ) + '</truncate><action>' + escape( action ) + '</action></progress>';
	var bt = new BridgeTalk();
	bt.target = BTLPtarget;
	bt.type = "BTLP.Progress";
	bt.body = msg;
	bt.headers.progressID = BTLPprogressId;
	bt.send();
}

BTLPSupport.updateProgress = function( id, msg ) {
	var node = CheezyXMLParser.parseText( msg );
	if ( node instanceof XmlNode ) {
		var btlp = BTLPSupport.bars.get( id );
		if ( !isValidReference( btlp ) ) {
			return;
		}
		if ( isValidReference( btlp.progress ) ) {
			var incNode = node.findNode( "increment" );
			var statusNode = node.findNode( "status" );
			var textNode = node.findNode( "text" );
			var trunkNode = node.findNode( "truncate" );
			var actNode = node.findNode( "action" );
			if ( isValidReference( incNode ) ) {
				if ( isValidReference( incNode.value ) ) {
					btlp.progress.setValue( incNode.value );
				}
			}
			if ( isValidReference( statusNode ) ) {
				if ( statusNode.value != "undefined" ) {
					btlp.progress.setStatus( statusNode.value, eval( trunkNode.value ), actNode.value );
				}
			}
			if ( isValidReference( textNode ) ) {
				if ( textNode.value != "undefined" ) {
					btlp.progress.setText( textNode.value );
				}
			}
		}
	}
} 


BridgeTalkLongProcess = function( showProgress, text, title, notifyComplete, target, script ) {
//	var BTLPSupport.originalHandler = BridgeTalk.onReceive;
	BridgeTalk.onReceive = function( msg ) {
		switch( msg.type ) {
			case "BTLP.Progress" :
				BTLPSupport.updateProgress( msg.headers.progressID, msg.body );
				break;
			default : { 
				retval = eval( '$.level = 0;' + msg.body );
				return retval;
			}
		}
	}
	this.text = text;
	this.title = title;
	this.showProgress = showProgress;
	this.notifyComplete = notifyComplete
	this.progress = undefined;
	this.errored = false;
	this.errorArray = new Array();
	this.bt = new BridgeTalk();

	this.bt.target = target;
	this.bt.body = script;
	this.bt.wrapper = this;
	this.id = new String( BTLPSupport.id++ );
	this.bt.headers.progressID = this.id;
	this.bt.headers.sender = "bridge";
	BTLPSupport.bars.put( this.id, this );
}

BridgeTalkLongProcess.prototype.setTarget = function( target ) {
	this.bt.target = target;
}
BridgeTalkLongProcess.prototype.setScript = function( script ) {
	this.bt.body = script;
}
BridgeTalkLongProcess.prototype.prepareScript = function( target ) {
	if ( !startTargetApplication( target ) ) {
		if ( this.showProgress ) {
			this.progress.close();
		}
		return;
	}
	var bt = new BridgeTalk();
	bt.target = target;
	bt.body = "BridgeTalk.onReceive;";
	bt.wrapper = this;
	bt.onError = function( btObj ) {
		alert( AdobeLibraryStrings.btError + "\n" + btObj.body );
	}
	bt.onResult = function( btObj ) {
		var a = getCharsAfter( btObj.body, "(" );
		var b = trim( getCharsBefore( a, ")" ) );
		var scriptHeader = "//$.level = 0; //debugger;\n" + 
				"BTLPtarget = " + b + ".headers.sender; \n" +
				"BTLPprogressId = " + b + ".headers.progressID; \n";
		scriptHeader += "sendBackStatus = " + BTLPSupport.sendBackStatus.toString() + "\n\n";
		this.wrapper.executeScript( scriptHeader );
	}
	BridgeTalk.bringToFront( "bridge" );
	bt.send();	
}
BridgeTalkLongProcess.prototype.send = function() {
	if ( this.showProgress ) { 
		this.progress = progressDialog( this.text, this.title, 100, true, 'OK' );
		this.progress.setStatus( AdobeLibraryStrings.starting );
	}
	this.prepareScript( this.bt.target );
}
BridgeTalkLongProcess.prototype.executeScript = function( header ) {
	this.bt.body = header + this.bt.body;
	this.bt.onResult = function( btObj ) {
		if ( this.wrapper.showProgress ) {
			this.wrapper.progress.close();
		}
		if ( this.wrapper.notifyComplete ) {
			alert ( AdobeLibraryStrings.operationComplete );
		}
	}
	this.bt.onError = function( btObj ) {
		alert( AdobeLibraryStrings.errorLongRunning + ": " + btObj.body );
	}
	if (!BridgeTalk.isRunning( this.bt.target ) ) {
		if ( !startTargetApplication( this.bt.target ) ) {
			if ( isValidReference( this.progress ) ) {
				this.progress.close();
			}
			return;
		}
		BridgeTalk.bringToFront( this.bt.target );
	}
	BridgeTalk.bringToFront( this.bt.target );
	this.bt.send();
}

//---------------------------------------------------------
// 	Class Name - CheezyXMLParser - 
//	Implements a cheexy XML Parser in JavaScript. It does NOT, REPEAT NOT, handle things
//	like CDATA or PCDATA or namespaces. It only handles unary and binary tags containing text data and attributes.
//
//	It's implementation is that of a static object. You do not create an instance of it to use it.
//	The output of the parser is a root, or document node (XmlNode). The node is similar to a DOM node. The class definition
//	is somewhere above here in this file... Once you have your document node, use node.findNode(), as you would in 
//	any DOM implementation to navigate the XML tree.
//
//	Usage:
//		an example of it's usage is in BridgeTalkLongProcess object above.
CheezyXMLParser = {};
	CheezyXMLParser.findNodeCount = 0;
	CheezyXMLParser.parseAttributes = function( str, ht )  {
		var htable = isValidReference( ht ) ? ht : new Hashtable();
		if ( trim( str ).length == 0 ) {
			return htable;
		}
		var aName = trim( getCharsBefore( trim( str ), "=" ) );
		var remainder = trim( getCharsAfter( trim( str ), "=" ) );
		if ( remainder.length == 0 ) return htable;
		var aValue = null;
		if ( remainder.charAt( 0 ) == '"' ) {
			var vString = trim( getCharsAfter( remainder, '"' ) );
			aValue = trim( getCharsBefore( vString, '"' ) );
			remainder = trim( getCharsAfter( vString, '"' ) );
		} else {
			aValue = trim( getCharsBefore( remainder, " " ) );
			remainder = trim( getCharsAfter( remainder, " " ) );
		}
		htable.put( aName, unescape( aValue ) );
		return CheezyXMLParser.parseAttributes( remainder, htable );
	}
	CheezyXMLParser.parseText = function( text ) {
		return CheezyXMLParser.startParser( text );
	}
	CheezyXMLParser.parse = function( f ) {
		f.open( "r" );
		var buffer = f.read();
		f.close();
		return CheezyXMLParser.startParser( buffer );
	}
	CheezyXMLParser.startParser = function( buffer ) {
		buffer = stripCR( buffer );
		var xTag = trim( getCharsBefore( buffer, "?>" ) );
		if ( xTag == buffer ) {
			return buffer;
		}
		var buffer = trim( getCharsAfter( buffer, "?>" ) );
		var xTag = trim( getCharsAfter( xTag, "<?xml" ) );
		var root = new XmlNode( "document" );
		var ht = CheezyXMLParser.parseAttributes( xTag, root.attr );
		root.setAttributes( ht );
		CheezyXMLParser.parsePrimitive( buffer, root );
		return root;
	}
	CheezyXMLParser.parsePrimitive = function( buffer, parentNode ) {
		if ( trim( buffer ).length == 0 ) {
			return;
		}
		var buffer = trim( buffer );
		var text = trim( getCharsBefore( buffer, "<" ) );
		var buffer = trim( getCharsAfter( buffer, "<" ) );
		if ( isValidReference( parentNode ) && text.length > 0 ) {
			parentNode.value = trim( unescape( text ) );
		}
		if ( buffer.length == 0 ) {
			return;
		}
		var tagText = trim( getCharsBefore( buffer, ">" ) );
		buffer = trim( getCharsAfter( buffer, ">" ) );
		var binary = !endsWith( tagText, "/" );
		if ( !binary ) { // it's a <tag attr="val" /> style tag
			tagText = trim( tagText.substr( 0, ( tagText.length - 1 ) ) ); // trim the / and whitespace
			var tag = trim( getCharsBefore( tagText, " " ) );
			tagText = trim( getCharsAfter( tagText, " " ) );
			var node = parentNode.addChildNode( tag, "" );
			node.setAttributes( CheezyXMLParser.parseAttributes( tagText, node.attr ) );
			CheezyXMLParser.parsePrimitive( buffer, parentNode ); // it's not binary, go look for another tag under same parent
		} else { // it's a binary tag, like: <tag attr="val >something</tag>
			tagText = trim( tagText );
			var tag = trim( getCharsBefore( tagText, " " ) ); // peels the tag off the front
			tagText = trim( getCharsAfter( tagText, " " ) );
			var containedStuff = trim( getCharsBefore( buffer, "</" + tag ) );
			var buffer = trim( getCharsAfter( buffer, "</" + tag ) );
			var buffer = trim( getCharsAfter( buffer, ">" ) );
			var node = parentNode.addChildNode( tag, "" );
			node.setAttributes( CheezyXMLParser.parseAttributes( tagText, node.attr ) );
			CheezyXMLParser.parsePrimitive( containedStuff, node );// parse contained nodes
			CheezyXMLParser.parsePrimitive( buffer, parentNode ); // parse sibling nodes
		}
	}

DialogUtilities = {};

DialogUtilities.setupDropdown = function( control, hTable, selectedText, editTextControl ) {
	control.sourceHashtable = hTable;
	selectedText = isValidReference( selectedText ) ? selectedText : "";
	for ( var i = 0; i < hTable.keyList.length; i++ ) {
		var newItem = control.add( "item", hTable.keyList[ i ] );
		newItem.selected = equalsIgnoreCase( selectedText, newItem.text );
		if ( newItem.selected && editTextControl ) {
			var oldDebug = $.level;
			$.level = 0;
			try {
				editTextControl.text = eval( hTable.get( newItem.text ) );
			} catch ( e ) {
				editTextControl.text = hTable.get( newItem.text );
			}
			$.level = oldDebug;
		}
	}
}
DialogUtilities.ExtendedDialog = function( title, okEnabled, omitCancel ) {
	this.control = new Window( "dialog", title );
	this.window = this;
	this.control.wrapper = this;
	this.name = title;
  	this.control.orientation = "row"; 	// at the window level, I want two "groups", one to hold the 
										// all the "value entering" controls, and one to hold OK,CANCEL, etc
										// buttons in a vertical column on the right.
	this.control.alignChildren = "top"; 	// the default is center, you want both the value and button groups
										// at the top of the window
	this.mainRegion = new DialogUtilities.ExtendedControl( this, "group", "mainRegion" );;

	this.mainRegion.setOrientation( "column" );
	this.mainRegion.setAlignChildren( "fill" );

	this.buttonRegion = new DialogUtilities.ExtendedControl( this, "group", "buttonRegion" );
	this.buttonRegion.setOrientation( "column" );
	this.buttonRegion.setSpacing( 30 ); // in the button group, I want to have groups of buttons the first two will
									// always be OK, Cancel. But if you want to add a Page Setup, for example,
									// I want it to be an extra 10 pixels down from the Cancel button to differentiate	

	// this is the OK/Cancel button group
	this.okButtonGroup = this.buttonRegion.add( "group", "okButtonGroup" );
	this.okButtonGroup.setOrientation( "column" );
	this.okButton = this.okButtonGroup.add( "button", localize( "$$$/WAS/DialogUtil/OKButton=OK" ), AdobeLibraryStrings.OK );
	this.okButton.setEnabled( okEnabled );
	var omit = isValidReference( omitCancel ) ? omitCancel : false;
	if ( !omit ) {
		this.cancelButton = this.okButtonGroup.add( "button", localize( "$$$/WAS/DialogUtil/CancelButton=Cancel" ), AdobeLibraryStrings.cancel );
		this.cancelButton.control.onClick = function () { 
			this.wrapper.window.control.close( 2 ); 
		}
	}
	// The Build and Cancel buttons close this dialog
	this.okButton.control.onClick = function () { 
		this.wrapper.window.control.close( 1 ); 
	}
	this.control.center();
}
DialogUtilities.ExtendedDialog.prototype.show = function() {
	var result = this.control.show();
	switch ( result ) {
		case 1 : return this;
		case 2 : return undefined;
	}
}
DialogUtilities.ExtendedDialog.prototype.addButtonGroup = function( name, array ) {
	var group = this.buttonRegion.add( "group", name );
	group.setOrientation( "column" );
	for ( var i = 0; i < array.length; i++ ) {
		var btn = group.add( "button", array[ i ], array[ i ] );
	}
	return group;
}
DialogUtilities.ExtendedDialog.prototype.add = function( type, name, text, preferredSize, creationProps ) {
	return this.mainRegion.add( type, name, text, preferredSize, creationProps );
}
DialogUtilities.ExtendedDialog.prototype.findControl = function( name ) {
	return this.find( name );
}
DialogUtilities.ExtendedDialog.prototype.find = function( name ) {
//	debugger;
	return DialogUtilities.findControl( this, name );
}
DialogUtilities.ExtendedControl = function( parent, type, name, text, preferredSize, creationProps ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	if ( type == "group" ) {
		if ( $.debugDialog ) {
			this.control = parent.control.add( "panel", undefined, undefined, creationProps );
			this.control.orientation = "row";		
			this.control.margins = [0,0,0,0];
		} else {
			this.control = parent.control.add( type, undefined, creationProps )
		}
	} else {
		this.control = parent.control.add( type, undefined, text, creationProps )
	}
	this.window = parent.window;
	this.control.wrapper = this;
	if ( !isValidReference( parent.childReferences ) ) {
		parent.childReferences = new Hashtable( true );
	}
	parent.childReferences.put( name, this );
	this.name = name;
	this.parent = parent;
	if ( isValidReference( preferredSize ) ) {
		this.control.preferredSize = preferredSize;
	}
}
DialogUtilities.ExtendedControl.prototype.setOrientation = function( o ) {
	this.control.orientation = o;
}
DialogUtilities.ExtendedControl.prototype.getOrientation = function() {
	return this.control.orientation;
}
DialogUtilities.ExtendedControl.prototype.setAlignment = function( o ) {
	this.control.alignment = o;
}
DialogUtilities.ExtendedControl.prototype.getAlignment = function() {
	return this.control.alignment;
}
DialogUtilities.ExtendedControl.prototype.setAlignChildren = function( o ) {
	this.control.alignChildren = o;
}
DialogUtilities.ExtendedControl.prototype.getAlignChildren = function() {
	return this.control.alignChildren;
}
DialogUtilities.ExtendedControl.prototype.setSpacing = function( o ) {
	this.control.spacing = o;
}
DialogUtilities.ExtendedControl.prototype.getSpacing = function() {
	return this.control.spacing;
}
DialogUtilities.ExtendedControl.prototype.setEnabled = function( o ) {
	this.control.enabled = o;
}
DialogUtilities.ExtendedControl.prototype.getEnabled = function() {
	return this.control.enabled;
}
DialogUtilities.ExtendedControl.prototype.setJustify = function( o ) {
	this.control.justify = o;
}
DialogUtilities.ExtendedControl.prototype.getJustify = function() {
	return this.control.justify;
}
DialogUtilities.ExtendedControl.prototype.setVisible = function( o ) {
	this.control.visible = o;
}
DialogUtilities.ExtendedControl.prototype.getVisible = function() {
	return this.control.visible;
}
DialogUtilities.ExtendedControl.prototype.setText = function( o ) {
	this.control.text = o;
}
DialogUtilities.ExtendedControl.prototype.getText = function() {
	return this.control.text;
}
DialogUtilities.ExtendedControl.prototype.setValue = function( o ) {
	switch ( this.control.type ) {
		case "checkbox" :
		case "radiobutton" :
		case "slider" :
		case "scrollbar" : {
			this.control.value = o;
			break;
		}
		case "edittext" :
		case "statictext" :
		case "listitem" : {
			this.control.text = o;
			break;
		}
		case "dropdownlist" :
		case "listbox" :
			this.control.selection = o;
	}
}
DialogUtilities.ExtendedControl.prototype.getValue = function() {
	switch ( this.control.type ) {
		case "checkbox" :
		case "radiobutton" :
		case "slider" :
		case "scrollbar" :
			return this.control.value;
		case "edittext" :
		case "statictext" :
		case "listitem" :
			return this.control.text;
		case "dropdownlist" :
		case "listbox" :
			return this.control.selection;
	}
}
DialogUtilities.ExtendedControl.prototype.addIndentedDrop = function( name, text, preferredSize, creationProps, caption, valueTable ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var group = this.add( "group", ( name + "Group" ) );
//	group.setAlignment( "fill" );
	group.setAlignChildren( "center" );
	if ( this.getAlignChildren() == "left" ) {
		var statIndent = group.add( "statictext", ( name + "StaticIndent" ), "a" );
		statIndent.setVisible( false );
	}
	var stat = group.add( "statictext", ( name + "Static" ), caption );
//	stat.setAlignment( "right" );
	var drop = group.add( "dropdownlist", name, undefined, preferredSize, creationProps );
	this.drop = drop;
	if ( this.getAlignChildren() == "right" ) {
		var statIndent = group.add( "statictext", ( name + "StaticIndent" ), "a" );
		statIndent.setVisible( false );
	}
	drop.setAlignment( "right" );
	DialogUtilities.setupDropdown( drop.control, valueTable, text );
	return drop;
}

DialogUtilities.ExtendedControl.prototype.addComplexDrop = function( name, text, preferredSize, creationProps, caption, valueTable ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var group = this.add( "group", ( name + "Group" ) );
//	group.setAlignment( "fill" );
	group.setAlignChildren( "center" );
	var stat = group.add( "statictext", ( name + "Static" ), caption );
//	stat.setAlignment( "right" );
	var drop = group.add( "dropdownlist", name, undefined, preferredSize, creationProps );
	this.drop = drop;
	drop.setAlignment( "right" );
	DialogUtilities.setupDropdown( drop.control, valueTable, text );
	return drop;
}
DialogUtilities.ExtendedControl.prototype.addComplexEdit = function( name, text, preferredSize, creationProps, caption, min, max, capLoc ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var uberGruppe = this;
	if ( isValidReference( min ) ) {
		uberGruppe = this.add( "group", ( name + "GroupCol" ) );
		uberGruppe.setOrientation( "column" );
		uberGruppe.setSpacing( 0 );
	}
	var group = uberGruppe.add( "group", ( name + "Group" ) );
//	group.setAlignment( "fill" );
	if ( capLoc == "top" ) {
		group.setOrientation( "column" );
		group.setAlignChildren( "left" );
	}
	group.setAlignChildren( "fill" );
	var stat = group.add( "statictext", ( name + "Static" ), caption );
	stat.setAlignment( "top" );
	var edit = group.add( "edittext", name, text, preferredSize, creationProps );
	this.captionField = stat;
//	edit.setAlignment( "fill" );
	this.edit = edit;
	edit.setAlignment( "right" );
	if ( isValidReference( min ) ) {
		var slider = uberGruppe.add( "slider", ( name + "slider" ) );
		this.slider = slider;
		slider.setAlignment( "right" );
		slider.control.minvalue = min;
		slider.control.maxvalue = max;
		slider.setValue( parseInt( text ) );
		edit.setValue( text );
		edit.savedValue = text;
		edit.slider = slider;
		slider.edit = edit;
		slider.control.onChanging = function() {
			this.wrapper.edit.setValue( this.value );
			this.wrapper.savedValue = this.value;
		}
		slider.control.onChange = function() {
			this.wrapper.edit.setValue( this.value );
			this.wrapper.savedValue = this.value;
		}
		edit.control.onChange = function() {
			if ( isNaN( parseInt( this.text ) ) ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
//			debugger;
			if ( parseInt( this.text ) > this.wrapper.slider.control.maxvalue ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
			if ( parseInt(this.text) < this.wrapper.slider.control.minvalue ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
			this.wrapper.slider.setValue( parseInt( this.text ) );
			this.wrapper.savedValue = parseInt( this.text );
		}
		
	}
	return edit;
}
DialogUtilities.ExtendedControl.prototype.addIndentedEdit = function( name, text, preferredSize, creationProps, caption, min, max ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var uberGruppe = this;
	if ( isValidReference( min ) ) {
		uberGruppe = this.add( "group", ( name + "GroupCol" ) );
		uberGruppe.setOrientation( "column" );
		uberGruppe.setSpacing( 0 );
	}
	var group = uberGruppe.add( "group", ( name + "Group" ) );
//	group.setAlignment( "fill" );
	group.setAlignChildren( "center" );
	if ( this.getAlignChildren() == "left" ) {
		var statIndent = group.add( "statictext", ( name + "StaticIndent" ), "a" );
		statIndent.setVisible( false );
	}
	var stat = group.add( "statictext", ( name + "Static" ), caption );
	stat.setAlignment( "top" );
//	stat.setAlignment( "right" );
	var edit = group.add( "edittext", name, text, preferredSize, creationProps );
	this.edit = edit;
	if ( this.getAlignChildren() == "right" ) {
		var statIndent = group.add( "statictext", ( name + "StaticIndent" ), "a" );
		statIndent.setVisible( false );
	}
	
//	edit.setAlignment( "right" );
	if ( isValidReference( min ) ) {
		var uberGruppe2 = uberGruppe.add( "group", ( name + "uberGruppe2" ) );
		uberGruppe2.setAlignment( "right" );
		if ( this.getAlignChildren() == "left" ) {
			var statIndent = uberGruppe2.add( "statictext", ( name + "StaticIndent" ), caption + "a" );
			statIndent.setVisible( false );
		}
		var slider = uberGruppe2.add( "slider", ( name + "slider" ) );
		this.slider = slider;
		if ( this.getAlignChildren() == "right" ) {
			var statIndent = uberGruppe2.add( "statictext", ( name + "StaticIndent" ), "a" );
			statIndent.setVisible( false );
		}
		slider.setAlignment( "right" );
		slider.control.minvalue = min;
		slider.control.maxvalue = max;
		slider.setValue( parseInt( text ) );
		edit.setValue( text );
		edit.savedValue = text;
		edit.slider = slider;
		slider.edit = edit;
		slider.control.onChanging = function() {
			this.wrapper.edit.setValue( this.value );
			this.wrapper.savedValue = this.value;
		}
		slider.control.onChange = function() {
			this.wrapper.edit.setValue( this.value );
			this.wrapper.savedValue = this.value;
		}
		edit.control.onChange = function() {
			if ( isNaN( parseInt( this.text ) ) ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
			if ( parseInt( this.text ) > this.wrapper.slider.control.maxvalue ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
			if ( parseInt(this.text) < this.wrapper.slider.control.minvalue ) {
				this.text = this.wrapper.savedValue;
				this.wrapper.slider.setValue( this.wrapper.savedValue );
			}
			this.wrapper.slider.setValue( parseInt( this.text ) );
			this.wrapper.savedValue = parseInt( this.text );
		}
		
	}
	return edit;
}
DialogUtilities.ExtendedControl.prototype.addPickFolder = function( name, btnText, preferredSize, creationProps, enableOkButton, folder ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var outGroup = this.add( "group", name + "OutputGroup" );
	outGroup.setAlignChildren( "right" );
	outGroup.setAlignment( "fill" );
	outGroup.setOrientation( "row" );
	var folderName = outGroup.add( "edittext", "outputFile", undefined, preferredSize, creationProps);
	folderName.setAlignment( "fill" );
	if ( isValidReference( folder ) ) {
		folderName.setValue( folder.fsName );
	}
	var button = undefined;
	button = outGroup.add( "button", "getFileButton", btnText );
	if ( enableOkButton ) {
		var msg = btnGroup.add( "statictext", "outputEnableMessage", AdobeLibraryStrings.folderEnablesOK );
	}
	this.control = folderName;
	this.button = button;
	button.editControl = folderName;
	button.control.onClick = function( ) {
		try {
			var currentFolder = this.wrapper.editControl.getValue();
			var theFolder = new Folder( app.document.thumbnail.path );
			if ( isValidReference( currentFolder ) ) {
				var theFolder = new Folder( currentFolder );
			}
			if ( theFolder.alias )  {
				theFolder = theFolder.resolve();
			}
			var theFolder = theFolder.selectDlg( AdobeLibraryStrings.selectDestFolder );
			var okBtn = this.wrapper.findControl( "OK" );
			if ( theFolder != null )  {
				this.wrapper.editControl.setValue( theFolder.fsName );
				if ( enableOkButton ) {
					okBtn.setEnabled( true );
					var msg = this.wrapper.findControl( "outputEnableMessage" );
					msg.setValue( "" );
				}
				this.wrapper.editControl.control.notify();
			} else {
				if ( enableOkButton ) {
					okBtn.setEnabled( false );
					var msg = this.wrapper.findControl( "outputEnableMessage" );
					msg.setValue( AdobeLibraryStrings.folderEnablesOK );
				}
				
			}
		} catch ( e ) {
			alert( e );
		}
	}
	return folderName;
}
DialogUtilities.ExtendedControl.prototype.addPickFile = function( name, btnText, preferredSize, creationProps, enableOkButton ) {
	if ( !isValidReference( creationProps ) ) {
		creationProps = {};
	}
	creationProps.name = name;
	var outGroup = this.add( "group", name + "OutputGroup" );
	outGroup.setOrientation( "column" );
	outGroup.setAlignChildren( "right" );
	var fileName = outGroup.add( "edittext", "outputFile", undefined, preferredSize, creationProps );
	var btnGroup = outGroup.add( "group", name + "buttonGroup" );
	btnGroup.setAlignment( "fill" );
	btnGroup.setAlignChildren( "right" );
	var button = btnGroup.add( "button", "getFileButton", AdobeLibraryStrings.selectOutputFile );
	if ( enableOkButton ) {
		var msg = btnGroup.add( "statictext", "outputEnableMessage", AdobeLibraryStrings.fileEnablesOK );
	}
	button.editControl = fileName;
	button.control.onClick = function( ) {
		try {
			var theFile = File.saveDialog( AdobeLibraryStrings.selectOutputFile );
			var okBtn = this.wrapper.findControl( "OK" );
			if ( theFile != null )  {
				this.wrapper.editControl.setValue( theFile.fsName );
				if ( enableOkButton ) {
					okBtn.setEnabled( true );
					var msg = this.wrapper.findControl( "outputEnableMessage" );
					msg.setValue( "" );
				}
			} else {
				if ( enableOkButton ) {
					okBtn.setEnabled( false );
					var msg = this.wrapper.findControl( "outputEnableMessage" );
					msg.setValue( AdobeLibraryStrings.fileEnablesOK );
				}
			}
		} catch ( e ) {
			alert( e );
		}
	}
	return fileName;
}

DialogUtilities.ExtendedControl.prototype.add = function( type, name, text, preferredSize, creationProps ) {
	return new DialogUtilities.ExtendedControl( this, type, name, text, preferredSize, creationProps );
}
DialogUtilities.ExtendedControl.prototype.findControl = function( name ) {
	return DialogUtilities.findControl( this.window, name );
}
DialogUtilities.ExtendedControl.prototype.find = function( name ) {
	return DialogUtilities.findControl( this, name );
}
DialogUtilities.findControl = function( c, name ) {
	if ( isValidReference( c.childReferences ) ) {
		if ( isValidReference( c.childReferences.get( name ) ) ) {
			return c.childReferences.get( name );
		}
		for ( var i = 0; i < c.childReferences.keyList.length; i++ ) {
			var nextControl = c.childReferences.get( c.childReferences.keyList[ i ] );
			var control = nextControl.find( name );
			if ( isValidReference( control ) ) {
				return control;
			}
		}
	}
	return undefined;
}
DoNoShowAgainWarningAlert = function( msg, cancel, msg2 ) {
	this.dialog = new Window( "dialog", localize( "$$$/WAS/Library/LibhelpNoteTitle=Help Note" ) );
	this.dialog.orientation = "column";
// ITALIAN CHANGE
	if ( isValidReference( msg2 ) ) {
		msg = msg + " " + msg2;
	}
	var txt = this.dialog.add( "statictext", undefined, msg, { multiline: true } );
//	if ( isValidReference( msg2 ) ) {
//		var txt2 = this.dialog.add( "statictext", undefined, msg2, { multiline: true } );
//	}

	this.notice = this.dialog.add( "checkbox", undefined, localize( "$$$/WAS/SM/noShow=Do not show this message again" ) );
	var group = this.dialog.add( "group" );
	this.actionCancelled = false;
	if ( cancel ) {
		this.cancel = group.add( "button", undefined, localize( "$$$/WAS/SM/canx=Cancel" ) );
		this.cancel.dlg = this.dialog;
		this.cancel.wrapper = this;
		this.cancel.alignment = "right";
		this.cancel.onClick = function() {
			this.dlg.close( 2 );
			this.wrapper.actionCancelled = true;
		}
	}
	this.ok = group.add( "button", undefined, localize( "$$$/WAS/SM/okBtn=OK" ) );
	this.ok.alignment = "right";
	this.ok.dlg = this.dialog;
	this.ok.onClick = function() {
		this.dlg.close( 1 );
	}
	this.dialog.center();
}

DoNoShowAgainWarningAlert.prototype.show = function() {
	this.dialog.show();
	return ( !this.notice.value );
}



FileSetDialog = {};
// localization strings
FileSetDialog.strings = {};
FileSetDialog.strings.title = localize( "$$$/WAS/FileSetDialog/selfile=Select Files" );
FileSetDialog.strings.title2 = localize( "$$$/WAS/FileSetDialog/seldfiles=Selected Files" );
FileSetDialog.strings.sourceFiles = localize( "$$$/WAS/FileSetDialog/srcfiles=Source Files" );
FileSetDialog.strings.includeSubfolders = localize( "$$$/WAS/FileSetDialog/incsub=Include Subfolders" );
FileSetDialog.strings.pruneEmptyFolders = localize( "$$$/WAS/FileSetDialog/hidempty=Hide Empty Folders" );
FileSetDialog.strings.moveUp = localize( "$$$/WAS/FileSetDialog/moveup=Move Up" );
FileSetDialog.strings.moveDown = localize( "$$$/WAS/FileSetDialog/movedn=Move Down" );
FileSetDialog.strings.removeFiles = localize( "$$$/WAS/FileSetDialog/remove=Remove" );
FileSetDialog.strings.OK = localize( "$$$/WAS/FileSetDialog/ok=OK" );
FileSetDialog.strings.Cancel = localize( "$$$/WAS/FileSetDialog/can=Cancel" );
FileSetDialog.strings.fileNameFilter = localize( "$$$/WAS/FileSetDialog/fnf=File Name Filter" );
FileSetDialog.strings.fileTypeFilter = localize( "$$$/WAS/FileSetDialog/ftf=File Type Filter" );
FileSetDialog.strings.refresh = localize( "$$$/WAS/FileSetDialog/ref=Refresh" );

FileSetDialog.Settings = function( moveOption, filterDefault, fileNameMask ) {
	this.fileNameMask = fileNameMask;
	this.filters = new Hashtable( true );
	this.filterDefault = filterDefault;
	this.moveOption = moveOption;
	this.onChange = undefined;
}
FileSetDialog.Settings.prototype.addFilter = function( displayName, typeList ) {
	this.filters.put( displayName, typeList );
}
FileSetDialog.Settings.prototype.getFilter = function( displayName ) {
	return this.filters.get( displayName );
}
FileSetDialog.create = function( settings )  {
    var dlg = new Window( "dialog", FileSetDialog.strings.title2 );
	dlg.settings = settings;
	if ( !isValidReference( settings ) ) {
		var defaultSettings = new FileSetDialog.Settings( false, "Photoshop", "*" );
		defaultSettings.addFilter( "Photoshop", "TYPES.PHOTOSHOP" );
		defaultSettings.addFilter( "InDesign", "TYPES.INDESIGN" );
		defaultSettings.addFilter( "Illustrator", "TYPES.ILLUSTRATOR" );
		defaultSettings.addFilter( "GoLive", "TYPES.GOLIVE" );
		defaultSettings.addFilter( "PDF", "TYPES.PDF" );
		defaultSettings.addFilter( "Photoshop - All", "TYPES.PHOTOSHOP_OPENABLE" );
		defaultSettings.addFilter( "Illustrator - All", "TYPES.ILLUSTRATOR_OPENABLE" );
		defaultSettings.addFilter( "All", "TYPES.ALL" );
		defaultSettings.moveOption = false;	
		defaultSettings.onChange = undefined;
		dlg.settings = defaultSettings;
	}

  	dlg.orientation = "row"; 	// at the window level, I want two "groups", one to hold the 
						// all the "value entering" controls, and one to hold OK,CANCEL, etc
						// buttons in a vertical column on the right.
	dlg.alignChildren = "top"; 	// the default is center, you want both the value and button groups
							// at the top of the window

	dlg.vGroup = dlg.add( "group" );	// this is the group that will hold all of the value stuff
	dlg.vGroup.orientation = "row";
	dlg.vGroup.alignChildren = "top";

	dlg.bGroup = dlg.add( "group" );
	dlg.bGroup.orientation = "column";
	dlg.bGroup.spacing = 30; // in the button group, I want to have groups of buttons the first two will
					// always be OK, Cancel. But if you want to add a Page Setup, for example,
					// I want it to be an extra 10 pixels down from the Cancel button to differentiate	

	dlg.vGroup.fileGroup = dlg.vGroup.add( "panel", undefined, FileSetDialog.strings.sourceFiles );
	dlg.vGroup.fileGroup.orientation = "column";
	dlg.vGroup.fileGroup.alignChildren = "left";
	// dlg.vGroup.fileGroup is the first visible element, a panel to hold the items common to layout
	dlg.vGroup.fileGroup.baseField = dlg.vGroup.fileGroup.add( "edittext", undefined, undefined,  {readonly: true} );
	dlg.vGroup.fileGroup.baseField.preferredSize = [450, 20 ];
	// add a group to put the check boxes on a single line
	dlg.vGroup.fileGroup.checkGroup = dlg.vGroup.fileGroup.add( "group" );
	dlg.vGroup.fileGroup.checkGroup.recurse = dlg.vGroup.fileGroup.checkGroup.add( "checkbox", undefined, FileSetDialog.strings.includeSubfolders );
	dlg.vGroup.fileGroup.checkGroup.prune = dlg.vGroup.fileGroup.checkGroup.add( "checkbox",undefined, FileSetDialog.strings.pruneEmptyFolders );

	//add a group to hold the list, another group to hold the buttons...
	dlg.vGroup.fileGroup.dummy = dlg.vGroup.fileGroup.add( "group" );
	dlg.vGroup.fileGroup.dummy.orientation = "row";
	
	dlg.vGroup.fileGroup.listGroup = dlg.vGroup.fileGroup.dummy.add( "group" );
	dlg.vGroup.fileGroup.listGroup.parentWindow = dlg;
	dlg.vGroup.fileGroup.btnGroup = dlg.vGroup.fileGroup.dummy.add( "group" );
	dlg.vGroup.fileGroup.btnGroup.alignment = "fill";
	dlg.vGroup.fileGroup.btnGroup.orientation = "column";
	dlg.vGroup.fileGroup.btnGroup.parentWindow = dlg;
	
	dlg.vGroup.fileGroup.listGroup.fileList = dlg.vGroup.fileGroup.listGroup.add( "listbox", undefined, undefined, { multiselect: true } );
	dlg.vGroup.fileGroup.listGroup.fileList.preferredSize = [450,300];

	dlg.vGroup.fileGroup.btnGroup.spacing = 30;
	dlg.vGroup.fileGroup.btnGroup.ref = dlg.vGroup.fileGroup.btnGroup.add( "group" );
	dlg.vGroup.fileGroup.btnGroup.ref.orientation = "column";
	dlg.vGroup.fileGroup.btnGroup.refresh = dlg.vGroup.fileGroup.btnGroup.ref.add( "button", undefined, FileSetDialog.strings.refresh );
	dlg.vGroup.fileGroup.btnGroup.removeFile = dlg.vGroup.fileGroup.btnGroup.ref.add( "button", undefined, FileSetDialog.strings.removeFiles );

	dlg.vGroup.fileGroup.btnGroup.move = dlg.vGroup.fileGroup.btnGroup.add( "group" );
	dlg.vGroup.fileGroup.btnGroup.move.orientation = "column";
	dlg.vGroup.fileGroup.btnGroup.moveUp = dlg.vGroup.fileGroup.btnGroup.move.add( "button", undefined, FileSetDialog.strings.moveUp );
	dlg.vGroup.fileGroup.btnGroup.moveDown = dlg.vGroup.fileGroup.btnGroup.move.add( "button", undefined, FileSetDialog.strings.moveDown );

	dlg.vGroup.fileGroup.btnGroup.moveUp.enabled = false;
	dlg.vGroup.fileGroup.btnGroup.moveDown.enabled = false;
	dlg.vGroup.fileGroup.btnGroup.removeFile.enabled = false;
	
	if ( !dlg.settings.moveOption ) {
		dlg.vGroup.fileGroup.btnGroup.moveUp.visible = false;
		dlg.vGroup.fileGroup.btnGroup.moveDown.visible = false;
	} else {
		dlg.vGroup.fileGroup.btnGroup.moveUp.visible = true;
		dlg.vGroup.fileGroup.btnGroup.moveDown.visible = true;
	}
	dlg.vGroup.fileGroup.fGroup = dlg.vGroup.fileGroup.add( "group" );
	dlg.vGroup.fileGroup.fGroup.parentWindow = dlg;
	dlg.vGroup.fileGroup.fGroup.alignChildren = "right";
	dlg.vGroup.fileGroup.fGroup.alignment = "fill";
//	dlg.vGroup.fileGroup.fGroup.stat = dlg.vGroup.fileGroup.fGroup.add( "statictext", undefined, FileSetDialog.strings.fileNameFilter );
//	dlg.vGroup.fileGroup.fGroup.mask = dlg.vGroup.fileGroup.fGroup.add( "edittext", undefined, undefined, {readonly: false} );
//	dlg.vGroup.fileGroup.fGroup.mask.preferredSize = [120,20];
//	dlg.vGroup.fileGroup.fGroup.mask.alignment = "fill";
//	dlg.vGroup.fileGroup.fGroup.mask.text = dlg.settings.fileNameMask;

	dlg.vGroup.fileGroup.tGroup = dlg.vGroup.fileGroup.add( "group" );
	dlg.vGroup.fileGroup.tGroup.parentWindow = dlg;
	dlg.vGroup.fileGroup.tGroup.alignChildren = "top";
	
	dlg.vGroup.fileGroup.tGroup.typeMaskStat = dlg.vGroup.fileGroup.tGroup.add( "statictext", undefined, FileSetDialog.strings.fileTypeFilter );
	dlg.vGroup.fileGroup.tGroup.typeMask = dlg.vGroup.fileGroup.tGroup.add( "edittext", undefined, undefined, {multiline:true,readonly: false} );
	dlg.vGroup.fileGroup.tGroup.typeMask.preferredSize = [350,60];
	dlg.vGroup.fileGroup.tGroup.typePreset = dlg.vGroup.fileGroup.tGroup.add( "dropdownlist",undefined );
	DialogUtilities.setupDropdown( dlg.vGroup.fileGroup.tGroup.typePreset, dlg.settings.filters, dlg.settings.filterDefault, dlg.vGroup.fileGroup.tGroup.typeMask );
	
	dlg.vGroup.fileGroup.tGroup.typePreset.refresh = dlg.vGroup.fileGroup.btnGroup.refresh; 
	dlg.vGroup.fileGroup.tGroup.typeMask.refresh = dlg.vGroup.fileGroup.btnGroup.refresh;
//	dlg.vGroup.fileGroup.fGroup.mask.refresh = dlg.vGroup.fileGroup.btnGroup.refresh;
	dlg.vGroup.fileGroup.listGroup.fileList.moveUp = dlg.vGroup.fileGroup.btnGroup.moveUp;
	dlg.vGroup.fileGroup.listGroup.fileList.moveDown = dlg.vGroup.fileGroup.btnGroup.moveDown;
	dlg.vGroup.fileGroup.listGroup.fileList.refresh = dlg.vGroup.fileGroup.btnGroup.refresh;
	dlg.vGroup.fileGroup.listGroup.fileList.removeFile = dlg.vGroup.fileGroup.btnGroup.removeFile;
	dlg.vGroup.fileGroup.listGroup.fileList.parentWindow = dlg;
	dlg.vGroup.fileGroup.checkGroup.recurse.refresh = dlg.vGroup.fileGroup.btnGroup.refresh;
	dlg.vGroup.fileGroup.checkGroup.prune.refresh = dlg.vGroup.fileGroup.btnGroup.refresh;
	dlg.vGroup.fileGroup.btnGroup.refresh.parentWindow = dlg;
	dlg.vGroup.fileGroup.btnGroup.refresh.fileList = dlg.vGroup.fileGroup.listGroup.fileList;
	dlg.vGroup.fileGroup.btnGroup.refresh.baseField = dlg.vGroup.fileGroup.baseField;
	dlg.vGroup.fileGroup.btnGroup.refresh.moveDown = dlg.vGroup.fileGroup.btnGroup.moveUp;
	dlg.vGroup.fileGroup.btnGroup.refresh.moveUp = dlg.vGroup.fileGroup.btnGroup.moveDown;
	dlg.vGroup.fileGroup.btnGroup.refresh.prune = dlg.vGroup.fileGroup.checkGroup.prune;
	dlg.vGroup.fileGroup.btnGroup.refresh.recurse = dlg.vGroup.fileGroup.checkGroup.recurse;
//	dlg.vGroup.fileGroup.btnGroup.refresh.mask = dlg.vGroup.fileGroup.fGroup.mask
	dlg.vGroup.fileGroup.btnGroup.refresh.typeMask = dlg.vGroup.fileGroup.tGroup.typeMask;
	dlg.vGroup.fileGroup.btnGroup.removeFile.parentWindow = dlg;
	dlg.vGroup.fileGroup.btnGroup.removeFile.fileList = dlg.vGroup.fileGroup.listGroup.fileList;
	dlg.vGroup.fileGroup.btnGroup.moveUp.fileList = dlg.vGroup.fileGroup.listGroup.fileList;
	dlg.vGroup.fileGroup.btnGroup.moveDown.fileList = dlg.vGroup.fileGroup.listGroup.fileList;
	dlg.vGroup.fileGroup.btnGroup.moveUp.parentWindow = dlg;
	dlg.vGroup.fileGroup.btnGroup.moveDown.parentWindow = dlg;

	dlg.vGroup.fileGroup.tGroup.typePreset.onChange = function() {
		var oldDebug = $.level;
		$.level = 0;
		try {
			this.parent.typeMask.text = eval( this.parent.parentWindow.settings.getFilter( this.selection.text ) );
		}
		catch( e ) {
			this.parent.typeMask.text = this.parent.parent.settings.getFilter( this.selection.text );
		}
		$.level = oldDebug;
		this.refresh.notify();
	}
	dlg.vGroup.fileGroup.tGroup.typeMask.onChange = function() {
		this.refresh.notify();
	}
//	dlg.vGroup.fileGroup.fGroup.mask.onChange = function() {
//		this.refresh.notify();
//	}
		
	dlg.vGroup.fileGroup.btnGroup.moveUp.onClick = function() {
//		debugger;
		var sel = this.fileList.selection;
		var multi = sel instanceof Array ? true : false;
		var selItem = null;
		var txt = "";
		if ( multi ) {
			txt = sel[ 0 ].text;
			selItem = sel[ 0 ];
		} else {
			txt = sel.text;
			selItem = sel;
		}		
		this.parentWindow.fileTree.move( selItem, true );
		for (var i = 0; i < this.fileList.items.length; i++ ) {
			if ( txt == this.fileList.items[ i ].text ) {
				this.fileList.selection = i;
				break;
			}
		}
	}
	dlg.vGroup.fileGroup.btnGroup.moveDown.onClick = function() {
		var sel = this.fileList.selection;
		var multi = sel instanceof Array ? true : false;
		var selItem = null;
		var txt = "";
		if ( multi ) {
			txt = sel[ 0 ].text;
			selItem = sel[ 0 ];
		} else {
			txt = sel.text;
			selItem = sel;
		}
		this.parentWindow.fileTree.move( selItem, false );
		for (var i = 0; i < this.fileList.items.length; i++ ) {
			if ( txt == this.fileList.items[ i ].text ) {
				this.fileList.selection = i;
				break;
			}
		}
	}
	dlg.vGroup.fileGroup.listGroup.fileList.onChange = function() {
//debugger;
		var sel = this.selection;
		if ( !isValidReference( sel ) ) {
			this.moveUp.enabled = false;
			this.moveDown.enabled = false;
			return;		
		}
		this.removeFile.enabled = true;
		var multi = sel instanceof Array ? true : false;
		if ( !multi ) {
			var ar = new Array( );
			ar.push( sel );
			sel = ar;
		}
		if ( sel.length == 0 ) {
			this.moveUp.enabled = false;
			this.moveDown.enabled = false;
			return;	
		
		}
		if ( sel.length > 1 ) { // more than 1 item selected
			this.moveUp.enabled = false;
			this.moveDown.enabled = false;
			return;	
		}
		if ( this.items.length == 1 ) { // only 1 item in the list
			this.moveUp.enabled = false;
			this.moveDown.enabled = false;
			return;
		} 
		// for nested items
		var selNode = this.parentWindow.fileTree.findNode( sel[ 0 ] );
		if ( isValidReference( selNode ) ) {
			var parent = selNode.parentNode;
			if ( isValidReference( parent ) ) {
				if ( parent.children.length == 1 ) { // only 1 child of parent, turn off
					this.moveUp.enabled = false;
					this.moveDown.enabled = false;
					return;
				}
				if ( trim( parent.children[ 0 ].text ) == trim( sel[ 0 ].text ) ) { // at top of parent, turn off move up
					this.moveUp.enabled = false;
					this.moveDown.enabled = true;
					return;
				}
				var lastChild = parent.children[ ( parent.children.length - 1 ) ];
				if ( trim( lastChild.text ) == trim( sel[ 0 ].text ) ) {// at bottom of parent, turn off move down
					this.moveUp.enabled = true;
					this.moveDown.enabled = false;
					return;
				}
			}
		// if selected item is bottom most child of parent
		
		// if selected item's bottom-most child is the bottom most turn off move down
			if ( selNode.children.length > 0 ) {
				var bottomItem = this.items[ ( this.items.length - 1 ) ];
				var lastChild = selNode.children[ ( selNode.children.length - 1 ) ];
				if ( trim( bottomItem.text ) == trim( lastChild.text ) ) {
					this.moveUp.enabled = true;
					this.moveDown.enabled = false;
					return;
				}
			}
		}
		
		if ( sel[ 0 ].index > 0 ) {
			this.moveUp.enabled = true;
		} else {
			this.moveUp.enabled = false;
		}
		if ( sel[ 0 ].index < ( this.parent.fileList.items.length - 1 ) ) {
			this.moveDown.enabled = true;
		} else {
			this.moveDown.enabled = false;
		}
	}
	
	
	dlg.vGroup.fileGroup.checkGroup.recurse.onClick = function()  {
		this.refresh.notify();
	}
	dlg.vGroup.fileGroup.checkGroup.prune.onClick = function() {
		this.refresh.notify();
	}
	
	dlg.vGroup.fileGroup.btnGroup.refresh.onClick = function()  {
		this.parentWindow.fileTree = new FileTree( this.fileList, app.document, this.recurse.value, this.prune.value, this.typeMask.text );
		this.parentWindow.fileTree.refresh();
		this.baseField.text = this.parentWindow.fileTree.base;
		this.moveUp.enabled = false;
		this.moveDown.enabled = false;
//		dlg.fileGroup.updateReport();
	}
	dlg.vGroup.fileGroup.btnGroup.removeFile.onClick = function()  {
		try {
//		debugger;
			var sel = this.fileList.selection;
			var ar = new Array();
			if ( sel instanceof Array ) {
				for ( var i = 0; i < sel.length; i++ ) {
					ar.push( sel[i].text );
				}
			} else {
				ar.push( sel.text );
			}
			this.parentWindow.fileTree.removeSelection( ar );
			this.enabled = false;
//			dlg.fileGroup.updateReport();
		} catch ( e ) {
			alert( e );
		}
	}
// this is the OK/Cancel button group
	dlg.bGroup.okGroup = dlg.bGroup.add( "group", undefined );
	dlg.bGroup.okGroup.preferredSize.width = 100;
	dlg.bGroup.okGroup.orientation = "column";
	dlg.bGroup.okGroup.okButton = dlg.bGroup.okGroup.add( "button", undefined, AdobeLibraryStrings.OK );
	dlg.bGroup.okGroup.cancelButton = dlg.bGroup.okGroup.add( "button", undefined, AdobeLibraryStrings.cancel );
	
	dlg.bGroup.okGroup.cancelButton.onClick = function() {
		dlg.close( 2 ); 
	}
	dlg.bGroup.okGroup.okButton.onClick = function() {
		dlg.close( 1 );
	}

	dlg.center();
//	dlg.vGroup.fileGroup.btnGroup.refresh.notify();
	return dlg;

	return dlg;
}
FileSetDialog.show = function( settings ) {
//debugger;
	var d = FileSetDialog.create( settings );
	var okClicked = d.show() == 1 ? true : false;
	if ( okClicked ) {
		return d.fileTree;
	}
	return undefined;
}


FileOutputDialog = {};
FileOutputDialog.OutputSettings = function() {
	this.type = "overwrite";
	this.defaultExtension = undefined;
	this.sampleFile = getFirstSelectedBridgeFile();
	this.dir = undefined;
	this.rename = undefined;
	this.syntax = new Hashtable( true );
	this.syntax.put( "Filename", "<var filename>" );
	this.syntax.put( "Filename - Substring", "<var filename[0,6]>" );
	this.syntax.put( "Filepath", "<var path[-1]>" );
	this.syntax.put( "Extension", "<var extension>" );
	this.syntax.put( "Date - YYMMDD", "<var date[YYMMDD]>" );
	this.syntax.put( "Creation Date", "<var cdate[YYMMDD]>" );
	this.syntax.put( "Modification Date", "<var mdate[YYMMDD>" );
	this.syntax.put( "Sequence", "<var sequence[3]>" );
}
FileOutputDialog.OutputSettings.prototype.addSyntax = function( menu, syntax ) {
	this.syntax.put( menu, syntax );
}
FileOutputDialog.init = function() {
	FileOutputDialog.mode = new Hashtable( true );
	FileOutputDialog.mode.put( AdobeLibraryStrings.saveIntoOriginal, "overwrite" );
	FileOutputDialog.mode.put( AdobeLibraryStrings.renameFiles, "rename" );
	FileOutputDialog.mode.put( AdobeLibraryStrings.placeInFolder, "folder" );
	FileOutputDialog.mode.put( AdobeLibraryStrings.mirrorStructure, "mirror" );

	FileOutputDialog.modeReverse = new Hashtable( true );
	FileOutputDialog.modeReverse.put( "overwrite", AdobeLibraryStrings.saveIntoOriginal );
	FileOutputDialog.modeReverse.put( "rename", AdobeLibraryStrings.renameFiles );
	FileOutputDialog.modeReverse.put( "folder", AdobeLibraryStrings );
	FileOutputDialog.modeReverse.put( "mirror", AdobeLibraryStrings.mirrorStructure );
}
FileOutputDialog.sequenceNumber = 0;
FileOutputDialog.parseRenamingTemplate = function( template, file, variableTable, ext, inc )  {
	var incrementSeq = isValidReference( inc ) ? inc : true;
	var s = template;
	var front = getCharsBefore( s, "<var " );
	if ( front == s ) { // means there isn't another "<var..." statement
		return front;
	}
	var junk = getCharsAfter( s, "<var " );
	var key = trim( getCharsBefore( junk, ">" ) );
	var back = getCharsAfter( junk, ">" );
	if ( startsWith( key, "filename" ) ) { // filename is standard in all implementations
		var name = file.getNameWithoutExtension();
		var sub = getCharsAfter( key, "[" );
		var sub = getCharsBefore( sub, "]" );
		if ( isEmpty( sub ) ) {
			sub = "0";
		}
		if ( getCharsBefore( sub, "," ) == sub ) {
			var sub0 = parseInt( sub );
			if ( isNaN( sub0 ) ) {
				throw AdobeLibraryStrings.substringIndexError;
			}
			name = name.substr( sub0 );
			
		} else {
			var sub0 = parseInt( getCharsBefore( sub, "," ) );
			var sub1 = parseInt( getCharsAfter( sub, "," ) );
			if ( isNaN( sub0 ) || isNaN( sub1 ) ) {
				throw AdobeLibraryStrings.substringIndexError;
			}
			name = name.substr( sub0, sub1 );
		}
		s = front + name + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
	} else if ( startsWith( key, "date" ) ) {
		var fmt = getCharsAfter( key, "[" );
		var fmt = getCharsBefore( fmt, "]" );
		s = front + new Date().formatter( fmt ) + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );				
	} else if ( startsWith( key, "cdate" ) ) {
		var fmt = getCharsAfter( key, "[" );
		var fmt = getCharsBefore( fmt, "]" );
		s = front + new Date( file.created ).formatter( fmt ) + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );		
	} else if ( startsWith( key, "mdate" ) ) {
		var fmt = getCharsAfter( key, "[" );
		var fmt = getCharsBefore( fmt, "]" );
		s = front + new Date( file.modified ).formatter( fmt ) + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
	} else if ( startsWith( key, "sequence" ) ) {
		var fmt = getCharsAfter( key, "[" );
		var fmt = getCharsBefore( fmt, "]" );
		var fmt = parseInt( fmt );
		if ( isNaN( fmt ) ) {
			fmt = 3;
		}
		var sqStr = new String( FileOutputDialog.sequenceNumber );
		if ( incrementSeq ) {
			FileOutputDialog.sequenceNumber++;
		}
		var zeros = "0000000000000000000000000000000000000000000000000000000000000000000000000";
		if ( sqStr.length < fmt ) {
			var sq = zeros.substr( 0, ( fmt - sqStr.length ) ) + sqStr;
		} else {
			sq = sqStr;
		}
		s = front + sq + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
	} else if ( key == "extension" ) {
		if ( !isValidReference( ext ) ) {
			ext = file.getExtension();
			if ( isValidReference( ext ) ) {
				ext = "." + ext;
			} else {
				ext = "";
			}
		} else {
			ext = "." + ext;
		}
		s = front + ext + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
	} else if ( startsWith( key, "path" ) ) { //  so are path elements
		var eText = getCharsAfter( key, "[" );
		var idx = getCharsBefore( eText, "]" );
		var pathArray = new String( File.decode( file.absoluteURI ) ).split( "/" );
		try {
			var e = parseInt( idx );
		} catch ( x ) {
			throw ( FileOutputDialog.strings.illegalPathIndex + ": " + idx );
		}
		var pathElement = null;
		if ( e < 0 )  {
			pathElement = pathArray[ ( pathArray.length + e - 1 ) ];
		} else {
			pathElement = pathArray[ e ];
		}
		if ( !isValidReference( pathElement ) )  {
			throw ( FileOutputDialog.strings.pathIndexOB + ": " + idx );
		}
		s = front + pathElement + back;
		return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
	} else {
		var repVal = variableTable.get( key );
		if ( isValidReference( repVal ) ) {
			s = front + repVal + back;
			return FileOutputDialog.parseRenamingTemplate( s, file, variableTable, ext, inc );
		} else {
			throw( key + " " + FileOutputDialog.strings.supportedVariable );
		}
	}
}
FileOutputDialog.show = function( settings ) {
	FileOutputDialog.init();
//debugger;
	if ( !isValidReference( settings ) ) {
		settings = new FileOutputDialog.OutputSettings();
		settings.type = "overwrite";
	}
	var d = FileOutputDialog.create( settings );
	var okClicked = d.show() == 1 ? true : false;
	if ( okClicked ) {
		var mode = FileOutputDialog.mode.get( d.vGroup.optPanel.mode.drop.selection.text );
		switch ( mode ) {
			case "overwrite" : {
				settings.type = "overwrite";
				settings.dir = undefined;
				settings.rename = undefined;
				break;
			}
			case "rename" : {
				settings.type = "rename";
				settings.dir = undefined;
				settings.rename = d.vGroup.optPanel.stack.rename.temp.template.text;
				break;
			}
			case "folder" : {
				settings.type = "folder";
				settings.dir = d.vGroup.optPanel.stack.folder.head.edit.text;
				if ( d.vGroup.optPanel.stack.folder.head.andRenameIt.value ) {
					settings.rename = d.vGroup.optPanel.stack.folder.rename2.temp.template.text;
				} else {
					settings.rename = undefined;
				}
				break;
			}
			case "mirror" : {
				settings.type = "mirror";
				settings.dir = d.vGroup.optPanel.stack.mirror.head.edit.text;
				settings.rename = undefined;
				break;
			}
		}
		return settings;
	}
	return undefined;
}

FileOutputDialog.create = function( settings )  {
 	
    var dlg = new Window( "dialog", AdobeLibraryStrings.fileOutputOptions );

	if ( !isValidReference( settings ) ) {
		dlg.settings = new FileOutputDialog.OutputSettings();
	} else {
		dlg.settings = settings;
	}

  	dlg.orientation = "row"; 	// at the window level, I want two "groups", one to hold the 
						// all the "value entering" controls, and one to hold OK,CANCEL, etc
						// buttons in a vertical column on the right.
	dlg.alignChildren = "top"; 	// the default is center, you want both the value and button groups
							// at the top of the window

	dlg.vGroup = dlg.add( "group" );	// this is the group that will hold all of the value stuff
	dlg.vGroup.orientation = "row";
	dlg.vGroup.alignChildren = "top";

	dlg.bGroup = dlg.add( "group" );
	dlg.bGroup.orientation = "column";
	dlg.bGroup.spacing = 30; // in the button group, I want to have groups of buttons the first two will
					// always be OK, Cancel. But if you want to add a Page Setup, for example,
					// I want it to be an extra 10 pixels down from the Cancel button to differentiate	

	dlg.vGroup.optPanel = dlg.vGroup.add( "panel", undefined, AdobeLibraryStrings.selectFileOutputOptions );
	dlg.vGroup.optPanel.orientation = "column";
	dlg.vGroup.optPanel.alignChildren = "left";
	// dlg.vGroup.optPanel is the first visible element, a panel to hold the items common to layout
	dlg.vGroup.optPanel.mode = dlg.vGroup.optPanel.add( "group" );
	dlg.vGroup.optPanel.mode.stat = dlg.vGroup.optPanel.mode.add( "statictext", undefined, AdobeLibraryStrings.outputMode );
	dlg.vGroup.optPanel.mode.drop = dlg.vGroup.optPanel.mode.add( "dropdownlist" );
	dlg.vGroup.optPanel.mode.drop.parentWindow = dlg; // do this to make referencing the dialog window easier from the onSelect handler
	var settingsMode = FileOutputDialog.modeReverse.get( settings.type );
	DialogUtilities.setupDropdown( dlg.vGroup.optPanel.mode.drop, FileOutputDialog.mode, settingsMode );
	
	dlg.vGroup.optPanel.mode.drop.onChange = function() {
		if ( !isValidReference( this.selection ) ) {
			this.selection = this.items[ 0 ];
		}
		settings.type = this.selection.text;
		this.parentWindow.handlePanelVisibility( this.selection.text );
	}
	dlg.handlePanelVisibility = function( sel ) {
		switch( sel ) {
			case AdobeLibraryStrings.saveIntoOriginal : {
				this.vGroup.optPanel.stack.mirror.visible = false;
				this.vGroup.optPanel.stack.rename.visible = false;
				this.vGroup.optPanel.stack.folder.visible = false;
				this.vGroup.optPanel.stack.folder.rename2.visible = false;
				break;
			}
			case AdobeLibraryStrings.renameFiles : {
				this.vGroup.optPanel.stack.mirror.visible = false;
				this.vGroup.optPanel.stack.rename.visible = true;
				this.vGroup.optPanel.stack.folder.visible = false;
				this.vGroup.optPanel.stack.folder.rename2.visible = false;
				break;
			}
			case AdobeLibraryStrings.placeInFolder : {
				this.vGroup.optPanel.stack.mirror.visible = false;
				this.vGroup.optPanel.stack.rename.visible = false;
				this.vGroup.optPanel.stack.folder.visible = true;
				if ( this.vGroup.optPanel.stack.folder.head.andRenameIt.value ) {
					this.vGroup.optPanel.stack.folder.rename2.visible = true;
				} else {
					this.vGroup.optPanel.stack.folder.rename2.visible = false;
				}
				if ( this.vGroup.optPanel.stack.folder.head.edit.text.length == 0 ) {
					this.bGroup.okGroup.okButton.enabled = false;
				}
				break;
			} 
			case AdobeLibraryStrings.mirrorStructure : {
				this.vGroup.optPanel.stack.mirror.visible = true;
				this.vGroup.optPanel.stack.rename.visible = false;
				this.vGroup.optPanel.stack.folder.visible = false;
				this.vGroup.optPanel.stack.folder.rename2.visible = false;
				if ( this.vGroup.optPanel.stack.mirror.head.edit.text.length == 0 ) {
					this.bGroup.okGroup.okButton.enabled = false;
				}
				break;
			} 
		}
	}
	dlg.vGroup.optPanel.stack = dlg.vGroup.optPanel.add( "group" );
	dlg.vGroup.optPanel.stack.orientation = "stack";
// first Rename Panel	
//	dlg.vGroup.optPanel.stack.spacer = dlg.vGroup.optPanel.stack.add( "group" );
//	dlg.vGroup.optPanel.stack.spacer.orientation = "column";
	dlg.vGroup.optPanel.stack.rename = dlg.vGroup.optPanel.stack.add( "panel", undefined, AdobeLibraryStrings.renameFiles );
	dlg.vGroup.optPanel.stack.rename.alignment = "top";
	dlg.vGroup.optPanel.stack.rename.parentWindow = dlg;
	dlg.vGroup.optPanel.stack.rename.orientation = "column";
	dlg.vGroup.optPanel.stack.rename.adder = dlg.vGroup.optPanel.stack.rename.add( "group" );
	dlg.vGroup.optPanel.stack.rename.adder.orientation = "row";
	dlg.vGroup.optPanel.stack.rename.adder.alignment = "right"
//	dlg.vGroup.optPanel.stack.rename.adder.alignChildren = "right";
	dlg.vGroup.optPanel.stack.rename.adder.stat = dlg.vGroup.optPanel.stack.rename.adder.add( "statictext", undefined, AdobeLibraryStrings.addToTemplate );

	dlg.vGroup.optPanel.stack.rename.adder.drop = dlg.vGroup.optPanel.stack.rename.adder.add( "dropdownlist" );
//	dlg.vGroup.optPanel.stack.rename.adder.drop.alignment = "right";
	DialogUtilities.setupDropdown( dlg.vGroup.optPanel.stack.rename.adder.drop, settings.syntax, "Filename" );
	dlg.vGroup.optPanel.stack.rename.adder.btn = dlg.vGroup.optPanel.stack.rename.adder.add( "button", undefined, AdobeLibraryStrings.add );
//	dlg.vGroup.optPanel.stack.rename.adder.btn.alignment = "right";
	dlg.vGroup.optPanel.stack.rename.adder.parentWindow = dlg; // makes referencing in handlers easier...
	
	dlg.vGroup.optPanel.stack.rename.temp = dlg.vGroup.optPanel.stack.rename.add( "group" );
	dlg.vGroup.optPanel.stack.rename.temp.alignment = "right";
	dlg.vGroup.optPanel.stack.rename.temp.orientation = "row";
	dlg.vGroup.optPanel.stack.rename.temp.alignChildren = "right";
	dlg.vGroup.optPanel.stack.rename.temp.stat = dlg.vGroup.optPanel.stack.rename.temp.add( "statictext", undefined, AdobeLibraryStrings.template );
	dlg.vGroup.optPanel.stack.rename.temp.template = dlg.vGroup.optPanel.stack.rename.temp.add( "edittext", undefined, undefined, { multiline:true } );
	dlg.vGroup.optPanel.stack.rename.temp.template.alignment = "right";
	dlg.vGroup.optPanel.stack.rename.temp.template.preferredSize = [300,60];
	
	dlg.vGroup.optPanel.stack.rename.sample = dlg.vGroup.optPanel.stack.rename.add( "group" );
	dlg.vGroup.optPanel.stack.rename.sample.parentWindow = dlg; // makes referencing easier
	dlg.vGroup.optPanel.stack.rename.sample.alignment = "right";
	dlg.vGroup.optPanel.stack.rename.sample.stat = dlg.vGroup.optPanel.stack.rename.sample.add( "statictext", undefined, AdobeLibraryStrings.newName );
	dlg.vGroup.optPanel.stack.rename.sample.edit = dlg.vGroup.optPanel.stack.rename.sample.add( "statictext" );
	dlg.vGroup.optPanel.stack.rename.sample.edit.alignment = "right";
	dlg.vGroup.optPanel.stack.rename.sample.edit.preferredSize = [300,20]
//	dlg.vGroup.optPanel.stack.rename.sample.edit.enabled = false;
	dlg.vGroup.optPanel.stack.rename.test = dlg.vGroup.optPanel.stack.rename.add( "button", undefined, AdobeLibraryStrings.Test );
	
	dlg.vGroup.optPanel.stack.rename.adder.drop.onChange = function() {
		if ( isValidReference( this.selection ) ) {
			dlg.vGroup.optPanel.stack.rename.adder.btn.enabled = true;
		} else {
			dlg.vGroup.optPanel.stack.rename.adder.btn.enabled = false;
		}
	}
	dlg.vGroup.optPanel.stack.rename.adder.btn.onClick = function() {
//	debugger;
		var sel = this.parent.drop.selection.text;
		if ( isValidReference( sel ) ) {
			var syntax = this.parent.parentWindow.settings.syntax.get( sel );
			if ( isValidReference ( syntax ) ) {
				this.parent.parent.temp.template.textselection = syntax;
			}
		}
		this.parent.parent.temp.template.notify();
	}	
	dlg.vGroup.optPanel.stack.rename.temp.template.text = "<var filename> from <var path[-1]>";
	
	dlg.vGroup.optPanel.stack.rename.temp.template.onChange = function()  {
		var f = this.parent.parent.parentWindow.settings.sampleFile;
		if ( !isValidReference( f ) ) {
			alert( AdobeLibraryStrings.oneFileSelected );
			return;
		}
		var name = FileOutputDialog.parseRenamingTemplate( this.text, f, this.parent.parent.parentWindow.settings.syntax, this.parent.parent.parentWindow.settings.defaultExtension );
		try {
			this.parent.parent.sample.edit.text = File.decode( name ); 
		} catch ( w ) {
			alert( w );
		}
	}
	dlg.vGroup.optPanel.stack.rename.test.onClick = function()  {
		this.parent.temp.template.notify();
	}

	dlg.vGroup.optPanel.stack.rename.adder.drop.notify();
// end first rename panel

// folder panel
	dlg.vGroup.optPanel.stack.folder = dlg.vGroup.optPanel.stack.add( "group" );
	dlg.vGroup.optPanel.stack.folder.orientation = "column";
	
	dlg.vGroup.optPanel.stack.folder.head = dlg.vGroup.optPanel.stack.folder.add( "panel", undefined, AdobeLibraryStrings.placeFilesInFolder );
	dlg.vGroup.optPanel.stack.folder.head.alignment = "fill"
	dlg.vGroup.optPanel.stack.folder.head.alignChildren = "left";
	dlg.vGroup.optPanel.stack.folder.head.parentWindow = dlg; // makes referencing in handlers easier

	dlg.vGroup.optPanel.stack.folder.head.folderBtn = dlg.vGroup.optPanel.stack.folder.head.add( "button", undefined, AdobeLibraryStrings.chooseFolder );
//	dlg.vGroup.optPanel.stack.folder.head.folderBtn.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.head.edit = dlg.vGroup.optPanel.stack.folder.head.add( "statictext" );
//	dlg.vGroup.optPanel.stack.folder.head.edit.enabled = false;
//	dlg.vGroup.optPanel.stack.folder.head.edit.preferredSize = [300,20];
	dlg.vGroup.optPanel.stack.folder.head.edit.alignment = "fill";
	dlg.vGroup.optPanel.stack.folder.head.andRenameIt = dlg.vGroup.optPanel.stack.folder.head.add( "checkbox", undefined, AdobeLibraryStrings.andRename );
	dlg.vGroup.optPanel.stack.folder.head.andRenameIt.alignment = "left";
	dlg.vGroup.optPanel.stack.folder.head.andRenameIt.onClick = function() {
		this.parent.parent.rename2.visible = this.value;
	}
// second rename panel (only shows when and rename it is clicked)
	dlg.vGroup.optPanel.stack.folder.rename2 = dlg.vGroup.optPanel.stack.folder.add( "group" );
	dlg.vGroup.optPanel.stack.folder.rename2.parentWindow = dlg;
	dlg.vGroup.optPanel.stack.folder.rename2.orientation = "column";
	dlg.vGroup.optPanel.stack.folder.rename2.adder = dlg.vGroup.optPanel.stack.folder.rename2.add( "group" );
	dlg.vGroup.optPanel.stack.folder.rename2.adder.orientation = "row";
	dlg.vGroup.optPanel.stack.folder.rename2.adder.alignment = "right"
//	dlg.vGroup.optPanel.stack.rename2.adder.alignChildren = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.adder.stat = dlg.vGroup.optPanel.stack.folder.rename2.adder.add( "statictext", undefined, AdobeLibraryStrings.addToTemplate );

	dlg.vGroup.optPanel.stack.folder.rename2.adder.drop = dlg.vGroup.optPanel.stack.folder.rename2.adder.add( "dropdownlist" );
//	dlg.vGroup.optPanel.stack.rename2.adder.drop.alignment = "right";
	DialogUtilities.setupDropdown( dlg.vGroup.optPanel.stack.folder.rename2.adder.drop, settings.syntax, "Filename" );
	dlg.vGroup.optPanel.stack.folder.rename2.adder.btn = dlg.vGroup.optPanel.stack.folder.rename2.adder.add( "button", undefined, AdobeLibraryStrings.add );
//	dlg.vGroup.optPanel.stack.rename2.adder.btn.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.adder.parentWindow = dlg; // makes referencing in handlers easier...
	
	dlg.vGroup.optPanel.stack.folder.rename2.temp = dlg.vGroup.optPanel.stack.folder.rename2.add( "group" );
	dlg.vGroup.optPanel.stack.folder.rename2.temp.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.temp.orientation = "row";
	dlg.vGroup.optPanel.stack.folder.rename2.temp.alignChildren = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.temp.stat = dlg.vGroup.optPanel.stack.folder.rename2.temp.add( "statictext", undefined, AdobeLibraryStrings.template );
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template = dlg.vGroup.optPanel.stack.folder.rename2.temp.add( "edittext", undefined, undefined, { multiline:true } );
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template.preferredSize = [300,60];
	
	dlg.vGroup.optPanel.stack.folder.rename2.sample = dlg.vGroup.optPanel.stack.folder.rename2.add( "group" );
	dlg.vGroup.optPanel.stack.folder.rename2.sample.parentWindow = dlg; // makes referencing easier
	dlg.vGroup.optPanel.stack.folder.rename2.sample.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.sample.stat = dlg.vGroup.optPanel.stack.folder.rename2.sample.add( "statictext", undefined, AdobeLibraryStrings.newName );
	dlg.vGroup.optPanel.stack.folder.rename2.sample.edit = dlg.vGroup.optPanel.stack.folder.rename2.sample.add( "statictext" );
	dlg.vGroup.optPanel.stack.folder.rename2.sample.edit.alignment = "right";
	dlg.vGroup.optPanel.stack.folder.rename2.sample.edit.preferredSize = [300,20]
//	dlg.vGroup.optPanel.stack.folder.rename2.sample.edit.enabled = false;
	dlg.vGroup.optPanel.stack.folder.rename2.test = dlg.vGroup.optPanel.stack.folder.rename2.add( "button", undefined, AdobeLibraryStrings.Test );
	
	dlg.vGroup.optPanel.stack.folder.rename2.adder.drop.onChange = function() {
		if ( isValidReference( this.selection ) ) {
			dlg.vGroup.optPanel.stack.folder.rename2.adder.btn.enabled = true;
		} else {
			dlg.vGroup.optPanel.stack.folder.rename2.adder.btn.enabled = false;
		}
	}
	dlg.vGroup.optPanel.stack.folder.rename2.adder.btn.onClick = function() {
//	debugger;
		var sel = this.parent.drop.selection.text;
		if ( isValidReference( sel ) ) {
			var syntax = this.parent.parentWindow.settings.syntax.get( sel );
			if ( isValidReference ( syntax ) ) {
				this.parent.parent.temp.template.textselection = syntax;
			}
		}
		this.parent.parent.temp.template.notify();
	}	
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template.text = "<var filename> from <var path[-1]>";
	
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template.onChange = function()  {
		var f = this.parent.parent.parentWindow.settings.sampleFile;
		if ( !isValidReference( f ) ) {
			alert( AdobeLibraryStrings.oneFileSelected );
			return;
		}
		var name = FileOutputDialog.parseRenamingTemplate( this.text, f, this.parent.parent.parentWindow.settings.syntax, this.parent.parent.parentWindow.settings.defaultExtension );
		try {
			this.parent.parent.sample.edit.text = File.decode( name ); 
		} catch ( w ) {
			alert( w );
		}
	}
	dlg.vGroup.optPanel.stack.folder.rename2.test.onClick = function()  {
		this.parent.temp.template.notify();
	}

//	dlg.vGroup.optPanel.stack.folder.rename2.adder.drop.notify();
	dlg.vGroup.optPanel.stack.folder.rename2.adder.drop.notify();
	dlg.vGroup.optPanel.stack.folder.head.folderBtn.onClick = function()  {
		try {
			var theFolder = new Folder( app.document.thumbnail.path );
			if ( theFolder.alias )  {
				theFolder = theFolder.resolve();
			}
			var theFolder = theFolder.selectDlg( AdobeLibraryStrings.selectDestFolder );
			if ( theFolder != null )  {
				this.parent.edit.text = theFolder.fsName;
				this.parent.parentWindow.bGroup.okGroup.okButton.enabled = true;
			} else {
				this.parent.parentWindow.bGroup.okGroup.okButton.enabled = false;
			}
		} catch ( e ) {
			alert( e );
		}
	}
	dlg.vGroup.optPanel.stack.folder.rename2.temp.template.text = "<var filename> from <var path[-1]>";
	
	dlg.vGroup.optPanel.stack.folder.rename2.test.onClick = function()  {
		this.parent.temp.template.notify();
	}

	dlg.vGroup.optPanel.stack.folder.rename2.adder.drop.notify();
// end second rename panel
// end folder panel

// mirror panel
	dlg.vGroup.optPanel.stack.mirror = dlg.vGroup.optPanel.stack.add( "group" );
	dlg.vGroup.optPanel.stack.mirror.orientation = "row";
	dlg.vGroup.optPanel.stack.mirror.alignment = "top";
	dlg.vGroup.optPanel.stack.mirror.alignChildren = "top";
	
	dlg.vGroup.optPanel.stack.mirror.head = dlg.vGroup.optPanel.stack.mirror.add( "panel", undefined, AdobeLibraryStrings.mirrorHead );
	dlg.vGroup.optPanel.stack.mirror.head.alignment = "top"
	dlg.vGroup.optPanel.stack.mirror.head.alignChildren = "left";
	dlg.vGroup.optPanel.stack.mirror.head.parentWindow = dlg; // makes referencing in handlers easier

	dlg.vGroup.optPanel.stack.mirror.head.folderBtn = dlg.vGroup.optPanel.stack.mirror.head.add( "button", undefined, AdobeLibraryStrings.chooseFolder );
//	dlg.vGroup.optPanel.stack.mirror.head.folderBtn.alignment = "right";
	dlg.vGroup.optPanel.stack.mirror.head.edit = dlg.vGroup.optPanel.stack.mirror.head.add( "statictext" );
//	dlg.vGroup.optPanel.stack.mirror.head.edit.enabled = false;
	dlg.vGroup.optPanel.stack.mirror.head.edit.preferredSize = [360,20];
	dlg.vGroup.optPanel.stack.mirror.head.edit.alignment = "fill";

//	dlg.vGroup.optPanel.stack.mirror = dlg.vGroup.optPanel.stack.add( "group" );
//	dlg.vGroup.optPanel.stack.mirror.orientation = "column";
//	dlg.vGroup.optPanel.stack.mirror.parentWindow = dlg;
//	dlg.vGroup.optPanel.stack.mirror.head = dlg.vGroup.optPanel.stack.mirror.add( "group" );
//	dlg.vGroup.optPanel.stack.mirror.head.stat = dlg.vGroup.optPanel.stack.mirror.head.add( "statictext", undefined, "Mirror Folder Structure" );
//	dlg.vGroup.optPanel.stack.mirror.head.stat.alignment = "left";
//	dlg.vGroup.optPanel.stack.mirror.head.folderBtn = dlg.vGroup.optPanel.stack.mirror.head.add( "button", undefined, "Folder..." );
//	dlg.vGroup.optPanel.stack.mirror.head.folderBtn.alignment = "right";
//	dlg.vGroup.optPanel.stack.mirror.head.edit = dlg.vGroup.optPanel.stack.mirror.head.add( "edittext" );
//	dlg.vGroup.optPanel.stack.mirror.head.edit.enabled = false;
	
	dlg.vGroup.optPanel.stack.mirror.head.folderBtn.onClick = function()  {
		try {
			var theFolder = new Folder( app.document.thumbnail.path );
			if ( theFolder.alias )  {
				theFolder = theFolder.resolve();
			}
			var theFolder = theFolder.selectDlg( AdobeLibraryStrings.selectDestFolder );
			if ( theFolder != null )  {
				this.parent.edit.text = theFolder.fsName;
				this.parent.parentWindow.bGroup.okGroup.okButton.enabled = true;
			} else {
				this.parent.parentWindow.bGroup.okGroup.okButton.enabled = false;
			}
		} catch ( e ) {
			alert( e );
		}
	}

// end mirror panel
// make all the stacked panels invisible
	dlg.vGroup.optPanel.stack.mirror.visible = false;
	dlg.vGroup.optPanel.stack.rename.visible = false;
	dlg.vGroup.optPanel.stack.folder.visible = false;
	dlg.vGroup.optPanel.stack.folder.rename2.visible = false;

// this is the OK/Cancel button group
	dlg.bGroup.okGroup = dlg.bGroup.add( "group", undefined );
	dlg.bGroup.okGroup.preferredSize.width = 100;
	dlg.bGroup.okGroup.orientation = "column";
	dlg.bGroup.okGroup.okButton = dlg.bGroup.okGroup.add( "button", undefined, AdobeLibraryStrings.OK );
	dlg.bGroup.okGroup.cancelButton = dlg.bGroup.okGroup.add( "button", undefined, AdobeLibraryStrings.cancel );
	
	dlg.bGroup.okGroup.okButton.onClick = function() {
		dlg.close( 1 );
	}
	dlg.bGroup.okGroup.cancelButton.onClick = function() {
		dlg.close( 2 );
	}
	dlg.vGroup.optPanel.mode.drop.notify();
	dlg.center();
	return dlg;
}
//
//
//
// DANGER WILL ROBINSON - HACKING TESTING AREA BELOW
//
//
//

// works with ScriptUI version 2.2.29 or later
function stringWidth( control, str ) {
	var temp = control.parent.add("statictext", undefined, str);
	var w = temp.preferredSize.width + 2; // there's a 2 pixel bug in the call
	control.parent.remove(temp);
	return w;
}
function stringHeight( control, str) {
	var temp = control.parent.add("statictext", undefined, str);
	var h = temp.preferredSize.height;
	control.parent.remove(temp);
	return h;
}
// library localization
var AdobeLibraryStrings = {};
AdobeLibraryStrings.fsError = localize( "$$$/WAS/Library/local=This script can not operate from this location" );
AdobeLibraryStrings.indexBoundsError = localize( "$$$/WAS/Library/idxob=Index out of bounds" );
AdobeLibraryStrings.MoveOneError = localize( "$$$/WAS/Library/moveOne=Only move one element at a time, please" );
AdobeLibraryStrings.failedToSend = localize( "$$$/WAS/Library/failedtosend=Failed to send message" );
AdobeLibraryStrings.btError = localize( "$$$/WAS/Library/bterr=BridgeTalk Error" );
AdobeLibraryStrings.cancel = localize( "$$$/WAS/Library/cancel=Cancel" );
AdobeLibraryStrings.progress = localize( "$$$/WAS/Library/progress=Progress" );
AdobeLibraryStrings.numericValue = localize( "$$$/WAS/Library/numeric=setValue requires a numeric value" );
AdobeLibraryStrings.complete = localize( "$$$/WAS/Library/complete=Complete" );
AdobeLibraryStrings.iterationError = localize( "$$$/WAS/Library/iterawarning=Warning, an error occurred in Iteration" );
AdobeLibraryStrings.iterationErrorPlural = localize( "$$$/WAS/Library/iterswarn=Warning, errors occurred in Iterations" );
AdobeLibraryStrings.operationComplete = localize( "$$$/WAS/Library/opComplete=Operation Complete" );
AdobeLibraryStrings.starting = localize( "$$$/WAS/Library/starting=Starting..." );
AdobeLibraryStrings.errorBang = localize( "$$$/WAS/Library/error=Error!" );
AdobeLibraryStrings.errorLongRunning = localize( "$$$/WAS/Library/errWarn=Warning, an error occurred" );
AdobeLibraryStrings.failedToSendMessage = localize( "$$$/WAS/Library/failedToSendMsg=Failed to send message: " );
AdobeLibraryStrings.scriptErrors = localize( "$$$/WAS/Library/scriptErrors=Script Errors" );
AdobeLibraryStrings.folderEnablesOK = localize( "$$$/WAS/Library/enableOK=(setting the output folder enables the OK button)" );
AdobeLibraryStrings.selectDestFolder = localize( "$$$/WAS/Library/selectDest=Select the Destination Folder" );
AdobeLibraryStrings.OK = localize( "$$$/WAS/Library/ok=OK" );
AdobeLibraryStrings.selectOutputFile = localize( "$$$/WAS/Library/selectOutput=Select Output File" );
AdobeLibraryStrings.fileEnablesOK = localize( "$$$/WAS/Library/fileOK=(setting the output file enables the OK button)" );
AdobeLibraryStrings.saveIntoOriginal = localize( "$$$/WAS/Library/saveIntoOrig=Save into Original Folder" );
AdobeLibraryStrings.renameFiles = localize( "$$$/WAS/Library/rename=Rename Files" );
AdobeLibraryStrings.placeInFolder = localize( "$$$/WAS/Library/placeFolder=Place in a Folder" );
AdobeLibraryStrings.mirrorStructure = localize( "$$$/WAS/Library/mirror=Mirror the Folder Structure" );
AdobeLibraryStrings.substringIndexError = localize( "$$$/WAS/Library/integers=Substring indices must be integers!" );
AdobeLibraryStrings.fileOutputOptions = localize( "$$$/WAS/Library/FOP=File Output Options" );
AdobeLibraryStrings.selectFileOutputOptions = localize( "$$$/WAS/Library/SFOP=Select File Output Options" );
AdobeLibraryStrings.outputMode = localize( "$$$/WAS/Library/OM=Output Mode:" );
AdobeLibraryStrings.renameFiles = localize( "$$$/WAS/LibraryRF=Rename Files" );
AdobeLibraryStrings.addToTemplate = localize( "$$$/WAS/Library/ATT=Add to Template:" );
AdobeLibraryStrings.add = localize( "$$$/WAS/Library/Add=Add" );
AdobeLibraryStrings.template = localize( "$$$/WAS/Library/TEMPLATE=Template:" );
AdobeLibraryStrings.newName = localize( "$$$/WAS/Library/NEWNAME=New Name:" );
AdobeLibraryStrings.Test = localize( "$$$/WAS/Library/TEST=Test" );
AdobeLibraryStrings.oneFileSelected = localize( "$$$/WAS/Library/ONEselected=At least one file must be selected" );
AdobeLibraryStrings.noFileSelected = localize( "$$$/WAS/Library/NONEselected=There was a problem with \"ScriptName\" because no valid items were selected. Please make a selection and try again." );
AdobeLibraryStrings.genericError = localize( "$$$/WAS/Library/GenericError=There was a problem with \"ScriptName\". Please try again.");
AdobeLibraryStrings.placeInFilesFolder = localize( "$$$/WAS/Library/PlaceInFolder=Place Files In Folder" );
AdobeLibraryStrings.chooseFolder = localize( "$$$/WAS/Library/chooseFolderElip=Choose Folder..." );
AdobeLibraryStrings.andRename = localize( "$$$/WAS/Library/andrename=And Rename the Files" );
AdobeLibraryStrings.mirrorHead = localize( "$$$/WAS/Library/mirrorFromFolder=Mirror Folder Structure from Selected Folder" );
AdobeLibraryStrings.psMenu = localize( "$$$/WAS/Library/psMenu=Photoshop" );
AdobeLibraryStrings.aiMenu = localize( "$$$/WAS/Library/aiMenu=Illustrator" );
AdobeLibraryStrings.idMenu = localize( "$$$/WAS/Library/idMenu=InDesign" );
AdobeLibraryStrings.glmenu = localize( "$$$/WAS/Library/glMenu=GoLive" );

} // closes off the check for it being the bridge....