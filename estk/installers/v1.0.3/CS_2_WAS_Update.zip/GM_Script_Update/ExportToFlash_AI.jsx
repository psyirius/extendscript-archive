#target bridge
//----------------------------------------------------------------------- 
//
// ADOBE SYSTEMS INCORPORATED
// (c) 2004-05 Adobe Systems Incorporated.
// All Rights Reserved
//
// NOTICE: Adobe permits you to use, modify, and distribute
// this file in accordance with the terms of the Adobe license
// agreement accompanying it. If you have received this file
// from a source other than Adobe, then your use, modification,
// or distribution of it requires the prior written permission
// of Adobe.
//

// make sure bridge is the current app
if (BridgeTalk.appName == "bridge" )	 {
	var ExportToFlashAI = {};
	ExportToFlashAI.scriptInfo = new ScriptManager.ScriptInfo();
	ExportToFlashAI.scriptInfo.set( "name", localize( "$$$/WAS/xtf/infoName=Export to Flash" ) );
	ExportToFlashAI.scriptInfo.set( "description", localize( "$$$/WAS/xtf/infodesc=Exports a selected file to Flash (SWF) format." ) );
	ExportToFlashAI.scriptInfo.set( "help", localize( "$$$/WAS/xtf/infoHelp=Select a set of images in Bridge, select menu item Tool->Illustrator->Export To Flash->[Mode]. Quick Mode will export with default settings, Custom will allow you to choose export options." ) );
	ExportToFlashAI.scriptInfo.set( "author", "Chandler McWilliams" );
	ExportToFlashAI.scriptInfo.set( "company", localize( "$$$/WAS/xtf/infoCompany=Adobe Systems, Inc." ) );
	ExportToFlashAI.scriptInfo.set( "copyright", localize( "$$$/WAS/xtf/infoCopyright=(c) Copyright 2004-2005 Adobe Systems Incorporated. All rights reserved" ) )
	ExportToFlashAI.scriptInfo.set( "version", "0.5.22" );
	ExportToFlashAI.scriptInfo.set( "date", "07-19-2005" );
	ExportToFlashAI.scriptInfo.set( "website", "http://www.adobe.com" );

	createGenericMenus();

	// create main menu object
	createMenu( "menu", localize("$$$/WAS/ETFAIExporttoFlash=Export to Flash"), "at the end of tools/ai", "tools/ai/ExportToFlash" );

	// create menu for Simple Export
	var ExportToFlashAIQuick =  new BAScriptMenu( "command", localize("$$$/WAS/ETFAIQuickExport=Quick Export"), "at the end of tools/ai/ExportToFlash", "tools/ai/ExportToFlash/QuickExport");
	ExportToFlashAIQuick.setTarget('illustrator');
	ExportToFlashAIQuick.setEnabledForTypes(TYPES.ILLUSTRATOR_OPENABLE);
	ExportToFlashAIQuick.getScript = function( f )  {
		var options = "var opt = new ExportOptionsFlash(); opt.resolution = 72; opt.generateHTML = false;";
		var scpt = getExportToFlashScript(f, options);
		BridgeTalk.bringToFront('illustrator');
		return scpt;
	}

	// create menu for Custom Export
	ExportToFlashAI.menu = createMenu( "command", localize("$$$/WAS/ETFAICustomExport=Custom Export..."), "at the end of tools/ai/ExportToFlash", "tools/ai/ExportToFlash/CustomExport");
	ExportToFlashAI.menu.onSelect = function() {
		// init the dialog
		ExportToFlashAI.initDialog();

		// show the dialog
		ExportToFlashAI.showDialog();
	}



	// add actions for ok
	ExportToFlashAI.ok = function() {
		// holds code for the options to pass to AI
		var options = "var opt = new ExportOptionsFlash();";
		
		// set export style
		options += 'opt.exportStyle = FlashExportStyle.';
		switch (ExportToFlashAI.dialog.typeDD.selection.index) {
			case 0:
				options += 'ASFLASHFILE;';
				break;
			
			case 1:
				options += 'LAYERSASFRAMES;';
				options += 'opt.frameRate		= ' + ExportToFlashAI.dialog.options.rateEt.text + ';';
				options += 'opt.looping			= ' + ExportToFlashAI.dialog.options.loopCb.value + ';';
				options += 'opt.layerOrder		= LayerOrderType.' + ExportToFlashAI.dialog.options.layerOrderDD.selection.value + ';';
				
				if(ExportToFlashAI.dialog.options.blendsOptGrp.enabled) {
					if(ExportToFlashAI.dialog.options.blendRb1.value == true) {
						options += 'opt.blendAnimation	= BlendAnimationType.INBUILD;';
					} else if(ExportToFlashAI.dialog.options.blendRb2.value == true) {
						options += 'opt.blendAnimation	= BlendAnimationType.INSEQUENCE;';
					}
				}


				
				break;
			
			case 2:
				options += 'LAYERSASFILES;';
				break;
		}
		options += 'opt.generateHTML			= ' + ExportToFlashAI.dialog.options.htmlCb.value + ';';
		options += 'opt.artBoardClipping		= ' + ExportToFlashAI.dialog.options.clipCb.value + ';';
		options += 'opt.readOnly 				= ' + ExportToFlashAI.dialog.options.protectCb.value + ';';
		options += 'opt.convertTextToOutlines	= ' + ExportToFlashAI.dialog.options.outlineCb.value + ';';
		options += 'opt.compressed 				= ' + ExportToFlashAI.dialog.options.compressCb.value + ';';


		// set method options
		if (ExportToFlashAI.dialog.options.flattenRb1.value == true) {
			options += 'opt.flattenOutput = OutputFlattening.PRESERVEAPPEARANCE;';
		} else {
			options += 'opt.flattenOutput = OutputFlattening.PRESERVEPATHS;';
		}
		
		// set curve quality
		options += 'opt.curveQuality = '+ExportToFlashAI.dialog.options.curveSlider.value+';';

		// set image options
		if (ExportToFlashAI.dialog.options.lossRb1.value == true) {
			options += 'opt.imageFormat = FlashImageFormat.LOSSLESS;';
		} else {
			options += 'opt.imageFormat = FlashImageFormat.LOSSY;';
			
			if (ExportToFlashAI.dialog.options.methodRb1.value == true) {
				options += 'opt.jpegMethod = FlashJPEGMethod.Standard;';
			} else {
				options += 'opt.jpegMethod = FlashJPEGMethod.Optimized;';
			}
			
			options += 'opt.jpegQuality = ' + ExportToFlashAI.dialog.options.qualityDD.selection.value + ';';
		}

		var scpt = '';

		// get selected files
		files = getBridgeFiles(TYPES.ILLUSTRATOR_OPENABLE,true, true);
		
		// create iterator
		var bti = new BridgeTalkIterator( true, localize("$$$/WAS/ETFAICustomExport=Custom Export..."), localize("$$$/WAS/ETFAICustomExport=Custom Export..."), false );

		for (var i=0; i<files.length; i++) {
			// get script
			scpt = getExportToFlashScript(files[i], options);
			/*
			sendBridgeTalkMessage(
				'illustrator',
				scpt
			);
			*/
			bti.addMessage( 'illustrator', scpt, files[i].name );
		}
		bti.send();
		ExportToFlashAI.dialog.close( true );
	}

	ExportToFlashAI.cancel	= function () {
		ExportToFlashAI.dialog.close();
	}

	ExportToFlashAI.initDialog = function()  {
		ExportToFlashAI.dialog = new Window("dialog", localize("$$$/WAS/ETFAIExporttoFlash=Export to Flash"));
		ExportToFlashAI.dialog.options = {};
		ExportToFlashAI.dialog.orientation = "stack";
		
		ExportToFlashAI.dialog.pnlTitleGrp = ExportToFlashAI.dialog.add( "group" );
		ExportToFlashAI.dialog.pnlTitleGrp.orientation = "row";
		ExportToFlashAI.dialog.pnlTitleGrp.title = ExportToFlashAI.dialog.pnlTitleGrp.add("statictext", undefined, localize("$$$/WAS/ETFAIExportAs=Export As:") );
		ExportToFlashAI.dialog.typeDD = ExportToFlashAI.dialog.pnlTitleGrp.add( "dropdownlist" );
		ExportToFlashAI.dialog.typeDD.add('item', localize("$$$/WAS/ETFAIFileToSWFFile=AI File to SWF File"));
		ExportToFlashAI.dialog.typeDD.add('item', localize("$$$/WAS/ETFAILayersToSWFFrames=AI Layers to SWF Frames"));
		ExportToFlashAI.dialog.typeDD.add('item', localize("$$$/WAS/ETFAILayersToSWFFiles=AI Layers to SWF Files"));
		ExportToFlashAI.dialog.typeDD.selection = ExportToFlashAI.dialog.typeDD.items[0];

		ExportToFlashAI.dialog.mainRow = ExportToFlashAI.dialog.add( "group" );
		
		
		/**
		* FIRST COLUMN -----------------------------------------------------------
		*/

		ExportToFlashAI.dialog.exportCol = ExportToFlashAI.dialog.mainRow.add( "panel", undefined, localize("$$$/WAS/ETFAIExportAs=Export As:") );
		ExportToFlashAI.dialog.exportCol.orientation = "row";		


		// first options column
			ExportToFlashAI.dialog.optCol1 = ExportToFlashAI.dialog.exportCol.add( "group" );
			ExportToFlashAI.dialog.optCol1.orientation = "column";
			ExportToFlashAI.dialog.optCol1.alignment = "fill";
			
			// general
			var general = ExportToFlashAI.dialog.optCol1.add("group");
			general.orientation = "column";
	
			// Generate HTML
			general.htmlCb = general.add( "checkbox", undefined, localize("$$$/WAS/ETFAIGenerateHTML=Generate HTML") );
			general.htmlCb.alignment = "left";
			general.htmlCb.value = true;
			ExportToFlashAI.dialog.options.htmlCb = general.htmlCb;

			// Protect From Import
			general.protectCb = general.add( "checkbox", undefined, localize("$$$/WAS/ETFAIProtectFromImport=Protect from Import"));
			general.protectCb.alignment = "left";
			ExportToFlashAI.dialog.options.protectCb = general.protectCb;

			// Clip to Artboard size
			general.clipCb = general.add( "checkbox", undefined, localize("$$$/WAS/ETFAIClipToArtboardSize=Clip to Artboard Size"));
			general.clipCb.alignment = "left";
			ExportToFlashAI.dialog.options.clipCb = general.clipCb;

			// outline text
			general.outlineCb = general.add( "checkbox", undefined, localize("$$$/WAS/ETFAIExportTextAsOutlines=Export Text As Outlines") );
			general.outlineCb.alignment = "left";
			ExportToFlashAI.dialog.options.outlineCb = general.outlineCb;

			// compress
			general.compressCb = general.add( "checkbox", undefined, localize("$$$/WAS/ETFAICompressFile=Compress File") );
			general.compressCb.alignment = "left";
			ExportToFlashAI.dialog.options.compressCb = general.compressCb;



			// animation
			var animation = ExportToFlashAI.dialog.optCol1.add("panel", undefined, localize("$$$/WAS/ETFAIAnimation=Animation"));
			animation.orientation = "column";
			animation.alignment = "fill";


			// fps
			var rate = animation.add( "group" ); 
			rate.add( "statictext", undefined, localize("$$$/WAS/ETFAIFrameRate=Frame Rate:") );
			rate.et	= rate.add( "edittext",undefined,12 );
			rate.et.preferredSize.width = 50;
			rate.add( "statictext", undefined, "fps" );
			ExportToFlashAI.dialog.options.rateEt = rate.et;

			// Looping
			animation.loopCb = animation.add( "checkbox", undefined, localize("$$$/WAS/ETFAILooping=Looping"));
			animation.loopCb.alignment = "left";
			ExportToFlashAI.dialog.options.loopCb = animation.loopCb;
		

			// Use as layer order
			var layerOrder = animation.add('group');
			layerOrder.orientation = 'row';
			layerOrder.add( "statictext", undefined, localize("$$$/WAS/ETFAILayerOrder=Layer Order"));
			ExportToFlashAI.dialog.options.layerOrderDD = layerOrder.add( "dropdownlist");
			var item = ExportToFlashAI.dialog.options.layerOrderDD.add('item', localize("$$$/WAS/ETFAIBottomUp=Bottom Up"));
			item.value = 'BOTTOMUP';
			item = ExportToFlashAI.dialog.options.layerOrderDD.add('item', localize("$$$/WAS/ETFAITopDown=Top Down"));
			item.value = 'TOPDOWN';
			ExportToFlashAI.dialog.options.layerOrderDD.selection = ExportToFlashAI.dialog.options.layerOrderDD.items[0];

			// blends
			var blends = animation.add( "group" ); 
			blends.orientation = 'column';
			blends.alignChildren = 'left';
			ExportToFlashAI.dialog.options.blendsCb = blends.add( "checkbox", undefined, localize("$$$/WAS/ETFAIAnimateBlends=Animate Blends") );
			ExportToFlashAI.dialog.options.blendsCb.onClick = function() {
				ExportToFlashAI.dialog.options.blendsOptGrp.enabled = this.value;
			}
			
			ExportToFlashAI.dialog.options.blendsOptGrp = blends.add('group');
			ExportToFlashAI.dialog.options.blendsOptGrp.enabled = false;
			ExportToFlashAI.dialog.options.blendRb1 = ExportToFlashAI.dialog.options.blendsOptGrp.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIInSequence=In Sequence"));
			ExportToFlashAI.dialog.options.blendRb2 = ExportToFlashAI.dialog.options.blendsOptGrp.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIInBuild=In Build"));
			ExportToFlashAI.dialog.options.blendRb2.value = true;

			


		// second options column
			ExportToFlashAI.dialog.optCol2 = ExportToFlashAI.dialog.exportCol.add( "group" );
			ExportToFlashAI.dialog.optCol2.orientation = "column";
			ExportToFlashAI.dialog.optCol2.alignment = "fill";


			// method
			var methodPnl = ExportToFlashAI.dialog.optCol2.add('panel', undefined, localize("$$$/WAS/ETFAIMethod=Method:"));
			methodPnl.alignChildren = 'left';
			ExportToFlashAI.dialog.options.flattenRb1 = methodPnl.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIPreserveAppearance=Preserve Appearance"));
			ExportToFlashAI.dialog.options.flattenRb2 = methodPnl.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIPreserveEditabilityWherePossible=Preserve Editability Where Possible"));
			ExportToFlashAI.dialog.options.flattenRb2.value = true;



			// curve quality
			var curvePnl = ExportToFlashAI.dialog.optCol2.add('group');
			curvePnl.orientation = 'row';
			curvePnl.alignChildren = 'left';
			curvePnl.add('statictext', undefined, localize("$$$/WAS/ETFAICurveQuality=Curve Quality:"));
			ExportToFlashAI.dialog.options.curveSlider = curvePnl.add('slider', undefined, 7,0,10);
			ExportToFlashAI.dialog.options.curveValEt = curvePnl.add('statictext', undefined, 7);
			ExportToFlashAI.dialog.options.curveValEt.preferredSize.width = 20;
			ExportToFlashAI.dialog.options.curveSlider.onChange = function() {
				ExportToFlashAI.dialog.options.curveValEt.text = Math.round(this.value);
			}
			

			// image
			var imagePnl = ExportToFlashAI.dialog.optCol2.add('panel', undefined, localize('$$$/WAS/ETDAImageWordHardCoded=Image'));
			
			// format
			var formatRow = imagePnl.add( "group" );
			formatRow.orientation = "row";
			formatRow.alignChildren = "top";
			
			var formatLft = formatRow.add( "group" );
			formatLft.add( "statictext", undefined, localize("$$$/WAS/ETFAIImageFormat=Image Format:"));
			
			var formatRt = formatRow.add( "group" );
			formatRt.orientation = 'column';
			formatRt.alignChildren = 'left';
			ExportToFlashAI.dialog.options.lossRb1 = formatRt.add( "radiobutton", undefined, localize("$$$/WAS/ETFAILossless=Lossless"));
			ExportToFlashAI.dialog.options.lossRb2 = formatRt.add( "radiobutton", undefined, localize("$$$/WAS/ETFAILossy=Lossy (JPEG)"));
			ExportToFlashAI.dialog.options.lossRb1.value = true;
			
			// jpeg quality
			var quality = imagePnl.add( "group" ); 
			quality.add( "statictext", undefined, localize("$$$/WAS/ETFAIJPEGQuality=JPEG Quality"));
			quality.dd	= quality.add( "dropdownlist" );
			var item = quality.dd.add( "item", localize("$$$/WAS/ETFAIJPEGQualityLow=Low" ) );
			item.value = 1;
			item = quality.dd.add( "item", localize("$$$/WAS/ETFAIJPEGQualityMedium=Medium" ) );
			item.value = 3;
			item = quality.dd.add( "item", localize("$$$/WAS/ETFAIJPEGQualityHigh=High" ) );
			item.value = 6;
			item = quality.dd.add( "item", localize("$$$/WAS/ETFAIJPEGQualityMaximum=Maximum" ) );
			item.value = 8;
			quality.dd.selection = 0;
			ExportToFlashAI.dialog.options.qualityDD = quality.dd;

			// method
			var methodRow = imagePnl.add( "group" );
			methodRow.orientation = "row";
			methodRow.alignChildren = "top";
			
			var methodLft = methodRow.add( "group" );
			methodLft.add( "statictext", undefined, localize("$$$/WAS/ETFAIMethod=Method:"));
			
			var methodRt = methodRow.add( "group" );
			methodRt.orientation = 'column';
			methodRt.alignChildren = 'left';
			ExportToFlashAI.dialog.options.methodRb1 = methodRt.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIBaselineStandard=Baseline (Standard)"));
			ExportToFlashAI.dialog.options.methodRb2 = methodRt.add( "radiobutton", undefined, localize("$$$/WAS/ETFAIBaselineOptimized=Baseline Optimized"));
			ExportToFlashAI.dialog.options.methodRb1.value = true;
			
			// resolution
			var resolution = imagePnl.add( "group" ); 
			resolution.add( "statictext", undefined, localize("$$$/WAS/ETFAIResolution=Resolution:") );
			resolution.et 	= resolution.add( "edittext", undefined, "72" );
			resolution.et.preferredSize.width = 50;
			resolution.add( "statictext", undefined, "ppi" );
			ExportToFlashAI.dialog.options.resEt = resolution.et;
			
			// disable jpeg options
			methodRow.enabled = false;
			methodLft.enabled = false;
			methodRt.enabled = false;
			quality.enabled = false;




	/**
	* SECOND COLUMN --------------------------------------------------------
	*/
		// this is the OK/Cancel button group
		ExportToFlashAI.dialog.btn = ExportToFlashAI.dialog.mainRow.add( "group" );
		ExportToFlashAI.dialog.btn.orientation = "column";
		ExportToFlashAI.dialog.btn.alignChildren = 'top';
		ExportToFlashAI.dialog.btn.alignment = 'fill';
		ExportToFlashAI.dialog.btn.spacing = 30;
		
		ExportToFlashAI.dialog.buttonGroup = ExportToFlashAI.dialog.btn.add( "group", undefined );
		ExportToFlashAI.dialog.buttonGroup.preferredSize.width = 100;
		ExportToFlashAI.dialog.buttonGroup.orientation = "column";
		ExportToFlashAI.dialog.buttonGroup.alignChildren = "top";
		ExportToFlashAI.dialog.buttonGroup.alignment = "fill";
		ExportToFlashAI.dialog.buttonGroup.okButton = ExportToFlashAI.dialog.buttonGroup.add( "button", undefined, localize("$$$/WAS/ETFAIOKButton=OK") );
		ExportToFlashAI.dialog.buttonGroup.cancelButton = ExportToFlashAI.dialog.buttonGroup.add( "button", undefined, localize("$$$/WAS/ETFAICancelButton=Cancel") );		

		
		// move the drop down so that it overlapps the panel
		ExportToFlashAI.dialog.onShow = 	function () {
			this.pnlTitleGrp.location.x = this.exportCol.location.x + 30;
			this.pnlTitleGrp.location.y = this.exportCol.location.y + 12;
		}
	
		ExportToFlashAI.dialog.buttonGroup.okButton.onClick		= this.ok;
		ExportToFlashAI.dialog.buttonGroup.cancelButton.onClick	= this.cancel;

		ExportToFlashAI.dialog.center();

	
	/**
	* ACTIONS --------------------------------------------------------
	*/

		// add actions for animation panel
		ExportToFlashAI.dialog.typeDD.onChange = function() {
			animation.enabled = (this.selection.text == localize("$$$/WAS/ETFAILayersToSWFFrames=AI Layers to SWF Frames"));
		}

	
		// add actions for image panel
		ExportToFlashAI.dialog.options.lossRb1.onClick = function() {
			methodRow.enabled = false;
			methodLft.enabled = false;
			methodRt.enabled = false;
			quality.enabled = false;
		}
		ExportToFlashAI.dialog.options.lossRb2.onClick = function() {
			methodRow.enabled = true;
			methodLft.enabled = true;
			methodRt.enabled = true;
			quality.enabled = true;
		}

		
	}
	
	ExportToFlashAI.showDialog	= function () {
		ExportToFlashAI.dialog.show();
	}

	function getExportToFlashScript( f, options) {
		// get new name
		var pi = pathinfo(f.absoluteURI);
		var newFile = f.getFileWithExtension( 'swf' );
		var scpt = "app.userInteractionLevel=UserInteractionLevel.DONTDISPLAYALERTS;\r" +
				"BridgeTalk.bringToFront('illustrator'); " +
				"try { \n " +
				"var thefile = eval( " + f.toSource() + " ); \n" +
					 "var doc = app.open( thefile ); \n" + options +
					 "var newFile = eval( " + newFile.toSource() + " ); \n" +
					 "doc.exportFile( newFile, ExportType.FLASH, opt); \n" +
				"} \n" +
			"catch( p ) { alert(' "+ AdobeLibraryStrings.genericError.replace(/ScriptName/g, localize("$$$/WAS/ETFAIExporttoFlash=Export to Flash"))+" '); } finally {doc.close(SaveOptions.DONOTSAVECHANGES);}";
		return scpt;
	}

	ScriptManager.reportLoading( ExportToFlashAI.scriptInfo );
}
