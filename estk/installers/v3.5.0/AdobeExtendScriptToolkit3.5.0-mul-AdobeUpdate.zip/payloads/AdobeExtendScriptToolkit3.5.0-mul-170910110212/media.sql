CREATE TABLE Branding ( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),resource_type TEXT NOT NULL,resource_data TEXT NOT NULL,PRIMARY KEY (ProductID, resource_type) )
CREATE TABLE DependencyData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PayloadIDb TEXT ,type TEXT NOT NULL ,product_family TEXT, product_name TEXT, version TEXT, PRIMARY KEY (PayloadID,PayloadIDb,type,product_family,product_name,version))
CREATE TABLE EULA_Files( productID TEXT NOT NULL, langCode TEXT NOT NULL,eula TEXT NOT NULL,PRIMARY KEY (productID, langCode) )
CREATE TABLE PayloadData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),domain TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY (PayloadID, domain, key) )
CREATE TABLE Payloads( PayloadID TEXT NOT NULL, payload_family TEXT NOT NULL,payload_name TEXT NOT NULL, payload_version TEXT NOT NULL,payload_type TEXT NOT NULL,PRIMARY KEY (PayloadID) )
CREATE TABLE SuitePayloads( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PRIMARY KEY (ProductID, PayloadID) )
CREATE TABLE Suites( ProductID TEXT NOT NULL, group_name TEXT NOT NULL, group_family TEXT NOT NULL, display_name TEXT NOT NULL, PRIMARY KEY (ProductID) )
INSERT INTO DependencyData VALUES	("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "{E995AC53-954A-48D2-A861-613B8D42A9BE}", "patch", "CoreTech", "Adobe ExtendScript Toolkit CS5", "")
INSERT INTO Payloads VALUES	("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "CoreTech", "Adobe ExtendScript Toolkit CS5_3.5.0_AdobeExtendScriptToolkit3.5.0-mul", "3.5.0", "patch")
INSERT INTO PayloadData VALUES("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "0" , "PayloadInfo", '<PayloadInfo version="3.0.121.0"><BuildInfo>
    <Property name="Created">2010-09-17 11:02:12.135000</Property>
    <Property name="TargetName">AdobeExtendScriptToolkit3.5.0-mul-170910110212</Property>
    <Property name="ProcessorFamily">All</Property>
  </BuildInfo><InstallerProperties>
    <Property name="payloadType">SQLite</Property>
    <Property name="AdobeCode">{187A7A38-6DD4-4549-AECD-22BA6BC2F002}</Property>
    <Property name="ProductName">Adobe ExtendScript Toolkit CS5</Property>
    <Property name="ProductVersion">3.5.0</Property>
  </InstallerProperties><InstallDir>
    <Platform isFixed="0" name="Default" folderName="">[AdobeProgramFiles]/Adobe Utilities - CS5/ExtendScript Toolkit CS5</Platform>
  </InstallDir><Languages languageIndependent="1"/><Satisfies>
    <ProductInfo>
      <Family>CoreTech</Family>
      <ProductName>Adobe ExtendScript Toolkit CS5_3.5.0_AdobeExtendScriptToolkit3.5.0-mul</ProductName>
      <ProductVersion>3.5.0</ProductVersion>
    </ProductInfo>
  </Satisfies><Channel enable="1" id="AdobeExtendScriptToolkitCS5-3.5.0">
        <DisplayName>Adobe ExtendScript Toolkit CS5</DisplayName>
      </Channel><Update id="3.5.0">
        <DisplayName default="en_US">
          <en_US>Adobe ExtendScript Toolkit CS5 3.5.0</en_US>
        </DisplayName>
        <Description default="en_US">
          <en_US>Adobe ExtendScript Toolkit CS5</en_US>
        </Description>
      </Update><Extends type="patch">
    <ParentProductInfo>
      <Family>CoreTech</Family>
      <ProductName>Adobe ExtendScript Toolkit CS5</ProductName>
      <AdobeCode>{E995AC53-954A-48D2-A861-613B8D42A9BE}</AdobeCode>
    </ParentProductInfo>
  </Extends><InstallDestinationMetadata relocatableSize="366326" sysDriveSize="10989541"><Destination>
      <Root>[AdobeProgramFiles]</Root>
      <TotalSize>10989541</TotalSize>
      <MaxPathComponent>/Adobe Utilities - CS5/ExtendScript Toolkit CS5/SDK/Samples/javascript\MessageSendingToInDesign.jsx</MaxPathComponent>
    </Destination>
    <Destination>
      <Root>[INSTALLDIR]</Root>
      <TotalSize>366326</TotalSize>
      <MaxPathComponent>/Adobe/AdobePatchFiles/{187A7A38-6DD4-4549-AECD-22BA6BC2F002}\890a6ef7a379d3f44556decd88c5fd61.rtp</MaxPathComponent>
    </Destination>
    <Assets>
      <Asset flag="0" name="Assets2_1" size="10989541"/>
      <Asset flag="1" name="Assets1_1" size="366326"/>
    </Assets>
  </InstallDestinationMetadata><ConflictingProcesses>
    <Win32>
      <Process processType="Adobe" blocking="1">^[Ee][Xx][Tt][Ee][Nn][Dd][Ss][Cc][Rr][Ii][Pp][Tt] [Tt][Oo][Oo][Ll][Kk][Ii][Tt].[Ee][Xx][Ee]$</Process>
    </Win32>
  </ConflictingProcesses><AddRemoveInfo>
    <DisplayVersion>
      <Value lang="sq_AL">3.5.0</Value>
      <Value lang="ar_AE">3.5.0</Value>
      <Value lang="be_BY">3.5.0</Value>
      <Value lang="bg_BG">3.5.0</Value>
      <Value lang="ca_ES">3.5.0</Value>
      <Value lang="zh_CN">3.5.0</Value>
      <Value lang="zh_TW">3.5.0</Value>
      <Value lang="hr_HR">3.5.0</Value>
      <Value lang="cs_CZ">3.5.0</Value>
      <Value lang="da_DK">3.5.0</Value>
      <Value lang="nl_NL">3.5.0</Value>
      <Value lang="en_XC">3.5.0</Value>
      <Value lang="en_XM">3.5.0</Value>
      <Value lang="en_GB">3.5.0</Value>
      <Value lang="en_US">3.5.0</Value>
      <Value lang="et_EE">3.5.0</Value>
      <Value lang="fi_FI">3.5.0</Value>
      <Value lang="fr_FR">3.5.0</Value>
      <Value lang="fr_XM">3.5.0</Value>
      <Value lang="de_DE">3.5.0</Value>
      <Value lang="el_GR">3.5.0</Value>
      <Value lang="he_IL">3.5.0</Value>
      <Value lang="hu_HU">3.5.0</Value>
      <Value lang="hi_IN">3.5.0</Value>
      <Value lang="is_IS">3.5.0</Value>
      <Value lang="it_IT">3.5.0</Value>
      <Value lang="ja_JP">3.5.0</Value>
      <Value lang="ko_KR">3.5.0</Value>
      <Value lang="lv_LV">3.5.0</Value>
      <Value lang="lt_LT">3.5.0</Value>
      <Value lang="mk_MK">3.5.0</Value>
      <Value lang="nn_NO">3.5.0</Value>
      <Value lang="no_NO">3.5.0</Value>
      <Value lang="nb_NO">3.5.0</Value>
      <Value lang="pl_PL">3.5.0</Value>
      <Value lang="pt_BR">3.5.0</Value>
      <Value lang="ro_RO">3.5.0</Value>
      <Value lang="ru_RU">3.5.0</Value>
      <Value lang="sh_YU">3.5.0</Value>
      <Value lang="sk_SK">3.5.0</Value>
      <Value lang="sl_SI">3.5.0</Value>
      <Value lang="es_QM">3.5.0</Value>
      <Value lang="es_ES">3.5.0</Value>
      <Value lang="sv_SE">3.5.0</Value>
      <Value lang="th_TH">3.5.0</Value>
      <Value lang="tr_TR">3.5.0</Value>
      <Value lang="uk_UA">3.5.0</Value>
      <Value lang="vi_VN">3.5.0</Value>
      <Value lang="fr_CA">3.5.0</Value>
      <Value lang="es_MX">3.5.0</Value>
    </DisplayVersion>
    <DisplayName>
      <Value lang="sq_AL">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ar_AE">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="be_BY">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="bg_BG">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ca_ES">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="zh_CN">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="zh_TW">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="hr_HR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="cs_CZ">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="da_DK">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="nl_NL">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="en_XC">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="en_XM">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="en_GB">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="en_US">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="et_EE">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="fi_FI">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="fr_FR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="fr_XM">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="de_DE">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="el_GR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="he_IL">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="hu_HU">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="hi_IN">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="is_IS">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="it_IT">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ja_JP">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ko_KR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="lv_LV">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="lt_LT">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="mk_MK">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="nn_NO">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="no_NO">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="nb_NO">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="pl_PL">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="pt_BR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ro_RO">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="ru_RU">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="sh_YU">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="sk_SK">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="sl_SI">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="es_QM">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="es_ES">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="sv_SE">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="th_TH">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="tr_TR">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="uk_UA">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="vi_VN">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="fr_CA">Adobe ExtendScript Toolkit CS5</Value>
      <Value lang="es_MX">Adobe ExtendScript Toolkit CS5</Value>
    </DisplayName>
  </AddRemoveInfo><UserPreferences>0</UserPreferences></PayloadInfo>')
INSERT INTO PayloadData VALUES("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "0", "ChannelID", "AdobeExtendScriptToolkitCS5-3.5.0")
INSERT INTO PayloadData VALUES("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "0", "ChannelInfo", '<Channel enable="1" id="AdobeExtendScriptToolkitCS5-3.5.0">
        <DisplayName>Adobe ExtendScript Toolkit CS5</DisplayName>
      </Channel>')
INSERT INTO PayloadData VALUES("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "0", "UpdateID", "3.5.0")
INSERT INTO PayloadData VALUES("{187A7A38-6DD4-4549-AECD-22BA6BC2F002}", "0", "UpdateInfo", '<Update id="3.5.0">
        <DisplayName default="en_US">
          <en_US>Adobe ExtendScript Toolkit CS5 3.5.0</en_US>
        </DisplayName>
        <Description default="en_US">
          <en_US>Adobe ExtendScript Toolkit CS5</en_US>
        </Description>
      </Update>')
